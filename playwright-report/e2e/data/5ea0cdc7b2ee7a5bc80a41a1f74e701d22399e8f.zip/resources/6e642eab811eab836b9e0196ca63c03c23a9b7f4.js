import {
  render,
  renderToCanvas
} from "/node_modules/.cache/sb-vite/deps/chunk-CL2QL7NK.js?v=77221ebe";
import "/node_modules/.cache/sb-vite/deps/chunk-W76KQCFG.js?v=77221ebe";
import "/node_modules/.cache/sb-vite/deps/chunk-3OCI4AVN.js?v=77221ebe";
import "/node_modules/.cache/sb-vite/deps/chunk-UGWRUW6S.js?v=77221ebe";
import "/node_modules/.cache/sb-vite/deps/chunk-ISPWXKZJ.js?v=77221ebe";
import "/node_modules/.cache/sb-vite/deps/chunk-OQ3OWAGM.js?v=77221ebe";
import "/node_modules/.cache/sb-vite/deps/chunk-LFBQMW2U.js?v=77221ebe";

// node_modules/@storybook/react/dist/entry-preview.mjs
var parameters = { renderer: "react" };
export {
  parameters,
  render,
  renderToCanvas
};
//# sourceMappingURL=@storybook_react_dist_entry-preview__mjs.js.map
