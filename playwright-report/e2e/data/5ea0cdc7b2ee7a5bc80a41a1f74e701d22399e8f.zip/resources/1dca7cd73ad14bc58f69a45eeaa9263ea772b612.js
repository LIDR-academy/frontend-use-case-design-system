import {
  require_isArray
} from "/node_modules/.cache/sb-vite/deps/chunk-7A7PZEIW.js?v=77221ebe";
import {
  require_isObjectLike
} from "/node_modules/.cache/sb-vite/deps/chunk-OHEVQGWM.js?v=77221ebe";
import {
  require_baseGetTag
} from "/node_modules/.cache/sb-vite/deps/chunk-TVITADQD.js?v=77221ebe";
import {
  __commonJS
} from "/node_modules/.cache/sb-vite/deps/chunk-LFBQMW2U.js?v=77221ebe";

// node_modules/lodash/isString.js
var require_isString = __commonJS({
  "node_modules/lodash/isString.js"(exports, module) {
    var baseGetTag = require_baseGetTag();
    var isArray = require_isArray();
    var isObjectLike = require_isObjectLike();
    var stringTag = "[object String]";
    function isString(value) {
      return typeof value == "string" || !isArray(value) && isObjectLike(value) && baseGetTag(value) == stringTag;
    }
    module.exports = isString;
  }
});

export {
  require_isString
};
//# sourceMappingURL=chunk-PRDOJXER.js.map
