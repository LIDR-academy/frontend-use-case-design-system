import {
  require_getNative
} from "/node_modules/.cache/sb-vite/deps/chunk-3UQ3EPPH.js?v=77221ebe";
import {
  require_root
} from "/node_modules/.cache/sb-vite/deps/chunk-TVITADQD.js?v=77221ebe";
import {
  __commonJS
} from "/node_modules/.cache/sb-vite/deps/chunk-LFBQMW2U.js?v=77221ebe";

// node_modules/lodash/_Set.js
var require_Set = __commonJS({
  "node_modules/lodash/_Set.js"(exports, module) {
    var getNative = require_getNative();
    var root = require_root();
    var Set = getNative(root, "Set");
    module.exports = Set;
  }
});

export {
  require_Set
};
//# sourceMappingURL=chunk-M3DRV55B.js.map
