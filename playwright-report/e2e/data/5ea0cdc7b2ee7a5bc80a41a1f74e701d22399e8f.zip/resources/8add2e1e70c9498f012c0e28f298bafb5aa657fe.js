import "/node_modules/.cache/sb-vite/deps/chunk-LFBQMW2U.js?v=77221ebe";

// node_modules/@storybook/addon-docs/dist/preview.mjs
var parameters = { docs: { renderer: async () => {
  let { DocsRenderer } = await import("/node_modules/.cache/sb-vite/deps/DocsRenderer-NNNQARDV-JPOHKHSX.js?v=77221ebe");
  return new DocsRenderer();
} } };
export {
  parameters
};
//# sourceMappingURL=@storybook_addon-essentials_docs_preview.js.map
