import { themes } from "/node_modules/.cache/sb-vite/deps/@storybook_theming.js?v=77221ebe";
import "/src/index.css?t=1762287146311";
const preview = {
  parameters: {
    actions: { argTypesRegex: "^on[A-Z].*" },
    controls: {
      matchers: {
        color: /(background|color)$/i,
        date: /Date$/i
      }
    },
    // Configuración para dark mode
    darkMode: {
      // Dark theme configuration
      dark: {
        ...themes.dark,
        appBg: "var(--color-background)",
        appContentBg: "var(--color-card)",
        barBg: "var(--color-card)"
      },
      // Light theme configuration
      light: {
        ...themes.normal,
        appBg: "var(--color-background)",
        appContentBg: "var(--color-card)",
        barBg: "var(--color-card)"
      },
      // Start with light mode
      current: "light",
      // Apply dark class to html element
      classTarget: "html",
      // Apply styles to preview iframe
      stylePreview: true
    },
    // Remove old background config since we're using dark mode addon
    a11y: {
      config: {
        rules: [
          {
            id: "color-contrast",
            enabled: true
          },
          {
            id: "heading-order",
            enabled: true
          }
        ]
      }
    }
  }
};
export default preview;

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInByZXZpZXcudHMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHR5cGUgeyBQcmV2aWV3IH0gZnJvbSAnQHN0b3J5Ym9vay9yZWFjdCc7XG5pbXBvcnQgeyB0aGVtZXMgfSBmcm9tICdAc3Rvcnlib29rL3RoZW1pbmcnO1xuXG4vLyBJbXBvcnRhciBlc3RpbG9zIGdsb2JhbGVzXG5pbXBvcnQgJy4uL3NyYy9pbmRleC5jc3MnO1xuXG5jb25zdCBwcmV2aWV3OiBQcmV2aWV3ID0ge1xuICBwYXJhbWV0ZXJzOiB7XG4gICAgYWN0aW9uczogeyBhcmdUeXBlc1JlZ2V4OiAnXm9uW0EtWl0uKicgfSxcbiAgICBjb250cm9sczoge1xuICAgICAgbWF0Y2hlcnM6IHtcbiAgICAgICAgY29sb3I6IC8oYmFja2dyb3VuZHxjb2xvcikkL2ksXG4gICAgICAgIGRhdGU6IC9EYXRlJC9pLFxuICAgICAgfSxcbiAgICB9LFxuICAgIC8vIENvbmZpZ3VyYWNpw7NuIHBhcmEgZGFyayBtb2RlXG4gICAgZGFya01vZGU6IHtcbiAgICAgIC8vIERhcmsgdGhlbWUgY29uZmlndXJhdGlvblxuICAgICAgZGFyazoge1xuICAgICAgICAuLi50aGVtZXMuZGFyayxcbiAgICAgICAgYXBwQmc6ICd2YXIoLS1jb2xvci1iYWNrZ3JvdW5kKScsXG4gICAgICAgIGFwcENvbnRlbnRCZzogJ3ZhcigtLWNvbG9yLWNhcmQpJyxcbiAgICAgICAgYmFyQmc6ICd2YXIoLS1jb2xvci1jYXJkKScsXG4gICAgICB9LFxuICAgICAgLy8gTGlnaHQgdGhlbWUgY29uZmlndXJhdGlvblxuICAgICAgbGlnaHQ6IHtcbiAgICAgICAgLi4udGhlbWVzLm5vcm1hbCxcbiAgICAgICAgYXBwQmc6ICd2YXIoLS1jb2xvci1iYWNrZ3JvdW5kKScsXG4gICAgICAgIGFwcENvbnRlbnRCZzogJ3ZhcigtLWNvbG9yLWNhcmQpJyxcbiAgICAgICAgYmFyQmc6ICd2YXIoLS1jb2xvci1jYXJkKScsXG4gICAgICB9LFxuICAgICAgLy8gU3RhcnQgd2l0aCBsaWdodCBtb2RlXG4gICAgICBjdXJyZW50OiAnbGlnaHQnLFxuICAgICAgLy8gQXBwbHkgZGFyayBjbGFzcyB0byBodG1sIGVsZW1lbnRcbiAgICAgIGNsYXNzVGFyZ2V0OiAnaHRtbCcsXG4gICAgICAvLyBBcHBseSBzdHlsZXMgdG8gcHJldmlldyBpZnJhbWVcbiAgICAgIHN0eWxlUHJldmlldzogdHJ1ZSxcbiAgICB9LFxuICAgIC8vIFJlbW92ZSBvbGQgYmFja2dyb3VuZCBjb25maWcgc2luY2Ugd2UncmUgdXNpbmcgZGFyayBtb2RlIGFkZG9uXG4gICAgYTExeToge1xuICAgICAgY29uZmlnOiB7XG4gICAgICAgIHJ1bGVzOiBbXG4gICAgICAgICAge1xuICAgICAgICAgICAgaWQ6ICdjb2xvci1jb250cmFzdCcsXG4gICAgICAgICAgICBlbmFibGVkOiB0cnVlLFxuICAgICAgICAgIH0sXG4gICAgICAgICAge1xuICAgICAgICAgICAgaWQ6ICdoZWFkaW5nLW9yZGVyJyxcbiAgICAgICAgICAgIGVuYWJsZWQ6IHRydWUsXG4gICAgICAgICAgfSxcbiAgICAgICAgXSxcbiAgICAgIH0sXG4gICAgfSxcbiAgfSxcbn07XG5cbmV4cG9ydCBkZWZhdWx0IHByZXZpZXc7XG4iXSwibWFwcGluZ3MiOiJBQUNBLFNBQVMsY0FBYztBQUd2QixPQUFPO0FBRVAsTUFBTSxVQUFtQjtBQUFBLEVBQ3ZCLFlBQVk7QUFBQSxJQUNWLFNBQVMsRUFBRSxlQUFlLGFBQWE7QUFBQSxJQUN2QyxVQUFVO0FBQUEsTUFDUixVQUFVO0FBQUEsUUFDUixPQUFPO0FBQUEsUUFDUCxNQUFNO0FBQUEsTUFDUjtBQUFBLElBQ0Y7QUFBQTtBQUFBLElBRUEsVUFBVTtBQUFBO0FBQUEsTUFFUixNQUFNO0FBQUEsUUFDSixHQUFHLE9BQU87QUFBQSxRQUNWLE9BQU87QUFBQSxRQUNQLGNBQWM7QUFBQSxRQUNkLE9BQU87QUFBQSxNQUNUO0FBQUE7QUFBQSxNQUVBLE9BQU87QUFBQSxRQUNMLEdBQUcsT0FBTztBQUFBLFFBQ1YsT0FBTztBQUFBLFFBQ1AsY0FBYztBQUFBLFFBQ2QsT0FBTztBQUFBLE1BQ1Q7QUFBQTtBQUFBLE1BRUEsU0FBUztBQUFBO0FBQUEsTUFFVCxhQUFhO0FBQUE7QUFBQSxNQUViLGNBQWM7QUFBQSxJQUNoQjtBQUFBO0FBQUEsSUFFQSxNQUFNO0FBQUEsTUFDSixRQUFRO0FBQUEsUUFDTixPQUFPO0FBQUEsVUFDTDtBQUFBLFlBQ0UsSUFBSTtBQUFBLFlBQ0osU0FBUztBQUFBLFVBQ1g7QUFBQSxVQUNBO0FBQUEsWUFDRSxJQUFJO0FBQUEsWUFDSixTQUFTO0FBQUEsVUFDWDtBQUFBLFFBQ0Y7QUFBQSxNQUNGO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUFDRjtBQUVBLGVBQWU7IiwibmFtZXMiOltdfQ==