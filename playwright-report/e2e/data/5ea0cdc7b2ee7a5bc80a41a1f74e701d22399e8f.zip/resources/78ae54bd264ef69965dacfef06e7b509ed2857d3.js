const importers = {
        './src/components/atoms/Button/Button.stories.tsx': async () => import("/src/components/atoms/Button/Button.stories.tsx"),
  './src/components/atoms/Icon/Icon.stories.tsx': async () => import("/src/components/atoms/Icon/Icon.stories.tsx"),
  './src/components/atoms/Input/Input.stories.tsx': async () => import("/src/components/atoms/Input/Input.stories.tsx"),
  './src/components/molecules/Card/Card.stories.tsx': async () => import("/src/components/molecules/Card/Card.stories.tsx"),
  './src/components/molecules/Tag/Tag.stories.tsx': async () => import("/src/components/molecules/Tag/Tag.stories.tsx")
    };

    export async function importFn(path) {
        return importers[path]();
    }