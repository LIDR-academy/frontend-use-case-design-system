import {
  require_baseFor
} from "/node_modules/.cache/sb-vite/deps/chunk-7POIP7KK.js?v=77221ebe";
import {
  require_keys
} from "/node_modules/.cache/sb-vite/deps/chunk-HXLB7MO4.js?v=77221ebe";
import {
  __commonJS
} from "/node_modules/.cache/sb-vite/deps/chunk-LFBQMW2U.js?v=77221ebe";

// node_modules/lodash/_baseForOwn.js
var require_baseForOwn = __commonJS({
  "node_modules/lodash/_baseForOwn.js"(exports, module) {
    var baseFor = require_baseFor();
    var keys = require_keys();
    function baseForOwn(object, iteratee) {
      return object && baseFor(object, iteratee, keys);
    }
    module.exports = baseForOwn;
  }
});

export {
  require_baseForOwn
};
//# sourceMappingURL=chunk-NQLFTTWR.js.map
