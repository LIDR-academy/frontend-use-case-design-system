import {
  require_baseForOwn
} from "/node_modules/.cache/sb-vite/deps/chunk-NQLFTTWR.js?v=77221ebe";
import {
  require_baseIteratee
} from "/node_modules/.cache/sb-vite/deps/chunk-C625UK6T.js?v=77221ebe";
import {
  require_baseAssignValue
} from "/node_modules/.cache/sb-vite/deps/chunk-ECLEY75Q.js?v=77221ebe";
import {
  __commonJS
} from "/node_modules/.cache/sb-vite/deps/chunk-LFBQMW2U.js?v=77221ebe";

// node_modules/lodash/mapValues.js
var require_mapValues = __commonJS({
  "node_modules/lodash/mapValues.js"(exports, module) {
    var baseAssignValue = require_baseAssignValue();
    var baseForOwn = require_baseForOwn();
    var baseIteratee = require_baseIteratee();
    function mapValues(object, iteratee) {
      var result = {};
      iteratee = baseIteratee(iteratee, 3);
      baseForOwn(object, function(value, key, object2) {
        baseAssignValue(result, key, iteratee(value, key, object2));
      });
      return result;
    }
    module.exports = mapValues;
  }
});

export {
  require_mapValues
};
//# sourceMappingURL=chunk-GOAAS6EN.js.map
