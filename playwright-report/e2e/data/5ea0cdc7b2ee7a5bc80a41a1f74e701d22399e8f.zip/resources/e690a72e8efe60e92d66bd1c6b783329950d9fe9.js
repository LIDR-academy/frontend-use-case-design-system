import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/molecules/Card/Card.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.cache/sb-vite/deps/react_jsx-dev-runtime.js?v=77221ebe"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
export const Card = ({
  children,
  title,
  subtitle,
  variant = "elevated",
  className = "",
  headerActions,
  onClick,
  ...props
}) => {
  const baseStyles = "rounded-lg transition-all duration-200";
  const variantStyles = {
    elevated: "bg-card text-card-foreground shadow-md hover:shadow-lg",
    outlined: "bg-card text-card-foreground border border-border",
    filled: "bg-muted text-muted-foreground"
  };
  const clickableStyles = onClick ? "cursor-pointer hover:scale-[1.02]" : "";
  return /* @__PURE__ */ jsxDEV(
    "div",
    {
      className: `${baseStyles} ${variantStyles[variant]} ${clickableStyles} ${className}`,
      onClick,
      role: onClick ? "button" : void 0,
      tabIndex: onClick ? 0 : void 0,
      onKeyDown: onClick ? (e) => {
        if (e.key === "Enter" || e.key === " ") {
          e.preventDefault();
          onClick();
        }
      } : void 0,
      ...props,
      children: [
        (title || headerActions) && /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between p-6 pb-0", children: [
          /* @__PURE__ */ jsxDEV("div", { children: [
            title && /* @__PURE__ */ jsxDEV("h3", { className: "text-lg font-semibold text-foreground", children: title }, void 0, false, {
              fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/molecules/Card/Card.tsx",
              lineNumber: 55,
              columnNumber: 11
            }, this),
            subtitle && /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-muted-foreground mt-1", children: subtitle }, void 0, false, {
              fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/molecules/Card/Card.tsx",
              lineNumber: 58,
              columnNumber: 11
            }, this)
          ] }, void 0, true, {
            fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/molecules/Card/Card.tsx",
            lineNumber: 53,
            columnNumber: 11
          }, this),
          headerActions && /* @__PURE__ */ jsxDEV("div", { className: "ml-4", children: headerActions }, void 0, false, {
            fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/molecules/Card/Card.tsx",
            lineNumber: 61,
            columnNumber: 29
          }, this)
        ] }, void 0, true, {
          fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/molecules/Card/Card.tsx",
          lineNumber: 52,
          columnNumber: 7
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "p-6", children }, void 0, false, {
          fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/molecules/Card/Card.tsx",
          lineNumber: 65,
          columnNumber: 7
        }, this)
      ]
    },
    void 0,
    true,
    {
      fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/molecules/Card/Card.tsx",
      lineNumber: 34,
      columnNumber: 5
    },
    this
  );
};
_c = Card;
var _c;
$RefreshReg$(_c, "Card");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/molecules/Card/Card.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/molecules/Card/Card.tsx", currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/molecules/Card/Card.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBc0RjO0FBMUNQLGFBQU1BLE9BQTRCQSxDQUFDO0FBQUEsRUFDeENDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDLFVBQVU7QUFBQSxFQUNWQyxZQUFZO0FBQUEsRUFDWkM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQSxHQUFHQztBQUNMLE1BQU07QUFDSixRQUFNQyxhQUFhO0FBRW5CLFFBQU1DLGdCQUFnQjtBQUFBLElBQ3BCQyxVQUFVO0FBQUEsSUFDVkMsVUFBVTtBQUFBLElBQ1ZDLFFBQVE7QUFBQSxFQUNWO0FBRUEsUUFBTUMsa0JBQWtCUCxVQUFVLHNDQUFzQztBQUV4RSxTQUNFO0FBQUEsSUFBQztBQUFBO0FBQUEsTUFDQyxXQUFXLEdBQUdFLGNBQWNDLGNBQWNOLE9BQU8sS0FBS1UsbUJBQW1CVDtBQUFBQSxNQUN6RTtBQUFBLE1BQ0EsTUFBTUUsVUFBVSxXQUFXUTtBQUFBQSxNQUMzQixVQUFVUixVQUFVLElBQUlRO0FBQUFBLE1BQ3hCLFdBQ0VSLFVBQ0ksQ0FBQ1MsTUFBTTtBQUNMLFlBQUlBLEVBQUVDLFFBQVEsV0FBV0QsRUFBRUMsUUFBUSxLQUFLO0FBQ3RDRCxZQUFFRSxlQUFlO0FBQ2pCWCxrQkFBUTtBQUFBLFFBQ1Y7QUFBQSxNQUNGLElBQ0FRO0FBQUFBLE1BRU4sR0FBSVA7QUFBQUEsTUFFRk47QUFBQUEsa0JBQVNJLGtCQUNULHVCQUFDLFNBQUksV0FBVSw4Q0FDYjtBQUFBLGlDQUFDLFNBQ0VKO0FBQUFBLHFCQUNDLHVCQUFDLFFBQUcsV0FBVSx5Q0FBeUNBLG1CQUF2RDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE2RDtBQUFBLFlBRTlEQyxZQUNDLHVCQUFDLE9BQUUsV0FBVSxzQ0FBc0NBLHNCQUFuRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE0RDtBQUFBLGVBTGhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBT0E7QUFBQSxVQUNDRyxpQkFBaUIsdUJBQUMsU0FBSSxXQUFVLFFBQVFBLDJCQUF2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFxQztBQUFBLGFBVHpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFVQTtBQUFBLFFBR0YsdUJBQUMsU0FBSSxXQUFVLE9BQU9MLFlBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBK0I7QUFBQTtBQUFBO0FBQUEsSUEvQmpDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQWdDQTtBQUVKO0FBQUVrQixLQXZEV25CO0FBQXlCLElBQUFtQjtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsiQ2FyZCIsImNoaWxkcmVuIiwidGl0bGUiLCJzdWJ0aXRsZSIsInZhcmlhbnQiLCJjbGFzc05hbWUiLCJoZWFkZXJBY3Rpb25zIiwib25DbGljayIsInByb3BzIiwiYmFzZVN0eWxlcyIsInZhcmlhbnRTdHlsZXMiLCJlbGV2YXRlZCIsIm91dGxpbmVkIiwiZmlsbGVkIiwiY2xpY2thYmxlU3R5bGVzIiwidW5kZWZpbmVkIiwiZSIsImtleSIsInByZXZlbnREZWZhdWx0IiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJDYXJkLnRzeCJdLCJmaWxlIjoiL2hvbWUvc3VuZGUvcHJvamVjdHMvTGlkci9mcm9udGVuZC11c2UtY2FzZS1kZXNpZ24tc3lzdGVtL3NyYy9jb21wb25lbnRzL21vbGVjdWxlcy9DYXJkL0NhcmQudHN4Iiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0IGZyb20gJ3JlYWN0JztcblxuZXhwb3J0IGludGVyZmFjZSBDYXJkUHJvcHMgZXh0ZW5kcyBSZWFjdC5IVE1MQXR0cmlidXRlczxIVE1MRGl2RWxlbWVudD4ge1xuICBjaGlsZHJlbjogUmVhY3QuUmVhY3ROb2RlO1xuICB0aXRsZT86IHN0cmluZztcbiAgc3VidGl0bGU/OiBzdHJpbmc7XG4gIHZhcmlhbnQ/OiAnZWxldmF0ZWQnIHwgJ291dGxpbmVkJyB8ICdmaWxsZWQnO1xuICBjbGFzc05hbWU/OiBzdHJpbmc7XG4gIGhlYWRlckFjdGlvbnM/OiBSZWFjdC5SZWFjdE5vZGU7XG4gIG9uQ2xpY2s/OiAoKSA9PiB2b2lkO1xufVxuXG5leHBvcnQgY29uc3QgQ2FyZDogUmVhY3QuRkM8Q2FyZFByb3BzPiA9ICh7XG4gIGNoaWxkcmVuLFxuICB0aXRsZSxcbiAgc3VidGl0bGUsXG4gIHZhcmlhbnQgPSAnZWxldmF0ZWQnLFxuICBjbGFzc05hbWUgPSAnJyxcbiAgaGVhZGVyQWN0aW9ucyxcbiAgb25DbGljayxcbiAgLi4ucHJvcHNcbn0pID0+IHtcbiAgY29uc3QgYmFzZVN0eWxlcyA9ICdyb3VuZGVkLWxnIHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTIwMCc7XG5cbiAgY29uc3QgdmFyaWFudFN0eWxlcyA9IHtcbiAgICBlbGV2YXRlZDogJ2JnLWNhcmQgdGV4dC1jYXJkLWZvcmVncm91bmQgc2hhZG93LW1kIGhvdmVyOnNoYWRvdy1sZycsXG4gICAgb3V0bGluZWQ6ICdiZy1jYXJkIHRleHQtY2FyZC1mb3JlZ3JvdW5kIGJvcmRlciBib3JkZXItYm9yZGVyJyxcbiAgICBmaWxsZWQ6ICdiZy1tdXRlZCB0ZXh0LW11dGVkLWZvcmVncm91bmQnLFxuICB9O1xuXG4gIGNvbnN0IGNsaWNrYWJsZVN0eWxlcyA9IG9uQ2xpY2sgPyAnY3Vyc29yLXBvaW50ZXIgaG92ZXI6c2NhbGUtWzEuMDJdJyA6ICcnO1xuXG4gIHJldHVybiAoXG4gICAgPGRpdlxuICAgICAgY2xhc3NOYW1lPXtgJHtiYXNlU3R5bGVzfSAke3ZhcmlhbnRTdHlsZXNbdmFyaWFudF19ICR7Y2xpY2thYmxlU3R5bGVzfSAke2NsYXNzTmFtZX1gfVxuICAgICAgb25DbGljaz17b25DbGlja31cbiAgICAgIHJvbGU9e29uQ2xpY2sgPyAnYnV0dG9uJyA6IHVuZGVmaW5lZH1cbiAgICAgIHRhYkluZGV4PXtvbkNsaWNrID8gMCA6IHVuZGVmaW5lZH1cbiAgICAgIG9uS2V5RG93bj17XG4gICAgICAgIG9uQ2xpY2tcbiAgICAgICAgICA/IChlKSA9PiB7XG4gICAgICAgICAgICAgIGlmIChlLmtleSA9PT0gJ0VudGVyJyB8fCBlLmtleSA9PT0gJyAnKSB7XG4gICAgICAgICAgICAgICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xuICAgICAgICAgICAgICAgIG9uQ2xpY2soKTtcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgIDogdW5kZWZpbmVkXG4gICAgICB9XG4gICAgICB7Li4ucHJvcHN9XG4gICAgPlxuICAgICAgeyh0aXRsZSB8fCBoZWFkZXJBY3Rpb25zKSAmJiAoXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIHAtNiBwYi0wXCI+XG4gICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgIHt0aXRsZSAmJiAoXG4gICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtc2VtaWJvbGQgdGV4dC1mb3JlZ3JvdW5kXCI+e3RpdGxlfTwvaDM+XG4gICAgICAgICAgICApfVxuICAgICAgICAgICAge3N1YnRpdGxlICYmIChcbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LW11dGVkLWZvcmVncm91bmQgbXQtMVwiPntzdWJ0aXRsZX08L3A+XG4gICAgICAgICAgICApfVxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIHtoZWFkZXJBY3Rpb25zICYmIDxkaXYgY2xhc3NOYW1lPVwibWwtNFwiPntoZWFkZXJBY3Rpb25zfTwvZGl2Pn1cbiAgICAgICAgPC9kaXY+XG4gICAgICApfVxuXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtNlwiPntjaGlsZHJlbn08L2Rpdj5cbiAgICA8L2Rpdj5cbiAgKTtcbn07XG4iXX0=