import {
  require_preview_api
} from "/node_modules/.cache/sb-vite/deps/chunk-GRPSGFCD.js?v=77221ebe";
import {
  require_global
} from "/node_modules/.cache/sb-vite/deps/chunk-ISPWXKZJ.js?v=77221ebe";
import {
  __toESM
} from "/node_modules/.cache/sb-vite/deps/chunk-LFBQMW2U.js?v=77221ebe";

// node_modules/@storybook/addon-a11y/dist/preview.js
var import_global = __toESM(require_global());
var import_preview_api = __toESM(require_preview_api());
var ADDON_ID = "storybook/a11y";
var RESULT = `${ADDON_ID}/result`;
var REQUEST = `${ADDON_ID}/request`;
var RUNNING = `${ADDON_ID}/running`;
var ERROR = `${ADDON_ID}/error`;
var MANUAL = `${ADDON_ID}/manual`;
var EVENTS = { RESULT, REQUEST, RUNNING, ERROR, MANUAL };
var { document, window: globalWindow } = import_global.global;
var channel = import_preview_api.addons.getChannel();
var active = false;
var activeStoryId;
var handleRequest = async (storyId) => {
  let { manual } = await getParams(storyId);
  manual || await run(storyId);
};
var run = async (storyId) => {
  activeStoryId = storyId;
  try {
    let input = await getParams(storyId);
    if (!active) {
      active = true, channel.emit(EVENTS.RUNNING);
      let axe = (await import('/node_modules/.cache/sb-vite/deps/axe-core.js?v=77221ebe').then(m => m.default && m.default.__esModule ? m.default : ({ ...m.default, default: m.default }))).default, { element = "#storybook-root", config, options = {} } = input, htmlElement = document.querySelector(element);
      if (!htmlElement)
        return;
      axe.reset(), config && axe.configure(config);
      let result = await axe.run(htmlElement, options), resultJson = JSON.parse(JSON.stringify(result));
      activeStoryId === storyId ? channel.emit(EVENTS.RESULT, resultJson) : (active = false, run(activeStoryId));
    }
  } catch (error) {
    channel.emit(EVENTS.ERROR, error);
  } finally {
    active = false;
  }
};
var getParams = async (storyId) => {
  let { parameters } = await globalWindow.__STORYBOOK_STORY_STORE__.loadStory({ storyId }) || {};
  return parameters.a11y || { config: {}, options: {} };
};
channel.on(EVENTS.REQUEST, handleRequest);
channel.on(EVENTS.MANUAL, run);
//# sourceMappingURL=@storybook_addon-a11y_preview.js.map
