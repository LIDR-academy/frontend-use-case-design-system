import {
  require_isObject
} from "/node_modules/.cache/sb-vite/deps/chunk-V6CYO66A.js?v=77221ebe";
import {
  require_baseGetTag
} from "/node_modules/.cache/sb-vite/deps/chunk-TVITADQD.js?v=77221ebe";
import {
  __commonJS
} from "/node_modules/.cache/sb-vite/deps/chunk-LFBQMW2U.js?v=77221ebe";

// node_modules/lodash/isFunction.js
var require_isFunction = __commonJS({
  "node_modules/lodash/isFunction.js"(exports, module) {
    var baseGetTag = require_baseGetTag();
    var isObject = require_isObject();
    var asyncTag = "[object AsyncFunction]";
    var funcTag = "[object Function]";
    var genTag = "[object GeneratorFunction]";
    var proxyTag = "[object Proxy]";
    function isFunction(value) {
      if (!isObject(value)) {
        return false;
      }
      var tag = baseGetTag(value);
      return tag == funcTag || tag == genTag || tag == asyncTag || tag == proxyTag;
    }
    module.exports = isFunction;
  }
});

export {
  require_isFunction
};
//# sourceMappingURL=chunk-IFA2HY3B.js.map
