import {
  require_client
} from "/node_modules/.cache/sb-vite/deps/chunk-3OCI4AVN.js?v=77221ebe";
import {
  require_react
} from "/node_modules/.cache/sb-vite/deps/chunk-OQ3OWAGM.js?v=77221ebe";
import {
  __toESM
} from "/node_modules/.cache/sb-vite/deps/chunk-LFBQMW2U.js?v=77221ebe";

// node_modules/@storybook/react-dom-shim/dist/react-18.mjs
var import_react = __toESM(require_react(), 1);
var import_client = __toESM(require_client(), 1);
var nodes = /* @__PURE__ */ new Map();
var WithCallback = ({ callback, children }) => {
  let once = (0, import_react.useRef)();
  return (0, import_react.useLayoutEffect)(() => {
    once.current !== callback && (once.current = callback, callback());
  }, [callback]), children;
};
var renderElement = async (node, el) => {
  let root = await getReactRoot(el);
  return new Promise((resolve) => {
    root.render(import_react.default.createElement(WithCallback, { callback: () => resolve(null) }, node));
  });
};
var unmountElement = (el, shouldUseNewRootApi) => {
  let root = nodes.get(el);
  root && (root.unmount(), nodes.delete(el));
};
var getReactRoot = async (el) => {
  let root = nodes.get(el);
  return root || (root = import_client.default.createRoot(el), nodes.set(el, root)), root;
};

export {
  renderElement,
  unmountElement
};
//# sourceMappingURL=chunk-W76KQCFG.js.map
