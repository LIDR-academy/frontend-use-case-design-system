import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.cache/sb-vite/deps/react_jsx-dev-runtime.js?v=77221ebe"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import { userEvent, within, expect } from "/node_modules/.cache/sb-vite/deps/@storybook_test.js?v=77221ebe";
import { Card } from "/src/components/molecules/Card/Card.tsx";
const meta = {
  title: "Molecules/Card",
  component: Card,
  parameters: {
    layout: "centered",
    docs: {
      description: {
        component: "Componente Card flexible para mostrar contenido agrupado con diferentes variantes y estados."
      }
    },
    a11y: {
      config: {
        rules: [{
          id: "color-contrast",
          enabled: true
        }, {
          id: "heading-order",
          enabled: true
        }]
      }
    }
  },
  argTypes: {
    variant: {
      control: {
        type: "select"
      },
      options: ["elevated", "outlined", "filled"],
      description: "Estilo visual de la card"
    },
    title: {
      control: "text",
      description: "Título principal de la card"
    },
    subtitle: {
      control: "text",
      description: "Subtítulo o descripción adicional"
    },
    children: {
      control: "text",
      description: "Contenido principal de la card"
    },
    className: {
      control: "text",
      description: "Clases CSS adicionales"
    },
    onClick: {
      action: "clicked",
      description: "Función que se ejecuta al hacer click (hace la card interactiva)"
    },
    headerActions: {
      control: false,
      description: "Elementos de acción en el header (botones, iconos, etc.)"
    }
  },
  tags: ["autodocs"]
};
export default meta;
export const Default = {
  args: {
    children: "Esta es una card básica con contenido simple."
  },
  parameters: {
    docs: {
      description: {
        story: "Card por defecto con variante elevated y contenido básico."
      }
    }
  }
};
export const WithTitle = {
  args: {
    title: "Título de la Card",
    children: "Esta card tiene un título en el header."
  },
  parameters: {
    docs: {
      description: {
        story: "Card con título en el header."
      }
    }
  }
};
export const WithTitleAndSubtitle = {
  args: {
    title: "Título Principal",
    subtitle: "Subtítulo descriptivo",
    children: "Esta card tiene tanto título como subtítulo."
  },
  parameters: {
    docs: {
      description: {
        story: "Card con título y subtítulo en el header."
      }
    }
  }
};
export const WithHeaderActions = {
  args: {
    title: "Card con Acciones",
    headerActions: /* @__PURE__ */jsxDEV("div", {
      className: "flex gap-2",
      children: [/* @__PURE__ */jsxDEV("button", {
        className: "px-3 py-1 text-sm bg-blue-500 text-white rounded",
        children: "Editar"
      }, void 0, false, {
        fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/molecules/Card/Card.stories.tsx",
        lineNumber: 118,
        columnNumber: 9
      }, this), /* @__PURE__ */jsxDEV("button", {
        className: "px-3 py-1 text-sm border border-gray-300 rounded",
        children: "Más"
      }, void 0, false, {
        fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/molecules/Card/Card.stories.tsx",
        lineNumber: 121,
        columnNumber: 9
      }, this)]
    }, void 0, true, {
      fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/molecules/Card/Card.stories.tsx",
      lineNumber: 117,
      columnNumber: 5
    }, this),
    children: "Esta card tiene botones de acción en el header."
  },
  parameters: {
    docs: {
      description: {
        story: "Card con elementos de acción en el header."
      }
    }
  }
};
export const Elevated = {
  args: {
    variant: "elevated",
    title: "Card Elevated",
    children: "Esta card usa la variante elevated con sombra."
  },
  parameters: {
    docs: {
      description: {
        story: "Variante elevated con sombra para destacar el contenido."
      }
    }
  }
};
export const Outlined = {
  args: {
    variant: "outlined",
    title: "Card Outlined",
    children: "Esta card usa la variante outlined con borde."
  },
  parameters: {
    docs: {
      description: {
        story: "Variante outlined con borde sutil."
      }
    }
  }
};
export const Filled = {
  args: {
    variant: "filled",
    title: "Card Filled",
    children: "Esta card usa la variante filled con fondo coloreado."
  },
  parameters: {
    docs: {
      description: {
        story: "Variante filled con fondo de color diferenciado."
      }
    }
  }
};
export const Clickable = {
  args: {
    title: "Card Interactiva",
    children: "Esta card es clickeable. Prueba hacer click en ella.",
    onClick: () => {}
  },
  parameters: {
    docs: {
      description: {
        story: "Card interactiva que responde a clicks y navegación por teclado."
      }
    }
  }
};
export const ComplexContent = {
  args: {
    title: "Producto Premium",
    subtitle: "Categoría: Electrónicos",
    headerActions: /* @__PURE__ */jsxDEV("span", {
      className: "px-2 py-1 text-xs bg-green-100 text-green-800 rounded-full",
      children: "En stock"
    }, void 0, false, {
      fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/molecules/Card/Card.stories.tsx",
      lineNumber: 206,
      columnNumber: 5
    }, this),
    children: /* @__PURE__ */jsxDEV("div", {
      className: "space-y-4",
      children: [/* @__PURE__ */jsxDEV("img", {
        src: "https://via.placeholder.com/300x200/e2e8f0/64748b?text=Producto",
        alt: "Producto",
        className: "w-full h-32 object-cover rounded"
      }, void 0, false, {
        fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/molecules/Card/Card.stories.tsx",
        lineNumber: 212,
        columnNumber: 9
      }, this), /* @__PURE__ */jsxDEV("p", {
        className: "text-gray-600",
        children: "Descripción detallada del producto con múltiples características y beneficios que lo hacen único en el mercado."
      }, void 0, false, {
        fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/molecules/Card/Card.stories.tsx",
        lineNumber: 217,
        columnNumber: 9
      }, this), /* @__PURE__ */jsxDEV("div", {
        className: "flex justify-between items-center",
        children: [/* @__PURE__ */jsxDEV("span", {
          className: "text-2xl font-bold text-blue-600",
          children: "$299.99"
        }, void 0, false, {
          fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/molecules/Card/Card.stories.tsx",
          lineNumber: 222,
          columnNumber: 11
        }, this), /* @__PURE__ */jsxDEV("button", {
          className: "px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600",
          children: "Añadir al carrito"
        }, void 0, false, {
          fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/molecules/Card/Card.stories.tsx",
          lineNumber: 223,
          columnNumber: 11
        }, this)]
      }, void 0, true, {
        fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/molecules/Card/Card.stories.tsx",
        lineNumber: 221,
        columnNumber: 9
      }, this)]
    }, void 0, true, {
      fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/molecules/Card/Card.stories.tsx",
      lineNumber: 211,
      columnNumber: 5
    }, this)
  },
  parameters: {
    docs: {
      description: {
        story: "Ejemplo de card con contenido complejo: imagen, texto, precio y botón."
      }
    }
  }
};
export const InfoCard = {
  args: {
    title: "Información del Sistema",
    variant: "filled",
    children: /* @__PURE__ */jsxDEV("div", {
      className: "space-y-3",
      children: [/* @__PURE__ */jsxDEV("div", {
        className: "flex justify-between",
        children: [/* @__PURE__ */jsxDEV("span", {
          className: "font-medium",
          children: "Versión:"
        }, void 0, false, {
          fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/molecules/Card/Card.stories.tsx",
          lineNumber: 247,
          columnNumber: 11
        }, this), /* @__PURE__ */jsxDEV("span", {
          children: "v2.1.0"
        }, void 0, false, {
          fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/molecules/Card/Card.stories.tsx",
          lineNumber: 248,
          columnNumber: 11
        }, this)]
      }, void 0, true, {
        fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/molecules/Card/Card.stories.tsx",
        lineNumber: 246,
        columnNumber: 9
      }, this), /* @__PURE__ */jsxDEV("div", {
        className: "flex justify-between",
        children: [/* @__PURE__ */jsxDEV("span", {
          className: "font-medium",
          children: "Estado:"
        }, void 0, false, {
          fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/molecules/Card/Card.stories.tsx",
          lineNumber: 251,
          columnNumber: 11
        }, this), /* @__PURE__ */jsxDEV("span", {
          className: "text-green-600",
          children: "Activo"
        }, void 0, false, {
          fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/molecules/Card/Card.stories.tsx",
          lineNumber: 252,
          columnNumber: 11
        }, this)]
      }, void 0, true, {
        fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/molecules/Card/Card.stories.tsx",
        lineNumber: 250,
        columnNumber: 9
      }, this), /* @__PURE__ */jsxDEV("div", {
        className: "flex justify-between",
        children: [/* @__PURE__ */jsxDEV("span", {
          className: "font-medium",
          children: "Último backup:"
        }, void 0, false, {
          fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/molecules/Card/Card.stories.tsx",
          lineNumber: 255,
          columnNumber: 11
        }, this), /* @__PURE__ */jsxDEV("span", {
          children: "Hace 2 horas"
        }, void 0, false, {
          fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/molecules/Card/Card.stories.tsx",
          lineNumber: 256,
          columnNumber: 11
        }, this)]
      }, void 0, true, {
        fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/molecules/Card/Card.stories.tsx",
        lineNumber: 254,
        columnNumber: 9
      }, this)]
    }, void 0, true, {
      fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/molecules/Card/Card.stories.tsx",
      lineNumber: 245,
      columnNumber: 5
    }, this)
  },
  parameters: {
    docs: {
      description: {
        story: "Card de información con datos estructurados."
      }
    }
  }
};
export const ClickInteraction = {
  args: {
    title: "Test de Interacción",
    children: "Click me para probar la interactividad!",
    onClick: () => {}
  },
  play: async ({
    canvasElement
  }) => {
    const canvas = within(canvasElement);
    const card = canvas.getByRole("button");
    await expect(card).toBeInTheDocument();
    await expect(card).toHaveAttribute("tabIndex", "0");
    await userEvent.click(card);
  },
  parameters: {
    docs: {
      description: {
        story: "Demostración de interaction testing con play function."
      }
    }
  }
};
export const LongContent = {
  args: {
    title: "Card con Contenido Extenso",
    children: /* @__PURE__ */jsxDEV("div", {
      className: "space-y-4",
      children: [/* @__PURE__ */jsxDEV("p", {
        children: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat."
      }, void 0, false, {
        fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/molecules/Card/Card.stories.tsx",
        lineNumber: 303,
        columnNumber: 9
      }, this), /* @__PURE__ */jsxDEV("p", {
        children: "Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum."
      }, void 0, false, {
        fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/molecules/Card/Card.stories.tsx",
        lineNumber: 309,
        columnNumber: 9
      }, this), /* @__PURE__ */jsxDEV("div", {
        className: "border-t pt-4",
        children: /* @__PURE__ */jsxDEV("button", {
          className: "w-full py-2 text-blue-600 hover:text-blue-800",
          children: "Leer más..."
        }, void 0, false, {
          fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/molecules/Card/Card.stories.tsx",
          lineNumber: 316,
          columnNumber: 11
        }, this)
      }, void 0, false, {
        fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/molecules/Card/Card.stories.tsx",
        lineNumber: 315,
        columnNumber: 9
      }, this)]
    }, void 0, true, {
      fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/molecules/Card/Card.stories.tsx",
      lineNumber: 302,
      columnNumber: 5
    }, this)
  },
  parameters: {
    docs: {
      description: {
        story: "Card con contenido extenso que demuestra el manejo de espaciado."
      }
    }
  }
};
export const MinimalCard = {
  args: {
    variant: "outlined",
    children: /* @__PURE__ */jsxDEV("div", {
      className: "text-center py-8",
      children: [/* @__PURE__ */jsxDEV("div", {
        className: "text-4xl mb-2",
        children: "📋"
      }, void 0, false, {
        fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/molecules/Card/Card.stories.tsx",
        lineNumber: 338,
        columnNumber: 9
      }, this), /* @__PURE__ */jsxDEV("p", {
        className: "text-gray-500",
        children: "Sin contenido"
      }, void 0, false, {
        fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/molecules/Card/Card.stories.tsx",
        lineNumber: 339,
        columnNumber: 9
      }, this)]
    }, void 0, true, {
      fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/molecules/Card/Card.stories.tsx",
      lineNumber: 337,
      columnNumber: 5
    }, this)
  },
  parameters: {
    docs: {
      description: {
        story: "Card minimalista sin título, ideal para estados vacíos."
      }
    }
  }
};
Default.parameters = {
  ...Default.parameters,
  docs: {
    ...Default.parameters?.docs,
    source: {
      originalSource: "{\n  args: {\n    children: 'Esta es una card b\xE1sica con contenido simple.'\n  },\n  parameters: {\n    docs: {\n      description: {\n        story: 'Card por defecto con variante elevated y contenido b\xE1sico.'\n      }\n    }\n  }\n}",
      ...Default.parameters?.docs?.source
    }
  }
};
WithTitle.parameters = {
  ...WithTitle.parameters,
  docs: {
    ...WithTitle.parameters?.docs,
    source: {
      originalSource: "{\n  args: {\n    title: 'T\xEDtulo de la Card',\n    children: 'Esta card tiene un t\xEDtulo en el header.'\n  },\n  parameters: {\n    docs: {\n      description: {\n        story: 'Card con t\xEDtulo en el header.'\n      }\n    }\n  }\n}",
      ...WithTitle.parameters?.docs?.source
    }
  }
};
WithTitleAndSubtitle.parameters = {
  ...WithTitleAndSubtitle.parameters,
  docs: {
    ...WithTitleAndSubtitle.parameters?.docs,
    source: {
      originalSource: "{\n  args: {\n    title: 'T\xEDtulo Principal',\n    subtitle: 'Subt\xEDtulo descriptivo',\n    children: 'Esta card tiene tanto t\xEDtulo como subt\xEDtulo.'\n  },\n  parameters: {\n    docs: {\n      description: {\n        story: 'Card con t\xEDtulo y subt\xEDtulo en el header.'\n      }\n    }\n  }\n}",
      ...WithTitleAndSubtitle.parameters?.docs?.source
    }
  }
};
WithHeaderActions.parameters = {
  ...WithHeaderActions.parameters,
  docs: {
    ...WithHeaderActions.parameters?.docs,
    source: {
      originalSource: "{\n  args: {\n    title: 'Card con Acciones',\n    headerActions: <div className=\"flex gap-2\">\n        <button className=\"px-3 py-1 text-sm bg-blue-500 text-white rounded\">\n          Editar\n        </button>\n        <button className=\"px-3 py-1 text-sm border border-gray-300 rounded\">\n          M\xE1s\n        </button>\n      </div>,\n    children: 'Esta card tiene botones de acci\xF3n en el header.'\n  },\n  parameters: {\n    docs: {\n      description: {\n        story: 'Card con elementos de acci\xF3n en el header.'\n      }\n    }\n  }\n}",
      ...WithHeaderActions.parameters?.docs?.source
    }
  }
};
Elevated.parameters = {
  ...Elevated.parameters,
  docs: {
    ...Elevated.parameters?.docs,
    source: {
      originalSource: "{\n  args: {\n    variant: 'elevated',\n    title: 'Card Elevated',\n    children: 'Esta card usa la variante elevated con sombra.'\n  },\n  parameters: {\n    docs: {\n      description: {\n        story: 'Variante elevated con sombra para destacar el contenido.'\n      }\n    }\n  }\n}",
      ...Elevated.parameters?.docs?.source
    }
  }
};
Outlined.parameters = {
  ...Outlined.parameters,
  docs: {
    ...Outlined.parameters?.docs,
    source: {
      originalSource: "{\n  args: {\n    variant: 'outlined',\n    title: 'Card Outlined',\n    children: 'Esta card usa la variante outlined con borde.'\n  },\n  parameters: {\n    docs: {\n      description: {\n        story: 'Variante outlined con borde sutil.'\n      }\n    }\n  }\n}",
      ...Outlined.parameters?.docs?.source
    }
  }
};
Filled.parameters = {
  ...Filled.parameters,
  docs: {
    ...Filled.parameters?.docs,
    source: {
      originalSource: "{\n  args: {\n    variant: 'filled',\n    title: 'Card Filled',\n    children: 'Esta card usa la variante filled con fondo coloreado.'\n  },\n  parameters: {\n    docs: {\n      description: {\n        story: 'Variante filled con fondo de color diferenciado.'\n      }\n    }\n  }\n}",
      ...Filled.parameters?.docs?.source
    }
  }
};
Clickable.parameters = {
  ...Clickable.parameters,
  docs: {
    ...Clickable.parameters?.docs,
    source: {
      originalSource: "{\n  args: {\n    title: 'Card Interactiva',\n    children: 'Esta card es clickeable. Prueba hacer click en ella.',\n    onClick: () => {}\n  },\n  parameters: {\n    docs: {\n      description: {\n        story: 'Card interactiva que responde a clicks y navegaci\xF3n por teclado.'\n      }\n    }\n  }\n}",
      ...Clickable.parameters?.docs?.source
    }
  }
};
ComplexContent.parameters = {
  ...ComplexContent.parameters,
  docs: {
    ...ComplexContent.parameters?.docs,
    source: {
      originalSource: "{\n  args: {\n    title: 'Producto Premium',\n    subtitle: 'Categor\xEDa: Electr\xF3nicos',\n    headerActions: <span className=\"px-2 py-1 text-xs bg-green-100 text-green-800 rounded-full\">\n        En stock\n      </span>,\n    children: <div className=\"space-y-4\">\n        <img src=\"https://via.placeholder.com/300x200/e2e8f0/64748b?text=Producto\" alt=\"Producto\" className=\"w-full h-32 object-cover rounded\" />\n        <p className=\"text-gray-600\">\n          Descripci\xF3n detallada del producto con m\xFAltiples caracter\xEDsticas y\n          beneficios que lo hacen \xFAnico en el mercado.\n        </p>\n        <div className=\"flex justify-between items-center\">\n          <span className=\"text-2xl font-bold text-blue-600\">$299.99</span>\n          <button className=\"px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600\">\n            A\xF1adir al carrito\n          </button>\n        </div>\n      </div>\n  },\n  parameters: {\n    docs: {\n      description: {\n        story: 'Ejemplo de card con contenido complejo: imagen, texto, precio y bot\xF3n.'\n      }\n    }\n  }\n}",
      ...ComplexContent.parameters?.docs?.source
    }
  }
};
InfoCard.parameters = {
  ...InfoCard.parameters,
  docs: {
    ...InfoCard.parameters?.docs,
    source: {
      originalSource: "{\n  args: {\n    title: 'Informaci\xF3n del Sistema',\n    variant: 'filled',\n    children: <div className=\"space-y-3\">\n        <div className=\"flex justify-between\">\n          <span className=\"font-medium\">Versi\xF3n:</span>\n          <span>v2.1.0</span>\n        </div>\n        <div className=\"flex justify-between\">\n          <span className=\"font-medium\">Estado:</span>\n          <span className=\"text-green-600\">Activo</span>\n        </div>\n        <div className=\"flex justify-between\">\n          <span className=\"font-medium\">\xDAltimo backup:</span>\n          <span>Hace 2 horas</span>\n        </div>\n      </div>\n  },\n  parameters: {\n    docs: {\n      description: {\n        story: 'Card de informaci\xF3n con datos estructurados.'\n      }\n    }\n  }\n}",
      ...InfoCard.parameters?.docs?.source
    }
  }
};
ClickInteraction.parameters = {
  ...ClickInteraction.parameters,
  docs: {
    ...ClickInteraction.parameters?.docs,
    source: {
      originalSource: "{\n  args: {\n    title: 'Test de Interacci\xF3n',\n    children: 'Click me para probar la interactividad!',\n    onClick: () => {}\n  },\n  play: async ({\n    canvasElement\n  }) => {\n    const canvas = within(canvasElement);\n    const card = canvas.getByRole('button');\n\n    // Verificar que la card es clickeable\n    await expect(card).toBeInTheDocument();\n    await expect(card).toHaveAttribute('tabIndex', '0');\n\n    // Simular click\n    await userEvent.click(card);\n  },\n  parameters: {\n    docs: {\n      description: {\n        story: 'Demostraci\xF3n de interaction testing con play function.'\n      }\n    }\n  }\n}",
      ...ClickInteraction.parameters?.docs?.source
    }
  }
};
LongContent.parameters = {
  ...LongContent.parameters,
  docs: {
    ...LongContent.parameters?.docs,
    source: {
      originalSource: "{\n  args: {\n    title: 'Card con Contenido Extenso',\n    children: <div className=\"space-y-4\">\n        <p>\n          Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do\n          eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad\n          minim veniam, quis nostrud exercitation ullamco laboris nisi ut\n          aliquip ex ea commodo consequat.\n        </p>\n        <p>\n          Duis aute irure dolor in reprehenderit in voluptate velit esse cillum\n          dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non\n          proident, sunt in culpa qui officia deserunt mollit anim id est\n          laborum.\n        </p>\n        <div className=\"border-t pt-4\">\n          <button className=\"w-full py-2 text-blue-600 hover:text-blue-800\">\n            Leer m\xE1s...\n          </button>\n        </div>\n      </div>\n  },\n  parameters: {\n    docs: {\n      description: {\n        story: 'Card con contenido extenso que demuestra el manejo de espaciado.'\n      }\n    }\n  }\n}",
      ...LongContent.parameters?.docs?.source
    }
  }
};
MinimalCard.parameters = {
  ...MinimalCard.parameters,
  docs: {
    ...MinimalCard.parameters?.docs,
    source: {
      originalSource: "{\n  args: {\n    variant: 'outlined',\n    children: <div className=\"text-center py-8\">\n        <div className=\"text-4xl mb-2\">\uD83D\uDCCB</div>\n        <p className=\"text-gray-500\">Sin contenido</p>\n      </div>\n  },\n  parameters: {\n    docs: {\n      description: {\n        story: 'Card minimalista sin t\xEDtulo, ideal para estados vac\xEDos.'\n      }\n    }\n  }\n}",
      ...MinimalCard.parameters?.docs?.source
    }
  }
};;export const __namedExportsOrder = ["Default","WithTitle","WithTitleAndSubtitle","WithHeaderActions","Elevated","Outlined","Filled","Clickable","ComplexContent","InfoCard","ClickInteraction","LongContent","MinimalCard"];