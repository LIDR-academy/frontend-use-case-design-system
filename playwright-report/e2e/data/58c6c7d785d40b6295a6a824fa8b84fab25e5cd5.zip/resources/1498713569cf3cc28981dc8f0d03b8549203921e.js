import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.cache/sb-vite/deps/react_jsx-dev-runtime.js?v=77221ebe"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import { Icon } from "/src/components/atoms/Icon/Icon.tsx";
const meta = {
  title: "Atoms/Icon",
  component: Icon,
  parameters: {
    layout: "centered",
    docs: {
      description: {
        component: "Componente Icon para mostrar iconos SVG con diferentes tamaños y colores usando semantic tokens."
      }
    },
    a11y: {
      config: {
        rules: [{
          id: "color-contrast",
          enabled: true
        }]
      }
    }
  },
  argTypes: {
    name: {
      control: {
        type: "select"
      },
      options: ["leaf", "accessibility", "x", "handshake", "arrow-left"],
      description: "Nombre del icono a mostrar"
    },
    size: {
      control: {
        type: "select"
      },
      options: ["xs", "sm", "md", "lg", "xl"],
      description: "Tamaño del icono"
    },
    color: {
      control: {
        type: "select"
      },
      options: ["primary", "secondary", "muted", "destructive", "foreground"],
      description: "Color del icono usando semantic tokens (modo estático)"
    },
    colorVariant: {
      control: {
        type: "select"
      },
      options: ["primary", "secondary", "tertiary"],
      description: "Variante de color para modo interactivo"
    },
    state: {
      control: {
        type: "select"
      },
      options: ["default", "hover", "focus", "disabled"],
      description: "Estado controlado del icono"
    },
    interactive: {
      control: {
        type: "boolean"
      },
      description: "Habilitar estados interactivos"
    },
    disabled: {
      control: {
        type: "boolean"
      },
      description: "Deshabilitar el icono"
    }
  },
  tags: ["autodocs"]
};
export default meta;
export const Leaf = {
  args: {
    name: "leaf"
  },
  parameters: {
    docs: {
      description: {
        story: "Icono de hoja - representa naturaleza, sostenibilidad"
      }
    }
  }
};
export const Accessibility = {
  args: {
    name: "accessibility"
  },
  parameters: {
    docs: {
      description: {
        story: "Icono de accesibilidad - representa inclusión y diseño universal"
      }
    }
  }
};
export const X = {
  args: {
    name: "x"
  },
  parameters: {
    docs: {
      description: {
        story: "Icono X - representa cerrar, cancelar o eliminar"
      }
    }
  }
};
export const Handshake = {
  args: {
    name: "handshake"
  },
  parameters: {
    docs: {
      description: {
        story: "Icono de handshake - representa colaboración, acuerdo, partnership"
      }
    }
  }
};
export const ArrowLeft = {
  args: {
    name: "arrow-left"
  },
  parameters: {
    docs: {
      description: {
        story: "Icono de flecha izquierda - representa volver, anterior, navegación"
      }
    }
  }
};
export const ExtraSmall = {
  args: {
    name: "leaf",
    size: "xs"
  },
  parameters: {
    docs: {
      description: {
        story: "Tamaño extra pequeño (12px) - para uso en elementos muy compactos"
      }
    }
  }
};
export const Small = {
  args: {
    name: "leaf",
    size: "sm"
  },
  parameters: {
    docs: {
      description: {
        story: "Tamaño pequeño (16px) - para uso en texto o botones pequeños"
      }
    }
  }
};
export const Medium = {
  args: {
    name: "leaf",
    size: "md"
  },
  parameters: {
    docs: {
      description: {
        story: "Tamaño mediano (24px) - tamaño por defecto para uso general"
      }
    }
  }
};
export const Large = {
  args: {
    name: "leaf",
    size: "lg"
  },
  parameters: {
    docs: {
      description: {
        story: "Tamaño grande (32px) - para elementos destacados"
      }
    }
  }
};
export const ExtraLarge = {
  args: {
    name: "leaf",
    size: "xl"
  },
  parameters: {
    docs: {
      description: {
        story: "Tamaño extra grande (40px) - para uso decorativo o headers"
      }
    }
  }
};
export const Primary = {
  args: {
    name: "accessibility",
    color: "primary"
  },
  parameters: {
    docs: {
      description: {
        story: "Color primario - para iconos principales e importantes"
      }
    }
  }
};
export const Secondary = {
  args: {
    name: "accessibility",
    color: "secondary"
  },
  parameters: {
    docs: {
      description: {
        story: "Color secundario - para iconos de apoyo"
      }
    }
  }
};
export const Muted = {
  args: {
    name: "accessibility",
    color: "muted"
  },
  parameters: {
    docs: {
      description: {
        story: "Color apagado - para iconos decorativos o de baja prioridad"
      }
    }
  }
};
export const Destructive = {
  args: {
    name: "accessibility",
    color: "destructive"
  },
  parameters: {
    docs: {
      description: {
        story: "Color destructivo - para acciones peligrosas o errores"
      }
    }
  }
};
export const InteractivePrimary = {
  args: {
    name: "leaf",
    interactive: true,
    colorVariant: "primary"
  },
  parameters: {
    docs: {
      description: {
        story: "Icono interactivo con variante primary - hover sobre el icono para ver el efecto"
      }
    }
  }
};
export const InteractiveSecondary = {
  args: {
    name: "accessibility",
    interactive: true,
    colorVariant: "secondary"
  },
  parameters: {
    docs: {
      description: {
        story: "Icono interactivo con variante secondary"
      }
    }
  }
};
export const InteractiveTertiary = {
  args: {
    name: "handshake",
    interactive: true,
    colorVariant: "tertiary"
  },
  parameters: {
    docs: {
      description: {
        story: "Icono interactivo con variante tertiary"
      }
    }
  }
};
export const DisabledInteractive = {
  args: {
    name: "x",
    interactive: true,
    disabled: true,
    colorVariant: "primary"
  },
  parameters: {
    docs: {
      description: {
        story: "Icono interactivo deshabilitado"
      }
    }
  }
};
export const ControlledStates = {
  render: () => /* @__PURE__ */jsxDEV("div", {
    className: "space-y-6",
    children: [/* @__PURE__ */jsxDEV("div", {
      children: [/* @__PURE__ */jsxDEV("h3", {
        className: "text-lg font-semibold mb-3",
        children: "Estados Primary"
      }, void 0, false, {
        fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/atoms/Icon/Icon.stories.tsx",
        lineNumber: 334,
        columnNumber: 9
      }, this), /* @__PURE__ */jsxDEV("div", {
        className: "flex items-center gap-4",
        children: [/* @__PURE__ */jsxDEV("div", {
          className: "text-center",
          children: [/* @__PURE__ */jsxDEV(Icon, {
            name: "leaf",
            interactive: true,
            colorVariant: "primary",
            state: "default"
          }, void 0, false, {
            fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/atoms/Icon/Icon.stories.tsx",
            lineNumber: 337,
            columnNumber: 13
          }, this), /* @__PURE__ */jsxDEV("div", {
            className: "text-xs mt-1",
            children: "Default"
          }, void 0, false, {
            fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/atoms/Icon/Icon.stories.tsx",
            lineNumber: 343,
            columnNumber: 13
          }, this)]
        }, void 0, true, {
          fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/atoms/Icon/Icon.stories.tsx",
          lineNumber: 336,
          columnNumber: 11
        }, this), /* @__PURE__ */jsxDEV("div", {
          className: "text-center",
          children: [/* @__PURE__ */jsxDEV(Icon, {
            name: "leaf",
            interactive: true,
            colorVariant: "primary",
            state: "hover"
          }, void 0, false, {
            fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/atoms/Icon/Icon.stories.tsx",
            lineNumber: 346,
            columnNumber: 13
          }, this), /* @__PURE__ */jsxDEV("div", {
            className: "text-xs mt-1",
            children: "Hover"
          }, void 0, false, {
            fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/atoms/Icon/Icon.stories.tsx",
            lineNumber: 352,
            columnNumber: 13
          }, this)]
        }, void 0, true, {
          fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/atoms/Icon/Icon.stories.tsx",
          lineNumber: 345,
          columnNumber: 11
        }, this), /* @__PURE__ */jsxDEV("div", {
          className: "text-center",
          children: [/* @__PURE__ */jsxDEV(Icon, {
            name: "leaf",
            interactive: true,
            colorVariant: "primary",
            state: "focus"
          }, void 0, false, {
            fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/atoms/Icon/Icon.stories.tsx",
            lineNumber: 355,
            columnNumber: 13
          }, this), /* @__PURE__ */jsxDEV("div", {
            className: "text-xs mt-1",
            children: "Focus"
          }, void 0, false, {
            fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/atoms/Icon/Icon.stories.tsx",
            lineNumber: 361,
            columnNumber: 13
          }, this)]
        }, void 0, true, {
          fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/atoms/Icon/Icon.stories.tsx",
          lineNumber: 354,
          columnNumber: 11
        }, this), /* @__PURE__ */jsxDEV("div", {
          className: "text-center",
          children: [/* @__PURE__ */jsxDEV(Icon, {
            name: "leaf",
            interactive: true,
            colorVariant: "primary",
            state: "disabled"
          }, void 0, false, {
            fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/atoms/Icon/Icon.stories.tsx",
            lineNumber: 364,
            columnNumber: 13
          }, this), /* @__PURE__ */jsxDEV("div", {
            className: "text-xs mt-1",
            children: "Disabled"
          }, void 0, false, {
            fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/atoms/Icon/Icon.stories.tsx",
            lineNumber: 370,
            columnNumber: 13
          }, this)]
        }, void 0, true, {
          fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/atoms/Icon/Icon.stories.tsx",
          lineNumber: 363,
          columnNumber: 11
        }, this)]
      }, void 0, true, {
        fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/atoms/Icon/Icon.stories.tsx",
        lineNumber: 335,
        columnNumber: 9
      }, this)]
    }, void 0, true, {
      fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/atoms/Icon/Icon.stories.tsx",
      lineNumber: 333,
      columnNumber: 7
    }, this), /* @__PURE__ */jsxDEV("div", {
      children: [/* @__PURE__ */jsxDEV("h3", {
        className: "text-lg font-semibold mb-3",
        children: "Estados Secondary"
      }, void 0, false, {
        fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/atoms/Icon/Icon.stories.tsx",
        lineNumber: 376,
        columnNumber: 9
      }, this), /* @__PURE__ */jsxDEV("div", {
        className: "flex items-center gap-4 bg-gray-800 p-4 rounded",
        children: [/* @__PURE__ */jsxDEV("div", {
          className: "text-center",
          children: [/* @__PURE__ */jsxDEV(Icon, {
            name: "accessibility",
            interactive: true,
            colorVariant: "secondary",
            state: "default"
          }, void 0, false, {
            fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/atoms/Icon/Icon.stories.tsx",
            lineNumber: 379,
            columnNumber: 13
          }, this), /* @__PURE__ */jsxDEV("div", {
            className: "text-xs mt-1 text-white",
            children: "Default"
          }, void 0, false, {
            fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/atoms/Icon/Icon.stories.tsx",
            lineNumber: 385,
            columnNumber: 13
          }, this)]
        }, void 0, true, {
          fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/atoms/Icon/Icon.stories.tsx",
          lineNumber: 378,
          columnNumber: 11
        }, this), /* @__PURE__ */jsxDEV("div", {
          className: "text-center",
          children: [/* @__PURE__ */jsxDEV(Icon, {
            name: "accessibility",
            interactive: true,
            colorVariant: "secondary",
            state: "hover"
          }, void 0, false, {
            fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/atoms/Icon/Icon.stories.tsx",
            lineNumber: 388,
            columnNumber: 13
          }, this), /* @__PURE__ */jsxDEV("div", {
            className: "text-xs mt-1 text-white",
            children: "Hover"
          }, void 0, false, {
            fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/atoms/Icon/Icon.stories.tsx",
            lineNumber: 394,
            columnNumber: 13
          }, this)]
        }, void 0, true, {
          fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/atoms/Icon/Icon.stories.tsx",
          lineNumber: 387,
          columnNumber: 11
        }, this), /* @__PURE__ */jsxDEV("div", {
          className: "text-center",
          children: [/* @__PURE__ */jsxDEV(Icon, {
            name: "accessibility",
            interactive: true,
            colorVariant: "secondary",
            state: "focus"
          }, void 0, false, {
            fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/atoms/Icon/Icon.stories.tsx",
            lineNumber: 397,
            columnNumber: 13
          }, this), /* @__PURE__ */jsxDEV("div", {
            className: "text-xs mt-1 text-white",
            children: "Focus"
          }, void 0, false, {
            fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/atoms/Icon/Icon.stories.tsx",
            lineNumber: 403,
            columnNumber: 13
          }, this)]
        }, void 0, true, {
          fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/atoms/Icon/Icon.stories.tsx",
          lineNumber: 396,
          columnNumber: 11
        }, this), /* @__PURE__ */jsxDEV("div", {
          className: "text-center",
          children: [/* @__PURE__ */jsxDEV(Icon, {
            name: "accessibility",
            interactive: true,
            colorVariant: "secondary",
            state: "disabled"
          }, void 0, false, {
            fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/atoms/Icon/Icon.stories.tsx",
            lineNumber: 406,
            columnNumber: 13
          }, this), /* @__PURE__ */jsxDEV("div", {
            className: "text-xs mt-1 text-white",
            children: "Disabled"
          }, void 0, false, {
            fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/atoms/Icon/Icon.stories.tsx",
            lineNumber: 412,
            columnNumber: 13
          }, this)]
        }, void 0, true, {
          fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/atoms/Icon/Icon.stories.tsx",
          lineNumber: 405,
          columnNumber: 11
        }, this)]
      }, void 0, true, {
        fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/atoms/Icon/Icon.stories.tsx",
        lineNumber: 377,
        columnNumber: 9
      }, this)]
    }, void 0, true, {
      fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/atoms/Icon/Icon.stories.tsx",
      lineNumber: 375,
      columnNumber: 7
    }, this), /* @__PURE__ */jsxDEV("div", {
      children: [/* @__PURE__ */jsxDEV("h3", {
        className: "text-lg font-semibold mb-3",
        children: "Estados Tertiary"
      }, void 0, false, {
        fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/atoms/Icon/Icon.stories.tsx",
        lineNumber: 418,
        columnNumber: 9
      }, this), /* @__PURE__ */jsxDEV("div", {
        className: "flex items-center gap-4",
        children: [/* @__PURE__ */jsxDEV("div", {
          className: "text-center",
          children: [/* @__PURE__ */jsxDEV(Icon, {
            name: "handshake",
            interactive: true,
            colorVariant: "tertiary",
            state: "default"
          }, void 0, false, {
            fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/atoms/Icon/Icon.stories.tsx",
            lineNumber: 421,
            columnNumber: 13
          }, this), /* @__PURE__ */jsxDEV("div", {
            className: "text-xs mt-1",
            children: "Default"
          }, void 0, false, {
            fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/atoms/Icon/Icon.stories.tsx",
            lineNumber: 427,
            columnNumber: 13
          }, this)]
        }, void 0, true, {
          fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/atoms/Icon/Icon.stories.tsx",
          lineNumber: 420,
          columnNumber: 11
        }, this), /* @__PURE__ */jsxDEV("div", {
          className: "text-center",
          children: [/* @__PURE__ */jsxDEV(Icon, {
            name: "handshake",
            interactive: true,
            colorVariant: "tertiary",
            state: "hover"
          }, void 0, false, {
            fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/atoms/Icon/Icon.stories.tsx",
            lineNumber: 430,
            columnNumber: 13
          }, this), /* @__PURE__ */jsxDEV("div", {
            className: "text-xs mt-1",
            children: "Hover"
          }, void 0, false, {
            fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/atoms/Icon/Icon.stories.tsx",
            lineNumber: 436,
            columnNumber: 13
          }, this)]
        }, void 0, true, {
          fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/atoms/Icon/Icon.stories.tsx",
          lineNumber: 429,
          columnNumber: 11
        }, this), /* @__PURE__ */jsxDEV("div", {
          className: "text-center",
          children: [/* @__PURE__ */jsxDEV(Icon, {
            name: "handshake",
            interactive: true,
            colorVariant: "tertiary",
            state: "focus"
          }, void 0, false, {
            fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/atoms/Icon/Icon.stories.tsx",
            lineNumber: 439,
            columnNumber: 13
          }, this), /* @__PURE__ */jsxDEV("div", {
            className: "text-xs mt-1",
            children: "Focus"
          }, void 0, false, {
            fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/atoms/Icon/Icon.stories.tsx",
            lineNumber: 445,
            columnNumber: 13
          }, this)]
        }, void 0, true, {
          fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/atoms/Icon/Icon.stories.tsx",
          lineNumber: 438,
          columnNumber: 11
        }, this), /* @__PURE__ */jsxDEV("div", {
          className: "text-center",
          children: [/* @__PURE__ */jsxDEV(Icon, {
            name: "handshake",
            interactive: true,
            colorVariant: "tertiary",
            state: "disabled"
          }, void 0, false, {
            fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/atoms/Icon/Icon.stories.tsx",
            lineNumber: 448,
            columnNumber: 13
          }, this), /* @__PURE__ */jsxDEV("div", {
            className: "text-xs mt-1",
            children: "Disabled"
          }, void 0, false, {
            fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/atoms/Icon/Icon.stories.tsx",
            lineNumber: 454,
            columnNumber: 13
          }, this)]
        }, void 0, true, {
          fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/atoms/Icon/Icon.stories.tsx",
          lineNumber: 447,
          columnNumber: 11
        }, this)]
      }, void 0, true, {
        fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/atoms/Icon/Icon.stories.tsx",
        lineNumber: 419,
        columnNumber: 9
      }, this)]
    }, void 0, true, {
      fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/atoms/Icon/Icon.stories.tsx",
      lineNumber: 417,
      columnNumber: 7
    }, this)]
  }, void 0, true, {
    fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/atoms/Icon/Icon.stories.tsx",
    lineNumber: 332,
    columnNumber: 3
  }, this),
  parameters: {
    docs: {
      description: {
        story: "Demostración de todos los estados interactivos controlados"
      }
    }
  }
};
export const IconShowcase = {
  render: () => /* @__PURE__ */jsxDEV("div", {
    className: "grid grid-cols-2 gap-8",
    children: [/* @__PURE__ */jsxDEV("div", {
      className: "space-y-4",
      children: [/* @__PURE__ */jsxDEV("h3", {
        className: "text-lg font-semibold",
        children: "Iconos disponibles"
      }, void 0, false, {
        fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/atoms/Icon/Icon.stories.tsx",
        lineNumber: 474,
        columnNumber: 9
      }, this), /* @__PURE__ */jsxDEV("div", {
        className: "flex items-center gap-4",
        children: [/* @__PURE__ */jsxDEV(Icon, {
          name: "leaf",
          size: "lg"
        }, void 0, false, {
          fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/atoms/Icon/Icon.stories.tsx",
          lineNumber: 476,
          columnNumber: 11
        }, this), /* @__PURE__ */jsxDEV("span", {
          children: "Leaf"
        }, void 0, false, {
          fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/atoms/Icon/Icon.stories.tsx",
          lineNumber: 477,
          columnNumber: 11
        }, this)]
      }, void 0, true, {
        fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/atoms/Icon/Icon.stories.tsx",
        lineNumber: 475,
        columnNumber: 9
      }, this), /* @__PURE__ */jsxDEV("div", {
        className: "flex items-center gap-4",
        children: [/* @__PURE__ */jsxDEV(Icon, {
          name: "accessibility",
          size: "lg"
        }, void 0, false, {
          fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/atoms/Icon/Icon.stories.tsx",
          lineNumber: 480,
          columnNumber: 11
        }, this), /* @__PURE__ */jsxDEV("span", {
          children: "Accessibility"
        }, void 0, false, {
          fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/atoms/Icon/Icon.stories.tsx",
          lineNumber: 481,
          columnNumber: 11
        }, this)]
      }, void 0, true, {
        fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/atoms/Icon/Icon.stories.tsx",
        lineNumber: 479,
        columnNumber: 9
      }, this), /* @__PURE__ */jsxDEV("div", {
        className: "flex items-center gap-4",
        children: [/* @__PURE__ */jsxDEV(Icon, {
          name: "x",
          size: "lg"
        }, void 0, false, {
          fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/atoms/Icon/Icon.stories.tsx",
          lineNumber: 484,
          columnNumber: 11
        }, this), /* @__PURE__ */jsxDEV("span", {
          children: "X (Close)"
        }, void 0, false, {
          fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/atoms/Icon/Icon.stories.tsx",
          lineNumber: 485,
          columnNumber: 11
        }, this)]
      }, void 0, true, {
        fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/atoms/Icon/Icon.stories.tsx",
        lineNumber: 483,
        columnNumber: 9
      }, this), /* @__PURE__ */jsxDEV("div", {
        className: "flex items-center gap-4",
        children: [/* @__PURE__ */jsxDEV(Icon, {
          name: "handshake",
          size: "lg"
        }, void 0, false, {
          fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/atoms/Icon/Icon.stories.tsx",
          lineNumber: 488,
          columnNumber: 11
        }, this), /* @__PURE__ */jsxDEV("span", {
          children: "Handshake"
        }, void 0, false, {
          fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/atoms/Icon/Icon.stories.tsx",
          lineNumber: 489,
          columnNumber: 11
        }, this)]
      }, void 0, true, {
        fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/atoms/Icon/Icon.stories.tsx",
        lineNumber: 487,
        columnNumber: 9
      }, this), /* @__PURE__ */jsxDEV("div", {
        className: "flex items-center gap-4",
        children: [/* @__PURE__ */jsxDEV(Icon, {
          name: "arrow-left",
          size: "lg"
        }, void 0, false, {
          fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/atoms/Icon/Icon.stories.tsx",
          lineNumber: 492,
          columnNumber: 11
        }, this), /* @__PURE__ */jsxDEV("span", {
          children: "Arrow Left"
        }, void 0, false, {
          fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/atoms/Icon/Icon.stories.tsx",
          lineNumber: 493,
          columnNumber: 11
        }, this)]
      }, void 0, true, {
        fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/atoms/Icon/Icon.stories.tsx",
        lineNumber: 491,
        columnNumber: 9
      }, this)]
    }, void 0, true, {
      fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/atoms/Icon/Icon.stories.tsx",
      lineNumber: 473,
      columnNumber: 7
    }, this), /* @__PURE__ */jsxDEV("div", {
      className: "space-y-4",
      children: [/* @__PURE__ */jsxDEV("h3", {
        className: "text-lg font-semibold",
        children: "Tamaños"
      }, void 0, false, {
        fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/atoms/Icon/Icon.stories.tsx",
        lineNumber: 498,
        columnNumber: 9
      }, this), /* @__PURE__ */jsxDEV("div", {
        className: "flex items-center gap-4",
        children: [/* @__PURE__ */jsxDEV(Icon, {
          name: "leaf",
          size: "xs"
        }, void 0, false, {
          fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/atoms/Icon/Icon.stories.tsx",
          lineNumber: 500,
          columnNumber: 11
        }, this), /* @__PURE__ */jsxDEV(Icon, {
          name: "leaf",
          size: "sm"
        }, void 0, false, {
          fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/atoms/Icon/Icon.stories.tsx",
          lineNumber: 501,
          columnNumber: 11
        }, this), /* @__PURE__ */jsxDEV(Icon, {
          name: "leaf",
          size: "md"
        }, void 0, false, {
          fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/atoms/Icon/Icon.stories.tsx",
          lineNumber: 502,
          columnNumber: 11
        }, this), /* @__PURE__ */jsxDEV(Icon, {
          name: "leaf",
          size: "lg"
        }, void 0, false, {
          fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/atoms/Icon/Icon.stories.tsx",
          lineNumber: 503,
          columnNumber: 11
        }, this), /* @__PURE__ */jsxDEV(Icon, {
          name: "leaf",
          size: "xl"
        }, void 0, false, {
          fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/atoms/Icon/Icon.stories.tsx",
          lineNumber: 504,
          columnNumber: 11
        }, this)]
      }, void 0, true, {
        fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/atoms/Icon/Icon.stories.tsx",
        lineNumber: 499,
        columnNumber: 9
      }, this), /* @__PURE__ */jsxDEV("h3", {
        className: "text-lg font-semibold",
        children: "Colores estáticos"
      }, void 0, false, {
        fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/atoms/Icon/Icon.stories.tsx",
        lineNumber: 507,
        columnNumber: 9
      }, this), /* @__PURE__ */jsxDEV("div", {
        className: "flex items-center gap-4",
        children: [/* @__PURE__ */jsxDEV(Icon, {
          name: "accessibility",
          color: "primary"
        }, void 0, false, {
          fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/atoms/Icon/Icon.stories.tsx",
          lineNumber: 509,
          columnNumber: 11
        }, this), /* @__PURE__ */jsxDEV(Icon, {
          name: "accessibility",
          color: "secondary"
        }, void 0, false, {
          fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/atoms/Icon/Icon.stories.tsx",
          lineNumber: 510,
          columnNumber: 11
        }, this), /* @__PURE__ */jsxDEV(Icon, {
          name: "accessibility",
          color: "muted"
        }, void 0, false, {
          fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/atoms/Icon/Icon.stories.tsx",
          lineNumber: 511,
          columnNumber: 11
        }, this), /* @__PURE__ */jsxDEV(Icon, {
          name: "accessibility",
          color: "destructive"
        }, void 0, false, {
          fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/atoms/Icon/Icon.stories.tsx",
          lineNumber: 512,
          columnNumber: 11
        }, this), /* @__PURE__ */jsxDEV(Icon, {
          name: "accessibility",
          color: "foreground"
        }, void 0, false, {
          fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/atoms/Icon/Icon.stories.tsx",
          lineNumber: 513,
          columnNumber: 11
        }, this)]
      }, void 0, true, {
        fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/atoms/Icon/Icon.stories.tsx",
        lineNumber: 508,
        columnNumber: 9
      }, this), /* @__PURE__ */jsxDEV("h3", {
        className: "text-lg font-semibold",
        children: "Iconos interactivos"
      }, void 0, false, {
        fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/atoms/Icon/Icon.stories.tsx",
        lineNumber: 516,
        columnNumber: 9
      }, this), /* @__PURE__ */jsxDEV("div", {
        className: "flex items-center gap-4",
        children: [/* @__PURE__ */jsxDEV(Icon, {
          name: "leaf",
          interactive: true,
          colorVariant: "primary"
        }, void 0, false, {
          fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/atoms/Icon/Icon.stories.tsx",
          lineNumber: 518,
          columnNumber: 11
        }, this), /* @__PURE__ */jsxDEV(Icon, {
          name: "accessibility",
          interactive: true,
          colorVariant: "secondary"
        }, void 0, false, {
          fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/atoms/Icon/Icon.stories.tsx",
          lineNumber: 519,
          columnNumber: 11
        }, this), /* @__PURE__ */jsxDEV(Icon, {
          name: "handshake",
          interactive: true,
          colorVariant: "tertiary"
        }, void 0, false, {
          fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/atoms/Icon/Icon.stories.tsx",
          lineNumber: 520,
          columnNumber: 11
        }, this), /* @__PURE__ */jsxDEV(Icon, {
          name: "x",
          interactive: true,
          colorVariant: "primary",
          disabled: true
        }, void 0, false, {
          fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/atoms/Icon/Icon.stories.tsx",
          lineNumber: 521,
          columnNumber: 11
        }, this)]
      }, void 0, true, {
        fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/atoms/Icon/Icon.stories.tsx",
        lineNumber: 517,
        columnNumber: 9
      }, this)]
    }, void 0, true, {
      fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/atoms/Icon/Icon.stories.tsx",
      lineNumber: 497,
      columnNumber: 7
    }, this)]
  }, void 0, true, {
    fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/atoms/Icon/Icon.stories.tsx",
    lineNumber: 472,
    columnNumber: 3
  }, this),
  parameters: {
    docs: {
      description: {
        story: "Showcase completo: iconos estáticos, tamaños, colores e interactivos"
      }
    }
  }
};
Leaf.parameters = {
  ...Leaf.parameters,
  docs: {
    ...Leaf.parameters?.docs,
    source: {
      originalSource: "{\n  args: {\n    name: 'leaf'\n  },\n  parameters: {\n    docs: {\n      description: {\n        story: 'Icono de hoja - representa naturaleza, sostenibilidad'\n      }\n    }\n  }\n}",
      ...Leaf.parameters?.docs?.source
    }
  }
};
Accessibility.parameters = {
  ...Accessibility.parameters,
  docs: {
    ...Accessibility.parameters?.docs,
    source: {
      originalSource: "{\n  args: {\n    name: 'accessibility'\n  },\n  parameters: {\n    docs: {\n      description: {\n        story: 'Icono de accesibilidad - representa inclusi\xF3n y dise\xF1o universal'\n      }\n    }\n  }\n}",
      ...Accessibility.parameters?.docs?.source
    }
  }
};
X.parameters = {
  ...X.parameters,
  docs: {
    ...X.parameters?.docs,
    source: {
      originalSource: "{\n  args: {\n    name: 'x'\n  },\n  parameters: {\n    docs: {\n      description: {\n        story: 'Icono X - representa cerrar, cancelar o eliminar'\n      }\n    }\n  }\n}",
      ...X.parameters?.docs?.source
    }
  }
};
Handshake.parameters = {
  ...Handshake.parameters,
  docs: {
    ...Handshake.parameters?.docs,
    source: {
      originalSource: "{\n  args: {\n    name: 'handshake'\n  },\n  parameters: {\n    docs: {\n      description: {\n        story: 'Icono de handshake - representa colaboraci\xF3n, acuerdo, partnership'\n      }\n    }\n  }\n}",
      ...Handshake.parameters?.docs?.source
    }
  }
};
ArrowLeft.parameters = {
  ...ArrowLeft.parameters,
  docs: {
    ...ArrowLeft.parameters?.docs,
    source: {
      originalSource: "{\n  args: {\n    name: 'arrow-left'\n  },\n  parameters: {\n    docs: {\n      description: {\n        story: 'Icono de flecha izquierda - representa volver, anterior, navegaci\xF3n'\n      }\n    }\n  }\n}",
      ...ArrowLeft.parameters?.docs?.source
    }
  }
};
ExtraSmall.parameters = {
  ...ExtraSmall.parameters,
  docs: {
    ...ExtraSmall.parameters?.docs,
    source: {
      originalSource: "{\n  args: {\n    name: 'leaf',\n    size: 'xs'\n  },\n  parameters: {\n    docs: {\n      description: {\n        story: 'Tama\xF1o extra peque\xF1o (12px) - para uso en elementos muy compactos'\n      }\n    }\n  }\n}",
      ...ExtraSmall.parameters?.docs?.source
    }
  }
};
Small.parameters = {
  ...Small.parameters,
  docs: {
    ...Small.parameters?.docs,
    source: {
      originalSource: "{\n  args: {\n    name: 'leaf',\n    size: 'sm'\n  },\n  parameters: {\n    docs: {\n      description: {\n        story: 'Tama\xF1o peque\xF1o (16px) - para uso en texto o botones peque\xF1os'\n      }\n    }\n  }\n}",
      ...Small.parameters?.docs?.source
    }
  }
};
Medium.parameters = {
  ...Medium.parameters,
  docs: {
    ...Medium.parameters?.docs,
    source: {
      originalSource: "{\n  args: {\n    name: 'leaf',\n    size: 'md'\n  },\n  parameters: {\n    docs: {\n      description: {\n        story: 'Tama\xF1o mediano (24px) - tama\xF1o por defecto para uso general'\n      }\n    }\n  }\n}",
      ...Medium.parameters?.docs?.source
    }
  }
};
Large.parameters = {
  ...Large.parameters,
  docs: {
    ...Large.parameters?.docs,
    source: {
      originalSource: "{\n  args: {\n    name: 'leaf',\n    size: 'lg'\n  },\n  parameters: {\n    docs: {\n      description: {\n        story: 'Tama\xF1o grande (32px) - para elementos destacados'\n      }\n    }\n  }\n}",
      ...Large.parameters?.docs?.source
    }
  }
};
ExtraLarge.parameters = {
  ...ExtraLarge.parameters,
  docs: {
    ...ExtraLarge.parameters?.docs,
    source: {
      originalSource: "{\n  args: {\n    name: 'leaf',\n    size: 'xl'\n  },\n  parameters: {\n    docs: {\n      description: {\n        story: 'Tama\xF1o extra grande (40px) - para uso decorativo o headers'\n      }\n    }\n  }\n}",
      ...ExtraLarge.parameters?.docs?.source
    }
  }
};
Primary.parameters = {
  ...Primary.parameters,
  docs: {
    ...Primary.parameters?.docs,
    source: {
      originalSource: "{\n  args: {\n    name: 'accessibility',\n    color: 'primary'\n  },\n  parameters: {\n    docs: {\n      description: {\n        story: 'Color primario - para iconos principales e importantes'\n      }\n    }\n  }\n}",
      ...Primary.parameters?.docs?.source
    }
  }
};
Secondary.parameters = {
  ...Secondary.parameters,
  docs: {
    ...Secondary.parameters?.docs,
    source: {
      originalSource: "{\n  args: {\n    name: 'accessibility',\n    color: 'secondary'\n  },\n  parameters: {\n    docs: {\n      description: {\n        story: 'Color secundario - para iconos de apoyo'\n      }\n    }\n  }\n}",
      ...Secondary.parameters?.docs?.source
    }
  }
};
Muted.parameters = {
  ...Muted.parameters,
  docs: {
    ...Muted.parameters?.docs,
    source: {
      originalSource: "{\n  args: {\n    name: 'accessibility',\n    color: 'muted'\n  },\n  parameters: {\n    docs: {\n      description: {\n        story: 'Color apagado - para iconos decorativos o de baja prioridad'\n      }\n    }\n  }\n}",
      ...Muted.parameters?.docs?.source
    }
  }
};
Destructive.parameters = {
  ...Destructive.parameters,
  docs: {
    ...Destructive.parameters?.docs,
    source: {
      originalSource: "{\n  args: {\n    name: 'accessibility',\n    color: 'destructive'\n  },\n  parameters: {\n    docs: {\n      description: {\n        story: 'Color destructivo - para acciones peligrosas o errores'\n      }\n    }\n  }\n}",
      ...Destructive.parameters?.docs?.source
    }
  }
};
InteractivePrimary.parameters = {
  ...InteractivePrimary.parameters,
  docs: {
    ...InteractivePrimary.parameters?.docs,
    source: {
      originalSource: "{\n  args: {\n    name: 'leaf',\n    interactive: true,\n    colorVariant: 'primary'\n  },\n  parameters: {\n    docs: {\n      description: {\n        story: 'Icono interactivo con variante primary - hover sobre el icono para ver el efecto'\n      }\n    }\n  }\n}",
      ...InteractivePrimary.parameters?.docs?.source
    }
  }
};
InteractiveSecondary.parameters = {
  ...InteractiveSecondary.parameters,
  docs: {
    ...InteractiveSecondary.parameters?.docs,
    source: {
      originalSource: "{\n  args: {\n    name: 'accessibility',\n    interactive: true,\n    colorVariant: 'secondary'\n  },\n  parameters: {\n    docs: {\n      description: {\n        story: 'Icono interactivo con variante secondary'\n      }\n    }\n  }\n}",
      ...InteractiveSecondary.parameters?.docs?.source
    }
  }
};
InteractiveTertiary.parameters = {
  ...InteractiveTertiary.parameters,
  docs: {
    ...InteractiveTertiary.parameters?.docs,
    source: {
      originalSource: "{\n  args: {\n    name: 'handshake',\n    interactive: true,\n    colorVariant: 'tertiary'\n  },\n  parameters: {\n    docs: {\n      description: {\n        story: 'Icono interactivo con variante tertiary'\n      }\n    }\n  }\n}",
      ...InteractiveTertiary.parameters?.docs?.source
    }
  }
};
DisabledInteractive.parameters = {
  ...DisabledInteractive.parameters,
  docs: {
    ...DisabledInteractive.parameters?.docs,
    source: {
      originalSource: "{\n  args: {\n    name: 'x',\n    interactive: true,\n    disabled: true,\n    colorVariant: 'primary'\n  },\n  parameters: {\n    docs: {\n      description: {\n        story: 'Icono interactivo deshabilitado'\n      }\n    }\n  }\n}",
      ...DisabledInteractive.parameters?.docs?.source
    }
  }
};
ControlledStates.parameters = {
  ...ControlledStates.parameters,
  docs: {
    ...ControlledStates.parameters?.docs,
    source: {
      originalSource: "{\n  render: () => <div className=\"space-y-6\">\n      <div>\n        <h3 className=\"text-lg font-semibold mb-3\">Estados Primary</h3>\n        <div className=\"flex items-center gap-4\">\n          <div className=\"text-center\">\n            <Icon name=\"leaf\" interactive colorVariant=\"primary\" state=\"default\" />\n            <div className=\"text-xs mt-1\">Default</div>\n          </div>\n          <div className=\"text-center\">\n            <Icon name=\"leaf\" interactive colorVariant=\"primary\" state=\"hover\" />\n            <div className=\"text-xs mt-1\">Hover</div>\n          </div>\n          <div className=\"text-center\">\n            <Icon name=\"leaf\" interactive colorVariant=\"primary\" state=\"focus\" />\n            <div className=\"text-xs mt-1\">Focus</div>\n          </div>\n          <div className=\"text-center\">\n            <Icon name=\"leaf\" interactive colorVariant=\"primary\" state=\"disabled\" />\n            <div className=\"text-xs mt-1\">Disabled</div>\n          </div>\n        </div>\n      </div>\n\n      <div>\n        <h3 className=\"text-lg font-semibold mb-3\">Estados Secondary</h3>\n        <div className=\"flex items-center gap-4 bg-gray-800 p-4 rounded\">\n          <div className=\"text-center\">\n            <Icon name=\"accessibility\" interactive colorVariant=\"secondary\" state=\"default\" />\n            <div className=\"text-xs mt-1 text-white\">Default</div>\n          </div>\n          <div className=\"text-center\">\n            <Icon name=\"accessibility\" interactive colorVariant=\"secondary\" state=\"hover\" />\n            <div className=\"text-xs mt-1 text-white\">Hover</div>\n          </div>\n          <div className=\"text-center\">\n            <Icon name=\"accessibility\" interactive colorVariant=\"secondary\" state=\"focus\" />\n            <div className=\"text-xs mt-1 text-white\">Focus</div>\n          </div>\n          <div className=\"text-center\">\n            <Icon name=\"accessibility\" interactive colorVariant=\"secondary\" state=\"disabled\" />\n            <div className=\"text-xs mt-1 text-white\">Disabled</div>\n          </div>\n        </div>\n      </div>\n\n      <div>\n        <h3 className=\"text-lg font-semibold mb-3\">Estados Tertiary</h3>\n        <div className=\"flex items-center gap-4\">\n          <div className=\"text-center\">\n            <Icon name=\"handshake\" interactive colorVariant=\"tertiary\" state=\"default\" />\n            <div className=\"text-xs mt-1\">Default</div>\n          </div>\n          <div className=\"text-center\">\n            <Icon name=\"handshake\" interactive colorVariant=\"tertiary\" state=\"hover\" />\n            <div className=\"text-xs mt-1\">Hover</div>\n          </div>\n          <div className=\"text-center\">\n            <Icon name=\"handshake\" interactive colorVariant=\"tertiary\" state=\"focus\" />\n            <div className=\"text-xs mt-1\">Focus</div>\n          </div>\n          <div className=\"text-center\">\n            <Icon name=\"handshake\" interactive colorVariant=\"tertiary\" state=\"disabled\" />\n            <div className=\"text-xs mt-1\">Disabled</div>\n          </div>\n        </div>\n      </div>\n    </div>,\n  parameters: {\n    docs: {\n      description: {\n        story: 'Demostraci\xF3n de todos los estados interactivos controlados'\n      }\n    }\n  }\n}",
      ...ControlledStates.parameters?.docs?.source
    }
  }
};
IconShowcase.parameters = {
  ...IconShowcase.parameters,
  docs: {
    ...IconShowcase.parameters?.docs,
    source: {
      originalSource: "{\n  render: () => <div className=\"grid grid-cols-2 gap-8\">\n      <div className=\"space-y-4\">\n        <h3 className=\"text-lg font-semibold\">Iconos disponibles</h3>\n        <div className=\"flex items-center gap-4\">\n          <Icon name=\"leaf\" size=\"lg\" />\n          <span>Leaf</span>\n        </div>\n        <div className=\"flex items-center gap-4\">\n          <Icon name=\"accessibility\" size=\"lg\" />\n          <span>Accessibility</span>\n        </div>\n        <div className=\"flex items-center gap-4\">\n          <Icon name=\"x\" size=\"lg\" />\n          <span>X (Close)</span>\n        </div>\n        <div className=\"flex items-center gap-4\">\n          <Icon name=\"handshake\" size=\"lg\" />\n          <span>Handshake</span>\n        </div>\n        <div className=\"flex items-center gap-4\">\n          <Icon name=\"arrow-left\" size=\"lg\" />\n          <span>Arrow Left</span>\n        </div>\n      </div>\n\n      <div className=\"space-y-4\">\n        <h3 className=\"text-lg font-semibold\">Tama\xF1os</h3>\n        <div className=\"flex items-center gap-4\">\n          <Icon name=\"leaf\" size=\"xs\" />\n          <Icon name=\"leaf\" size=\"sm\" />\n          <Icon name=\"leaf\" size=\"md\" />\n          <Icon name=\"leaf\" size=\"lg\" />\n          <Icon name=\"leaf\" size=\"xl\" />\n        </div>\n\n        <h3 className=\"text-lg font-semibold\">Colores est\xE1ticos</h3>\n        <div className=\"flex items-center gap-4\">\n          <Icon name=\"accessibility\" color=\"primary\" />\n          <Icon name=\"accessibility\" color=\"secondary\" />\n          <Icon name=\"accessibility\" color=\"muted\" />\n          <Icon name=\"accessibility\" color=\"destructive\" />\n          <Icon name=\"accessibility\" color=\"foreground\" />\n        </div>\n\n        <h3 className=\"text-lg font-semibold\">Iconos interactivos</h3>\n        <div className=\"flex items-center gap-4\">\n          <Icon name=\"leaf\" interactive colorVariant=\"primary\" />\n          <Icon name=\"accessibility\" interactive colorVariant=\"secondary\" />\n          <Icon name=\"handshake\" interactive colorVariant=\"tertiary\" />\n          <Icon name=\"x\" interactive colorVariant=\"primary\" disabled />\n        </div>\n      </div>\n    </div>,\n  parameters: {\n    docs: {\n      description: {\n        story: 'Showcase completo: iconos est\xE1ticos, tama\xF1os, colores e interactivos'\n      }\n    }\n  }\n}",
      ...IconShowcase.parameters?.docs?.source
    }
  }
};;export const __namedExportsOrder = ["Leaf","Accessibility","X","Handshake","ArrowLeft","ExtraSmall","Small","Medium","Large","ExtraLarge","Primary","Secondary","Muted","Destructive","InteractivePrimary","InteractiveSecondary","InteractiveTertiary","DisabledInteractive","ControlledStates","IconShowcase"];