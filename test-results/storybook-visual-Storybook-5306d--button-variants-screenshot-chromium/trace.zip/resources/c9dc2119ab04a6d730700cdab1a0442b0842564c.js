import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.cache/sb-vite/deps/react_jsx-dev-runtime.js?v=77221ebe"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import { userEvent, within, expect } from "/node_modules/.cache/sb-vite/deps/@storybook_test.js?v=77221ebe";
import { Button } from "/src/components/atoms/Button/Button.tsx";
const meta = {
  title: "Atoms/Button",
  component: Button,
  parameters: {
    layout: "centered",
    docs: {
      description: {
        component: "Botón principal del design system con diferentes variantes y tamaños."
      }
    },
    a11y: {
      config: {
        rules: [{
          id: "button-name",
          enabled: true
        }, {
          id: "color-contrast",
          enabled: true
        }]
      }
    }
  },
  argTypes: {
    variant: {
      control: {
        type: "select"
      },
      options: ["primary", "secondary", "outline", "destructive"],
      description: "Estilo visual del botón"
    },
    size: {
      control: {
        type: "select"
      },
      options: ["sm", "md", "lg"],
      description: "Tamaño del botón"
    },
    disabled: {
      control: {
        type: "boolean"
      },
      description: "Si el botón está deshabilitado"
    },
    onClick: {
      action: "clicked",
      description: "Función que se ejecuta al hacer click"
    },
    children: {
      control: "text",
      description: "Contenido del botón"
    }
  },
  tags: ["autodocs"]
};
export default meta;
export const Primary = {
  args: {
    children: "Primary Button",
    variant: "primary"
  },
  parameters: {
    docs: {
      description: {
        story: "Botón primario - usado para acciones principales"
      }
    }
  }
};
export const Secondary = {
  args: {
    children: "Secondary Button",
    variant: "secondary"
  },
  parameters: {
    docs: {
      description: {
        story: "Botón secundario - usado para acciones secundarias"
      }
    }
  }
};
export const Outline = {
  args: {
    children: "Outline Button",
    variant: "outline"
  },
  parameters: {
    docs: {
      description: {
        story: "Botón outline - usado para acciones menos prominentes"
      }
    }
  }
};
export const Destructive = {
  args: {
    children: "Delete",
    variant: "destructive"
  },
  parameters: {
    docs: {
      description: {
        story: "Botón destructivo - usado para acciones peligrosas como eliminar"
      }
    }
  }
};
export const Small = {
  args: {
    children: "Small Button",
    size: "sm"
  }
};
export const Medium = {
  args: {
    children: "Medium Button",
    size: "md"
  }
};
export const Large = {
  args: {
    children: "Large Button",
    size: "lg"
  }
};
export const Disabled = {
  args: {
    children: "Disabled Button",
    disabled: true
  },
  parameters: {
    docs: {
      description: {
        story: "Botón deshabilitado - no puede ser interactuado"
      }
    }
  }
};
export const ClickInteraction = {
  args: {
    children: "Click me!",
    variant: "primary"
  },
  play: async ({
    canvasElement,
    args
  }) => {
    const canvas = within(canvasElement);
    const button = canvas.getByRole("button", {
      name: /click me!/i
    });
    await expect(button).toBeInTheDocument();
    await userEvent.click(button);
    if (args.onClick) {
      console.log("Button was clicked!");
    }
  },
  parameters: {
    docs: {
      description: {
        story: "Demostración de interaction testing con play function"
      }
    }
  }
};
export const WithIcon = {
  args: {
    children: /* @__PURE__ */jsxDEV("span", {
      className: "flex items-center gap-2",
      children: [/* @__PURE__ */jsxDEV("svg", {
        className: "w-4 h-4",
        fill: "none",
        stroke: "currentColor",
        viewBox: "0 0 24 24",
        children: /* @__PURE__ */jsxDEV("path", {
          strokeLinecap: "round",
          strokeLinejoin: "round",
          strokeWidth: 2,
          d: "M5 13l4 4L19 7"
        }, void 0, false, {
          fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/atoms/Button/Button.stories.tsx",
          lineNumber: 199,
          columnNumber: 11
        }, this)
      }, void 0, false, {
        fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/atoms/Button/Button.stories.tsx",
        lineNumber: 193,
        columnNumber: 9
      }, this), "With Icon"]
    }, void 0, true, {
      fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/atoms/Button/Button.stories.tsx",
      lineNumber: 192,
      columnNumber: 5
    }, this),
    variant: "primary"
  },
  parameters: {
    docs: {
      description: {
        story: "Botón con icono incluido en el contenido"
      }
    }
  }
};
Primary.parameters = {
  ...Primary.parameters,
  docs: {
    ...Primary.parameters?.docs,
    source: {
      originalSource: "{\n  args: {\n    children: 'Primary Button',\n    variant: 'primary'\n  },\n  parameters: {\n    docs: {\n      description: {\n        story: 'Bot\xF3n primario - usado para acciones principales'\n      }\n    }\n  }\n}",
      ...Primary.parameters?.docs?.source
    }
  }
};
Secondary.parameters = {
  ...Secondary.parameters,
  docs: {
    ...Secondary.parameters?.docs,
    source: {
      originalSource: "{\n  args: {\n    children: 'Secondary Button',\n    variant: 'secondary'\n  },\n  parameters: {\n    docs: {\n      description: {\n        story: 'Bot\xF3n secundario - usado para acciones secundarias'\n      }\n    }\n  }\n}",
      ...Secondary.parameters?.docs?.source
    }
  }
};
Outline.parameters = {
  ...Outline.parameters,
  docs: {
    ...Outline.parameters?.docs,
    source: {
      originalSource: "{\n  args: {\n    children: 'Outline Button',\n    variant: 'outline'\n  },\n  parameters: {\n    docs: {\n      description: {\n        story: 'Bot\xF3n outline - usado para acciones menos prominentes'\n      }\n    }\n  }\n}",
      ...Outline.parameters?.docs?.source
    }
  }
};
Destructive.parameters = {
  ...Destructive.parameters,
  docs: {
    ...Destructive.parameters?.docs,
    source: {
      originalSource: "{\n  args: {\n    children: 'Delete',\n    variant: 'destructive'\n  },\n  parameters: {\n    docs: {\n      description: {\n        story: 'Bot\xF3n destructivo - usado para acciones peligrosas como eliminar'\n      }\n    }\n  }\n}",
      ...Destructive.parameters?.docs?.source
    }
  }
};
Small.parameters = {
  ...Small.parameters,
  docs: {
    ...Small.parameters?.docs,
    source: {
      originalSource: "{\n  args: {\n    children: 'Small Button',\n    size: 'sm'\n  }\n}",
      ...Small.parameters?.docs?.source
    }
  }
};
Medium.parameters = {
  ...Medium.parameters,
  docs: {
    ...Medium.parameters?.docs,
    source: {
      originalSource: "{\n  args: {\n    children: 'Medium Button',\n    size: 'md'\n  }\n}",
      ...Medium.parameters?.docs?.source
    }
  }
};
Large.parameters = {
  ...Large.parameters,
  docs: {
    ...Large.parameters?.docs,
    source: {
      originalSource: "{\n  args: {\n    children: 'Large Button',\n    size: 'lg'\n  }\n}",
      ...Large.parameters?.docs?.source
    }
  }
};
Disabled.parameters = {
  ...Disabled.parameters,
  docs: {
    ...Disabled.parameters?.docs,
    source: {
      originalSource: "{\n  args: {\n    children: 'Disabled Button',\n    disabled: true\n  },\n  parameters: {\n    docs: {\n      description: {\n        story: 'Bot\xF3n deshabilitado - no puede ser interactuado'\n      }\n    }\n  }\n}",
      ...Disabled.parameters?.docs?.source
    }
  }
};
ClickInteraction.parameters = {
  ...ClickInteraction.parameters,
  docs: {
    ...ClickInteraction.parameters?.docs,
    source: {
      originalSource: "{\n  args: {\n    children: 'Click me!',\n    variant: 'primary'\n  },\n  play: async ({\n    canvasElement,\n    args\n  }) => {\n    const canvas = within(canvasElement);\n    const button = canvas.getByRole('button', {\n      name: /click me!/i\n    });\n\n    // Verificar que el bot\xF3n est\xE1 visible\n    await expect(button).toBeInTheDocument();\n\n    // Simular click\n    await userEvent.click(button);\n\n    // Verificar que el onClick fue llamado (si est\xE1 definido)\n    if (args.onClick) {\n      // En un escenario real, aqu\xED verificar\xEDamos que el callback fue llamado\n      console.log('Button was clicked!');\n    }\n  },\n  parameters: {\n    docs: {\n      description: {\n        story: 'Demostraci\xF3n de interaction testing con play function'\n      }\n    }\n  }\n}",
      ...ClickInteraction.parameters?.docs?.source
    }
  }
};
WithIcon.parameters = {
  ...WithIcon.parameters,
  docs: {
    ...WithIcon.parameters?.docs,
    source: {
      originalSource: "{\n  args: {\n    children: <span className=\"flex items-center gap-2\">\n        <svg className=\"w-4 h-4\" fill=\"none\" stroke=\"currentColor\" viewBox=\"0 0 24 24\">\n          <path strokeLinecap=\"round\" strokeLinejoin=\"round\" strokeWidth={2} d=\"M5 13l4 4L19 7\" />\n        </svg>\n        With Icon\n      </span>,\n    variant: 'primary'\n  },\n  parameters: {\n    docs: {\n      description: {\n        story: 'Bot\xF3n con icono incluido en el contenido'\n      }\n    }\n  }\n}",
      ...WithIcon.parameters?.docs?.source
    }
  }
};;export const __namedExportsOrder = ["Primary","Secondary","Outline","Destructive","Small","Medium","Large","Disabled","ClickInteraction","WithIcon"];