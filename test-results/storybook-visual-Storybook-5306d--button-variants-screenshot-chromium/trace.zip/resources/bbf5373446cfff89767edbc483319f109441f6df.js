import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/atoms/Button/Button.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.cache/sb-vite/deps/react_jsx-dev-runtime.js?v=77221ebe"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
export const Button = ({
  children,
  variant = "primary",
  size = "md",
  disabled = false,
  onClick,
  type = "button",
  className = "",
  ...props
}) => {
  const baseStyles = "inline-flex items-center justify-center font-medium transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-50 rounded-md";
  const variantStyles = {
    primary: `bg-primary text-primary-foreground hover:bg-primary/90 focus-visible:ring-ring`,
    secondary: `bg-secondary text-secondary-foreground hover:bg-secondary/80 focus-visible:ring-ring`,
    outline: `border border-input bg-background text-foreground hover:bg-accent hover:text-accent-foreground focus-visible:ring-ring`,
    destructive: `bg-destructive text-destructive-foreground hover:bg-destructive/90 focus-visible:ring-ring`
  };
  const sizeStyles = {
    sm: "h-8 px-3 text-sm gap-2",
    md: "h-10 px-4 text-base gap-2",
    lg: "h-12 px-6 text-lg gap-2"
  };
  return /* @__PURE__ */ jsxDEV(
    "button",
    {
      className: `${baseStyles} ${variantStyles[variant]} ${sizeStyles[size]} ${className}`,
      disabled,
      onClick,
      type,
      ...props,
      children
    },
    void 0,
    false,
    {
      fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/atoms/Button/Button.tsx",
      lineNumber: 37,
      columnNumber: 5
    },
    this
  );
};
_c = Button;
var _c;
$RefreshReg$(_c, "Button");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/atoms/Button/Button.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/atoms/Button/Button.tsx", currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/atoms/Button/Button.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBb0NJO0FBM0JHLGFBQU1BLFNBQWdDQSxDQUFDO0FBQUEsRUFDNUNDO0FBQUFBLEVBQ0FDLFVBQVU7QUFBQSxFQUNWQyxPQUFPO0FBQUEsRUFDUEMsV0FBVztBQUFBLEVBQ1hDO0FBQUFBLEVBQ0FDLE9BQU87QUFBQSxFQUNQQyxZQUFZO0FBQUEsRUFDWixHQUFHQztBQUNMLE1BQU07QUFDSixRQUFNQyxhQUNKO0FBRUYsUUFBTUMsZ0JBQWdCO0FBQUEsSUFDcEJDLFNBQVM7QUFBQSxJQUNUQyxXQUFXO0FBQUEsSUFDWEMsU0FBUztBQUFBLElBQ1RDLGFBQWE7QUFBQSxFQUNmO0FBRUEsUUFBTUMsYUFBYTtBQUFBLElBQ2pCQyxJQUFJO0FBQUEsSUFDSkMsSUFBSTtBQUFBLElBQ0pDLElBQUk7QUFBQSxFQUNOO0FBRUEsU0FDRTtBQUFBLElBQUM7QUFBQTtBQUFBLE1BQ0MsV0FBVyxHQUFHVCxjQUFjQyxjQUFjUixPQUFPLEtBQUthLFdBQVdaLElBQUksS0FBS0k7QUFBQUEsTUFDMUU7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLE1BQ0EsR0FBSUM7QUFBQUEsTUFFSFA7QUFBQUE7QUFBQUEsSUFQSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFRQTtBQUVKO0FBQUVrQixLQXJDV25CO0FBQTZCLElBQUFtQjtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsiQnV0dG9uIiwiY2hpbGRyZW4iLCJ2YXJpYW50Iiwic2l6ZSIsImRpc2FibGVkIiwib25DbGljayIsInR5cGUiLCJjbGFzc05hbWUiLCJwcm9wcyIsImJhc2VTdHlsZXMiLCJ2YXJpYW50U3R5bGVzIiwicHJpbWFyeSIsInNlY29uZGFyeSIsIm91dGxpbmUiLCJkZXN0cnVjdGl2ZSIsInNpemVTdHlsZXMiLCJzbSIsIm1kIiwibGciLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIkJ1dHRvbi50c3giXSwiZmlsZSI6Ii9ob21lL3N1bmRlL3Byb2plY3RzL0xpZHIvZnJvbnRlbmQtdXNlLWNhc2UtZGVzaWduLXN5c3RlbS9zcmMvY29tcG9uZW50cy9hdG9tcy9CdXR0b24vQnV0dG9uLnRzeCIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCBmcm9tICdyZWFjdCc7XG5cbmV4cG9ydCBpbnRlcmZhY2UgQnV0dG9uUHJvcHNcbiAgZXh0ZW5kcyBSZWFjdC5CdXR0b25IVE1MQXR0cmlidXRlczxIVE1MQnV0dG9uRWxlbWVudD4ge1xuICBjaGlsZHJlbjogUmVhY3QuUmVhY3ROb2RlO1xuICB2YXJpYW50PzogJ3ByaW1hcnknIHwgJ3NlY29uZGFyeScgfCAnb3V0bGluZScgfCAnZGVzdHJ1Y3RpdmUnO1xuICBzaXplPzogJ3NtJyB8ICdtZCcgfCAnbGcnO1xufVxuXG5leHBvcnQgY29uc3QgQnV0dG9uOiBSZWFjdC5GQzxCdXR0b25Qcm9wcz4gPSAoe1xuICBjaGlsZHJlbixcbiAgdmFyaWFudCA9ICdwcmltYXJ5JyxcbiAgc2l6ZSA9ICdtZCcsXG4gIGRpc2FibGVkID0gZmFsc2UsXG4gIG9uQ2xpY2ssXG4gIHR5cGUgPSAnYnV0dG9uJyxcbiAgY2xhc3NOYW1lID0gJycsXG4gIC4uLnByb3BzXG59KSA9PiB7XG4gIGNvbnN0IGJhc2VTdHlsZXMgPVxuICAgICdpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgZm9udC1tZWRpdW0gdHJhbnNpdGlvbi1jb2xvcnMgZm9jdXMtdmlzaWJsZTpvdXRsaW5lLW5vbmUgZm9jdXMtdmlzaWJsZTpyaW5nLTIgZm9jdXMtdmlzaWJsZTpyaW5nLXJpbmcgZGlzYWJsZWQ6cG9pbnRlci1ldmVudHMtbm9uZSBkaXNhYmxlZDpvcGFjaXR5LTUwIHJvdW5kZWQtbWQnO1xuXG4gIGNvbnN0IHZhcmlhbnRTdHlsZXMgPSB7XG4gICAgcHJpbWFyeTogYGJnLXByaW1hcnkgdGV4dC1wcmltYXJ5LWZvcmVncm91bmQgaG92ZXI6YmctcHJpbWFyeS85MCBmb2N1cy12aXNpYmxlOnJpbmctcmluZ2AsXG4gICAgc2Vjb25kYXJ5OiBgYmctc2Vjb25kYXJ5IHRleHQtc2Vjb25kYXJ5LWZvcmVncm91bmQgaG92ZXI6Ymctc2Vjb25kYXJ5LzgwIGZvY3VzLXZpc2libGU6cmluZy1yaW5nYCxcbiAgICBvdXRsaW5lOiBgYm9yZGVyIGJvcmRlci1pbnB1dCBiZy1iYWNrZ3JvdW5kIHRleHQtZm9yZWdyb3VuZCBob3ZlcjpiZy1hY2NlbnQgaG92ZXI6dGV4dC1hY2NlbnQtZm9yZWdyb3VuZCBmb2N1cy12aXNpYmxlOnJpbmctcmluZ2AsXG4gICAgZGVzdHJ1Y3RpdmU6IGBiZy1kZXN0cnVjdGl2ZSB0ZXh0LWRlc3RydWN0aXZlLWZvcmVncm91bmQgaG92ZXI6YmctZGVzdHJ1Y3RpdmUvOTAgZm9jdXMtdmlzaWJsZTpyaW5nLXJpbmdgLFxuICB9O1xuXG4gIGNvbnN0IHNpemVTdHlsZXMgPSB7XG4gICAgc206ICdoLTggcHgtMyB0ZXh0LXNtIGdhcC0yJyxcbiAgICBtZDogJ2gtMTAgcHgtNCB0ZXh0LWJhc2UgZ2FwLTInLFxuICAgIGxnOiAnaC0xMiBweC02IHRleHQtbGcgZ2FwLTInLFxuICB9O1xuXG4gIHJldHVybiAoXG4gICAgPGJ1dHRvblxuICAgICAgY2xhc3NOYW1lPXtgJHtiYXNlU3R5bGVzfSAke3ZhcmlhbnRTdHlsZXNbdmFyaWFudF19ICR7c2l6ZVN0eWxlc1tzaXplXX0gJHtjbGFzc05hbWV9YH1cbiAgICAgIGRpc2FibGVkPXtkaXNhYmxlZH1cbiAgICAgIG9uQ2xpY2s9e29uQ2xpY2t9XG4gICAgICB0eXBlPXt0eXBlfVxuICAgICAgey4uLnByb3BzfVxuICAgID5cbiAgICAgIHtjaGlsZHJlbn1cbiAgICA8L2J1dHRvbj5cbiAgKTtcbn07XG4iXX0=