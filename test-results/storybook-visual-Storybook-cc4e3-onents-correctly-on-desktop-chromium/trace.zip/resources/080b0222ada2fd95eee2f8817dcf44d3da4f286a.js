import {
  require_react
} from "/node_modules/.cache/sb-vite/deps/chunk-OQ3OWAGM.js?v=77221ebe";
import "/node_modules/.cache/sb-vite/deps/chunk-LFBQMW2U.js?v=77221ebe";
export default require_react();
//# sourceMappingURL=react.js.map
