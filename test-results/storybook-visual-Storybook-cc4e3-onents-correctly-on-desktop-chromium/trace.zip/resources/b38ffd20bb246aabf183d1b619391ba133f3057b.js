import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.cache/sb-vite/deps/react_jsx-dev-runtime.js?v=77221ebe"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import { Tag } from "/src/components/molecules/Tag/Tag.tsx";
const meta = {
  title: "Molecules/Tag",
  component: Tag,
  parameters: {
    layout: "centered",
    docs: {
      description: {
        component: "Componente Tag para mostrar etiquetas con iconos, diferentes colores, tamaños y tipos."
      }
    },
    a11y: {
      config: {
        rules: [{
          id: "color-contrast",
          enabled: true
        }]
      }
    }
  },
  argTypes: {
    text: {
      control: {
        type: "text"
      },
      description: "Texto a mostrar en el tag"
    },
    color: {
      control: {
        type: "select"
      },
      options: ["yellow", "gray", "blue", "green", "orange", "pink", "purple"],
      description: "Color del tag"
    },
    size: {
      control: {
        type: "select"
      },
      options: ["s", "m", "l"],
      description: "Tamaño del tag"
    },
    type: {
      control: {
        type: "select"
      },
      options: ["positive", "negative"],
      description: "Tipo de tag (positivo o negativo)"
    },
    startIcon: {
      control: {
        type: "boolean"
      },
      description: "Mostrar icono al inicio (arrow-left)"
    },
    endIcon: {
      control: {
        type: "boolean"
      },
      description: "Mostrar icono al final (x)"
    },
    showText: {
      control: {
        type: "boolean"
      },
      description: "Mostrar texto"
    }
  },
  tags: ["autodocs"]
};
export default meta;
export const Default = {
  args: {
    text: "Tag"
  },
  parameters: {
    docs: {
      description: {
        story: "Tag por defecto con configuración estándar"
      }
    }
  }
};
export const WithoutIcons = {
  args: {
    text: "Sin iconos",
    startIcon: false,
    endIcon: false
  },
  parameters: {
    docs: {
      description: {
        story: "Tag sin iconos, solo texto"
      }
    }
  }
};
export const OnlyStartIcon = {
  args: {
    text: "Con inicio",
    startIcon: true,
    endIcon: false
  },
  parameters: {
    docs: {
      description: {
        story: "Tag solo con icono de inicio (arrow-left)"
      }
    }
  }
};
export const OnlyEndIcon = {
  args: {
    text: "Con final",
    startIcon: false,
    endIcon: true
  },
  parameters: {
    docs: {
      description: {
        story: "Tag solo con icono final (x)"
      }
    }
  }
};
export const Small = {
  args: {
    text: "Pequeño",
    size: "s"
  },
  parameters: {
    docs: {
      description: {
        story: "Tag tamaño pequeño"
      }
    }
  }
};
export const Medium = {
  args: {
    text: "Mediano",
    size: "m"
  },
  parameters: {
    docs: {
      description: {
        story: "Tag tamaño mediano (por defecto)"
      }
    }
  }
};
export const Large = {
  args: {
    text: "Grande",
    size: "l"
  },
  parameters: {
    docs: {
      description: {
        story: "Tag tamaño grande"
      }
    }
  }
};
export const Positive = {
  args: {
    text: "Positivo",
    type: "positive",
    color: "green"
  },
  parameters: {
    docs: {
      description: {
        story: "Tag tipo positivo con fondo claro"
      }
    }
  }
};
export const Negative = {
  args: {
    text: "Negativo",
    type: "negative",
    color: "blue"
  },
  parameters: {
    docs: {
      description: {
        story: "Tag tipo negativo con fondo oscuro"
      }
    }
  }
};
export const PositiveColors = {
  render: () => /* @__PURE__ */jsxDEV("div", {
    className: "flex flex-wrap gap-2",
    children: [/* @__PURE__ */jsxDEV(Tag, {
      text: "Yellow",
      color: "yellow",
      type: "positive"
    }, void 0, false, {
      fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/molecules/Tag/Tag.stories.tsx",
      lineNumber: 203,
      columnNumber: 7
    }, this), /* @__PURE__ */jsxDEV(Tag, {
      text: "Gray",
      color: "gray",
      type: "positive"
    }, void 0, false, {
      fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/molecules/Tag/Tag.stories.tsx",
      lineNumber: 204,
      columnNumber: 7
    }, this), /* @__PURE__ */jsxDEV(Tag, {
      text: "Blue",
      color: "blue",
      type: "positive"
    }, void 0, false, {
      fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/molecules/Tag/Tag.stories.tsx",
      lineNumber: 205,
      columnNumber: 7
    }, this), /* @__PURE__ */jsxDEV(Tag, {
      text: "Green",
      color: "green",
      type: "positive"
    }, void 0, false, {
      fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/molecules/Tag/Tag.stories.tsx",
      lineNumber: 206,
      columnNumber: 7
    }, this), /* @__PURE__ */jsxDEV(Tag, {
      text: "Orange",
      color: "orange",
      type: "positive"
    }, void 0, false, {
      fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/molecules/Tag/Tag.stories.tsx",
      lineNumber: 207,
      columnNumber: 7
    }, this), /* @__PURE__ */jsxDEV(Tag, {
      text: "Pink",
      color: "pink",
      type: "positive"
    }, void 0, false, {
      fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/molecules/Tag/Tag.stories.tsx",
      lineNumber: 208,
      columnNumber: 7
    }, this), /* @__PURE__ */jsxDEV(Tag, {
      text: "Purple",
      color: "purple",
      type: "positive"
    }, void 0, false, {
      fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/molecules/Tag/Tag.stories.tsx",
      lineNumber: 209,
      columnNumber: 7
    }, this)]
  }, void 0, true, {
    fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/molecules/Tag/Tag.stories.tsx",
    lineNumber: 202,
    columnNumber: 3
  }, this),
  parameters: {
    docs: {
      description: {
        story: "Showcase de todos los colores disponibles en tipo positivo"
      }
    }
  }
};
export const NegativeColors = {
  render: () => /* @__PURE__ */jsxDEV("div", {
    className: "flex flex-wrap gap-2",
    children: [/* @__PURE__ */jsxDEV(Tag, {
      text: "Yellow",
      color: "yellow",
      type: "negative"
    }, void 0, false, {
      fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/molecules/Tag/Tag.stories.tsx",
      lineNumber: 225,
      columnNumber: 7
    }, this), /* @__PURE__ */jsxDEV(Tag, {
      text: "Gray",
      color: "gray",
      type: "negative"
    }, void 0, false, {
      fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/molecules/Tag/Tag.stories.tsx",
      lineNumber: 226,
      columnNumber: 7
    }, this), /* @__PURE__ */jsxDEV(Tag, {
      text: "Blue",
      color: "blue",
      type: "negative"
    }, void 0, false, {
      fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/molecules/Tag/Tag.stories.tsx",
      lineNumber: 227,
      columnNumber: 7
    }, this), /* @__PURE__ */jsxDEV(Tag, {
      text: "Green",
      color: "green",
      type: "negative"
    }, void 0, false, {
      fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/molecules/Tag/Tag.stories.tsx",
      lineNumber: 228,
      columnNumber: 7
    }, this), /* @__PURE__ */jsxDEV(Tag, {
      text: "Orange",
      color: "orange",
      type: "negative"
    }, void 0, false, {
      fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/molecules/Tag/Tag.stories.tsx",
      lineNumber: 229,
      columnNumber: 7
    }, this), /* @__PURE__ */jsxDEV(Tag, {
      text: "Pink",
      color: "pink",
      type: "negative"
    }, void 0, false, {
      fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/molecules/Tag/Tag.stories.tsx",
      lineNumber: 230,
      columnNumber: 7
    }, this), /* @__PURE__ */jsxDEV(Tag, {
      text: "Purple",
      color: "purple",
      type: "negative"
    }, void 0, false, {
      fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/molecules/Tag/Tag.stories.tsx",
      lineNumber: 231,
      columnNumber: 7
    }, this)]
  }, void 0, true, {
    fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/molecules/Tag/Tag.stories.tsx",
    lineNumber: 224,
    columnNumber: 3
  }, this),
  parameters: {
    docs: {
      description: {
        story: "Showcase de todos los colores disponibles en tipo negativo"
      }
    }
  }
};
export const TagShowcase = {
  render: () => /* @__PURE__ */jsxDEV("div", {
    className: "space-y-6",
    children: [/* @__PURE__ */jsxDEV("div", {
      children: [/* @__PURE__ */jsxDEV("h3", {
        className: "text-lg font-semibold mb-3",
        children: "Tamaños"
      }, void 0, false, {
        fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/molecules/Tag/Tag.stories.tsx",
        lineNumber: 248,
        columnNumber: 9
      }, this), /* @__PURE__ */jsxDEV("div", {
        className: "flex items-center gap-4",
        children: [/* @__PURE__ */jsxDEV(Tag, {
          text: "Small",
          size: "s",
          color: "blue"
        }, void 0, false, {
          fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/molecules/Tag/Tag.stories.tsx",
          lineNumber: 250,
          columnNumber: 11
        }, this), /* @__PURE__ */jsxDEV(Tag, {
          text: "Medium",
          size: "m",
          color: "green"
        }, void 0, false, {
          fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/molecules/Tag/Tag.stories.tsx",
          lineNumber: 251,
          columnNumber: 11
        }, this), /* @__PURE__ */jsxDEV(Tag, {
          text: "Large",
          size: "l",
          color: "purple"
        }, void 0, false, {
          fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/molecules/Tag/Tag.stories.tsx",
          lineNumber: 252,
          columnNumber: 11
        }, this)]
      }, void 0, true, {
        fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/molecules/Tag/Tag.stories.tsx",
        lineNumber: 249,
        columnNumber: 9
      }, this)]
    }, void 0, true, {
      fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/molecules/Tag/Tag.stories.tsx",
      lineNumber: 247,
      columnNumber: 7
    }, this), /* @__PURE__ */jsxDEV("div", {
      children: [/* @__PURE__ */jsxDEV("h3", {
        className: "text-lg font-semibold mb-3",
        children: "Variaciones de iconos"
      }, void 0, false, {
        fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/molecules/Tag/Tag.stories.tsx",
        lineNumber: 257,
        columnNumber: 9
      }, this), /* @__PURE__ */jsxDEV("div", {
        className: "flex flex-wrap gap-2",
        children: [/* @__PURE__ */jsxDEV(Tag, {
          text: "Ambos iconos",
          startIcon: true,
          endIcon: true
        }, void 0, false, {
          fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/molecules/Tag/Tag.stories.tsx",
          lineNumber: 259,
          columnNumber: 11
        }, this), /* @__PURE__ */jsxDEV(Tag, {
          text: "Solo inicio",
          startIcon: true,
          endIcon: false
        }, void 0, false, {
          fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/molecules/Tag/Tag.stories.tsx",
          lineNumber: 260,
          columnNumber: 11
        }, this), /* @__PURE__ */jsxDEV(Tag, {
          text: "Solo final",
          startIcon: false,
          endIcon: true
        }, void 0, false, {
          fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/molecules/Tag/Tag.stories.tsx",
          lineNumber: 261,
          columnNumber: 11
        }, this), /* @__PURE__ */jsxDEV(Tag, {
          text: "Sin iconos",
          startIcon: false,
          endIcon: false
        }, void 0, false, {
          fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/molecules/Tag/Tag.stories.tsx",
          lineNumber: 262,
          columnNumber: 11
        }, this)]
      }, void 0, true, {
        fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/molecules/Tag/Tag.stories.tsx",
        lineNumber: 258,
        columnNumber: 9
      }, this)]
    }, void 0, true, {
      fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/molecules/Tag/Tag.stories.tsx",
      lineNumber: 256,
      columnNumber: 7
    }, this), /* @__PURE__ */jsxDEV("div", {
      children: [/* @__PURE__ */jsxDEV("h3", {
        className: "text-lg font-semibold mb-3",
        children: "Tipos"
      }, void 0, false, {
        fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/molecules/Tag/Tag.stories.tsx",
        lineNumber: 267,
        columnNumber: 9
      }, this), /* @__PURE__ */jsxDEV("div", {
        className: "flex flex-wrap gap-2",
        children: [/* @__PURE__ */jsxDEV(Tag, {
          text: "Positivo",
          type: "positive",
          color: "green"
        }, void 0, false, {
          fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/molecules/Tag/Tag.stories.tsx",
          lineNumber: 269,
          columnNumber: 11
        }, this), /* @__PURE__ */jsxDEV(Tag, {
          text: "Negativo",
          type: "negative",
          color: "blue"
        }, void 0, false, {
          fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/molecules/Tag/Tag.stories.tsx",
          lineNumber: 270,
          columnNumber: 11
        }, this)]
      }, void 0, true, {
        fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/molecules/Tag/Tag.stories.tsx",
        lineNumber: 268,
        columnNumber: 9
      }, this)]
    }, void 0, true, {
      fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/molecules/Tag/Tag.stories.tsx",
      lineNumber: 266,
      columnNumber: 7
    }, this)]
  }, void 0, true, {
    fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/molecules/Tag/Tag.stories.tsx",
    lineNumber: 246,
    columnNumber: 3
  }, this),
  parameters: {
    docs: {
      description: {
        story: "Showcase completo del componente Tag con todas sus variaciones"
      }
    }
  }
};
Default.parameters = {
  ...Default.parameters,
  docs: {
    ...Default.parameters?.docs,
    source: {
      originalSource: "{\n  args: {\n    text: 'Tag'\n  },\n  parameters: {\n    docs: {\n      description: {\n        story: 'Tag por defecto con configuraci\xF3n est\xE1ndar'\n      }\n    }\n  }\n}",
      ...Default.parameters?.docs?.source
    }
  }
};
WithoutIcons.parameters = {
  ...WithoutIcons.parameters,
  docs: {
    ...WithoutIcons.parameters?.docs,
    source: {
      originalSource: "{\n  args: {\n    text: 'Sin iconos',\n    startIcon: false,\n    endIcon: false\n  },\n  parameters: {\n    docs: {\n      description: {\n        story: 'Tag sin iconos, solo texto'\n      }\n    }\n  }\n}",
      ...WithoutIcons.parameters?.docs?.source
    }
  }
};
OnlyStartIcon.parameters = {
  ...OnlyStartIcon.parameters,
  docs: {
    ...OnlyStartIcon.parameters?.docs,
    source: {
      originalSource: "{\n  args: {\n    text: 'Con inicio',\n    startIcon: true,\n    endIcon: false\n  },\n  parameters: {\n    docs: {\n      description: {\n        story: 'Tag solo con icono de inicio (arrow-left)'\n      }\n    }\n  }\n}",
      ...OnlyStartIcon.parameters?.docs?.source
    }
  }
};
OnlyEndIcon.parameters = {
  ...OnlyEndIcon.parameters,
  docs: {
    ...OnlyEndIcon.parameters?.docs,
    source: {
      originalSource: "{\n  args: {\n    text: 'Con final',\n    startIcon: false,\n    endIcon: true\n  },\n  parameters: {\n    docs: {\n      description: {\n        story: 'Tag solo con icono final (x)'\n      }\n    }\n  }\n}",
      ...OnlyEndIcon.parameters?.docs?.source
    }
  }
};
Small.parameters = {
  ...Small.parameters,
  docs: {
    ...Small.parameters?.docs,
    source: {
      originalSource: "{\n  args: {\n    text: 'Peque\xF1o',\n    size: 's'\n  },\n  parameters: {\n    docs: {\n      description: {\n        story: 'Tag tama\xF1o peque\xF1o'\n      }\n    }\n  }\n}",
      ...Small.parameters?.docs?.source
    }
  }
};
Medium.parameters = {
  ...Medium.parameters,
  docs: {
    ...Medium.parameters?.docs,
    source: {
      originalSource: "{\n  args: {\n    text: 'Mediano',\n    size: 'm'\n  },\n  parameters: {\n    docs: {\n      description: {\n        story: 'Tag tama\xF1o mediano (por defecto)'\n      }\n    }\n  }\n}",
      ...Medium.parameters?.docs?.source
    }
  }
};
Large.parameters = {
  ...Large.parameters,
  docs: {
    ...Large.parameters?.docs,
    source: {
      originalSource: "{\n  args: {\n    text: 'Grande',\n    size: 'l'\n  },\n  parameters: {\n    docs: {\n      description: {\n        story: 'Tag tama\xF1o grande'\n      }\n    }\n  }\n}",
      ...Large.parameters?.docs?.source
    }
  }
};
Positive.parameters = {
  ...Positive.parameters,
  docs: {
    ...Positive.parameters?.docs,
    source: {
      originalSource: "{\n  args: {\n    text: 'Positivo',\n    type: 'positive',\n    color: 'green'\n  },\n  parameters: {\n    docs: {\n      description: {\n        story: 'Tag tipo positivo con fondo claro'\n      }\n    }\n  }\n}",
      ...Positive.parameters?.docs?.source
    }
  }
};
Negative.parameters = {
  ...Negative.parameters,
  docs: {
    ...Negative.parameters?.docs,
    source: {
      originalSource: "{\n  args: {\n    text: 'Negativo',\n    type: 'negative',\n    color: 'blue'\n  },\n  parameters: {\n    docs: {\n      description: {\n        story: 'Tag tipo negativo con fondo oscuro'\n      }\n    }\n  }\n}",
      ...Negative.parameters?.docs?.source
    }
  }
};
PositiveColors.parameters = {
  ...PositiveColors.parameters,
  docs: {
    ...PositiveColors.parameters?.docs,
    source: {
      originalSource: "{\n  render: () => <div className=\"flex flex-wrap gap-2\">\n      <Tag text=\"Yellow\" color=\"yellow\" type=\"positive\" />\n      <Tag text=\"Gray\" color=\"gray\" type=\"positive\" />\n      <Tag text=\"Blue\" color=\"blue\" type=\"positive\" />\n      <Tag text=\"Green\" color=\"green\" type=\"positive\" />\n      <Tag text=\"Orange\" color=\"orange\" type=\"positive\" />\n      <Tag text=\"Pink\" color=\"pink\" type=\"positive\" />\n      <Tag text=\"Purple\" color=\"purple\" type=\"positive\" />\n    </div>,\n  parameters: {\n    docs: {\n      description: {\n        story: 'Showcase de todos los colores disponibles en tipo positivo'\n      }\n    }\n  }\n}",
      ...PositiveColors.parameters?.docs?.source
    }
  }
};
NegativeColors.parameters = {
  ...NegativeColors.parameters,
  docs: {
    ...NegativeColors.parameters?.docs,
    source: {
      originalSource: "{\n  render: () => <div className=\"flex flex-wrap gap-2\">\n      <Tag text=\"Yellow\" color=\"yellow\" type=\"negative\" />\n      <Tag text=\"Gray\" color=\"gray\" type=\"negative\" />\n      <Tag text=\"Blue\" color=\"blue\" type=\"negative\" />\n      <Tag text=\"Green\" color=\"green\" type=\"negative\" />\n      <Tag text=\"Orange\" color=\"orange\" type=\"negative\" />\n      <Tag text=\"Pink\" color=\"pink\" type=\"negative\" />\n      <Tag text=\"Purple\" color=\"purple\" type=\"negative\" />\n    </div>,\n  parameters: {\n    docs: {\n      description: {\n        story: 'Showcase de todos los colores disponibles en tipo negativo'\n      }\n    }\n  }\n}",
      ...NegativeColors.parameters?.docs?.source
    }
  }
};
TagShowcase.parameters = {
  ...TagShowcase.parameters,
  docs: {
    ...TagShowcase.parameters?.docs,
    source: {
      originalSource: "{\n  render: () => <div className=\"space-y-6\">\n      <div>\n        <h3 className=\"text-lg font-semibold mb-3\">Tama\xF1os</h3>\n        <div className=\"flex items-center gap-4\">\n          <Tag text=\"Small\" size=\"s\" color=\"blue\" />\n          <Tag text=\"Medium\" size=\"m\" color=\"green\" />\n          <Tag text=\"Large\" size=\"l\" color=\"purple\" />\n        </div>\n      </div>\n\n      <div>\n        <h3 className=\"text-lg font-semibold mb-3\">Variaciones de iconos</h3>\n        <div className=\"flex flex-wrap gap-2\">\n          <Tag text=\"Ambos iconos\" startIcon endIcon />\n          <Tag text=\"Solo inicio\" startIcon endIcon={false} />\n          <Tag text=\"Solo final\" startIcon={false} endIcon />\n          <Tag text=\"Sin iconos\" startIcon={false} endIcon={false} />\n        </div>\n      </div>\n\n      <div>\n        <h3 className=\"text-lg font-semibold mb-3\">Tipos</h3>\n        <div className=\"flex flex-wrap gap-2\">\n          <Tag text=\"Positivo\" type=\"positive\" color=\"green\" />\n          <Tag text=\"Negativo\" type=\"negative\" color=\"blue\" />\n        </div>\n      </div>\n    </div>,\n  parameters: {\n    docs: {\n      description: {\n        story: 'Showcase completo del componente Tag con todas sus variaciones'\n      }\n    }\n  }\n}",
      ...TagShowcase.parameters?.docs?.source
    }
  }
};;export const __namedExportsOrder = ["Default","WithoutIcons","OnlyStartIcon","OnlyEndIcon","Small","Medium","Large","Positive","Negative","PositiveColors","NegativeColors","TagShowcase"];