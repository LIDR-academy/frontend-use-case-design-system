import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/molecules/Tag/Tag.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.cache/sb-vite/deps/react_jsx-dev-runtime.js?v=77221ebe"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import { Icon } from "/src/components/atoms/Icon/Icon.tsx";
export const Tag = ({
  endIcon = true,
  startIcon = true,
  showText = true,
  text = "Tag",
  color = "blue",
  size = "m",
  type = "positive",
  className = "",
  onClick
}) => {
  const sizeClasses = {
    s: "px-2 py-1 text-xs gap-1",
    m: "px-3 py-1.5 text-sm gap-2",
    l: "px-4 py-2 text-base gap-2"
  };
  const colorClasses = {
    positive: {
      yellow: "bg-yellow-100 text-yellow-800 border-yellow-200",
      gray: "bg-gray-100 text-gray-800 border-gray-200",
      blue: "bg-blue-100 text-blue-800 border-blue-200",
      green: "bg-green-100 text-green-800 border-green-200",
      orange: "bg-orange-100 text-orange-800 border-orange-200",
      pink: "bg-pink-100 text-pink-800 border-pink-200",
      purple: "bg-purple-100 text-purple-800 border-purple-200"
    },
    negative: {
      yellow: "bg-yellow-800 text-yellow-100 border-yellow-700",
      gray: "bg-gray-800 text-gray-100 border-gray-700",
      blue: "bg-blue-800 text-blue-100 border-blue-700",
      green: "bg-green-800 text-green-100 border-green-700",
      orange: "bg-orange-800 text-orange-100 border-orange-700",
      pink: "bg-pink-800 text-pink-100 border-pink-700",
      purple: "bg-purple-800 text-purple-100 border-purple-700"
    }
  };
  const iconColorClasses = {
    positive: {
      yellow: "text-yellow-800",
      gray: "text-gray-800",
      blue: "text-blue-800",
      green: "text-green-800",
      orange: "text-orange-800",
      pink: "text-pink-800",
      purple: "text-purple-800"
    },
    negative: {
      yellow: "text-yellow-100",
      gray: "text-gray-100",
      blue: "text-blue-100",
      green: "text-green-100",
      orange: "text-orange-100",
      pink: "text-pink-100",
      purple: "text-purple-100"
    }
  };
  const iconSize = size === "s" ? "xs" : size === "m" ? "sm" : "md";
  const baseClasses = "inline-flex items-center border rounded-full font-medium";
  const appliedColorClasses = colorClasses[type][color];
  const appliedSizeClasses = sizeClasses[size];
  const iconColorClass = iconColorClasses[type][color];
  return /* @__PURE__ */ jsxDEV(
    "div",
    {
      className: `${baseClasses} ${appliedColorClasses} ${appliedSizeClasses} ${className}`,
      onClick,
      role: onClick ? "button" : void 0,
      tabIndex: onClick ? 0 : void 0,
      children: [
        startIcon && /* @__PURE__ */ jsxDEV(Icon, { name: "arrow-left", size: iconSize, className: iconColorClass }, void 0, false, {
          fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/molecules/Tag/Tag.tsx",
          lineNumber: 91,
          columnNumber: 7
        }, this),
        showText && /* @__PURE__ */ jsxDEV("span", { children: text }, void 0, false, {
          fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/molecules/Tag/Tag.tsx",
          lineNumber: 94,
          columnNumber: 20
        }, this),
        endIcon && /* @__PURE__ */ jsxDEV(Icon, { name: "x", size: iconSize, className: iconColorClass }, void 0, false, {
          fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/molecules/Tag/Tag.tsx",
          lineNumber: 96,
          columnNumber: 19
        }, this)
      ]
    },
    void 0,
    true,
    {
      fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/molecules/Tag/Tag.tsx",
      lineNumber: 84,
      columnNumber: 5
    },
    this
  );
};
_c = Tag;
var _c;
$RefreshReg$(_c, "Tag");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/molecules/Tag/Tag.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/molecules/Tag/Tag.tsx", currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/molecules/Tag/Tag.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBMEZRO0FBekZSLFNBQVNBLFlBQVk7QUFjZCxhQUFNQyxNQUEwQkEsQ0FBQztBQUFBLEVBQ3RDQyxVQUFVO0FBQUEsRUFDVkMsWUFBWTtBQUFBLEVBQ1pDLFdBQVc7QUFBQSxFQUNYQyxPQUFPO0FBQUEsRUFDUEMsUUFBUTtBQUFBLEVBQ1JDLE9BQU87QUFBQSxFQUNQQyxPQUFPO0FBQUEsRUFDUEMsWUFBWTtBQUFBLEVBQ1pDO0FBQ0YsTUFBTTtBQUNKLFFBQU1DLGNBQWM7QUFBQSxJQUNsQkMsR0FBRztBQUFBLElBQ0hDLEdBQUc7QUFBQSxJQUNIQyxHQUFHO0FBQUEsRUFDTDtBQUVBLFFBQU1DLGVBQWU7QUFBQSxJQUNuQkMsVUFBVTtBQUFBLE1BQ1JDLFFBQVE7QUFBQSxNQUNSQyxNQUFNO0FBQUEsTUFDTkMsTUFBTTtBQUFBLE1BQ05DLE9BQU87QUFBQSxNQUNQQyxRQUFRO0FBQUEsTUFDUkMsTUFBTTtBQUFBLE1BQ05DLFFBQVE7QUFBQSxJQUNWO0FBQUEsSUFDQUMsVUFBVTtBQUFBLE1BQ1JQLFFBQVE7QUFBQSxNQUNSQyxNQUFNO0FBQUEsTUFDTkMsTUFBTTtBQUFBLE1BQ05DLE9BQU87QUFBQSxNQUNQQyxRQUFRO0FBQUEsTUFDUkMsTUFBTTtBQUFBLE1BQ05DLFFBQVE7QUFBQSxJQUNWO0FBQUEsRUFDRjtBQUVBLFFBQU1FLG1CQUFtQjtBQUFBLElBQ3ZCVCxVQUFVO0FBQUEsTUFDUkMsUUFBUTtBQUFBLE1BQ1JDLE1BQU07QUFBQSxNQUNOQyxNQUFNO0FBQUEsTUFDTkMsT0FBTztBQUFBLE1BQ1BDLFFBQVE7QUFBQSxNQUNSQyxNQUFNO0FBQUEsTUFDTkMsUUFBUTtBQUFBLElBQ1Y7QUFBQSxJQUNBQyxVQUFVO0FBQUEsTUFDUlAsUUFBUTtBQUFBLE1BQ1JDLE1BQU07QUFBQSxNQUNOQyxNQUFNO0FBQUEsTUFDTkMsT0FBTztBQUFBLE1BQ1BDLFFBQVE7QUFBQSxNQUNSQyxNQUFNO0FBQUEsTUFDTkMsUUFBUTtBQUFBLElBQ1Y7QUFBQSxFQUNGO0FBRUEsUUFBTUcsV0FBV25CLFNBQVMsTUFBTSxPQUFPQSxTQUFTLE1BQU0sT0FBTztBQUU3RCxRQUFNb0IsY0FDSjtBQUNGLFFBQU1DLHNCQUFzQmIsYUFBYVAsSUFBSSxFQUFFRixLQUFLO0FBQ3BELFFBQU11QixxQkFBcUJsQixZQUFZSixJQUFJO0FBQzNDLFFBQU11QixpQkFBaUJMLGlCQUFpQmpCLElBQUksRUFBRUYsS0FBSztBQUVuRCxTQUNFO0FBQUEsSUFBQztBQUFBO0FBQUEsTUFDQyxXQUFXLEdBQUdxQixlQUFlQyx1QkFBdUJDLHNCQUFzQnBCO0FBQUFBLE1BQzFFO0FBQUEsTUFDQSxNQUFNQyxVQUFVLFdBQVdxQjtBQUFBQSxNQUMzQixVQUFVckIsVUFBVSxJQUFJcUI7QUFBQUEsTUFFdkI1QjtBQUFBQSxxQkFDQyx1QkFBQyxRQUFLLE1BQUssY0FBYSxNQUFNdUIsVUFBVSxXQUFXSSxrQkFBbkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFrRTtBQUFBLFFBR25FMUIsWUFBWSx1QkFBQyxVQUFNQyxrQkFBUDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQVk7QUFBQSxRQUV4QkgsV0FBVyx1QkFBQyxRQUFLLE1BQUssS0FBSSxNQUFNd0IsVUFBVSxXQUFXSSxrQkFBMUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF5RDtBQUFBO0FBQUE7QUFBQSxJQVp2RTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFhQTtBQUVKO0FBQUVFLEtBbkZXL0I7QUFBdUIsSUFBQStCO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJJY29uIiwiVGFnIiwiZW5kSWNvbiIsInN0YXJ0SWNvbiIsInNob3dUZXh0IiwidGV4dCIsImNvbG9yIiwic2l6ZSIsInR5cGUiLCJjbGFzc05hbWUiLCJvbkNsaWNrIiwic2l6ZUNsYXNzZXMiLCJzIiwibSIsImwiLCJjb2xvckNsYXNzZXMiLCJwb3NpdGl2ZSIsInllbGxvdyIsImdyYXkiLCJibHVlIiwiZ3JlZW4iLCJvcmFuZ2UiLCJwaW5rIiwicHVycGxlIiwibmVnYXRpdmUiLCJpY29uQ29sb3JDbGFzc2VzIiwiaWNvblNpemUiLCJiYXNlQ2xhc3NlcyIsImFwcGxpZWRDb2xvckNsYXNzZXMiLCJhcHBsaWVkU2l6ZUNsYXNzZXMiLCJpY29uQ29sb3JDbGFzcyIsInVuZGVmaW5lZCIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiVGFnLnRzeCJdLCJmaWxlIjoiL2hvbWUvc3VuZGUvcHJvamVjdHMvTGlkci9mcm9udGVuZC11c2UtY2FzZS1kZXNpZ24tc3lzdGVtL3NyYy9jb21wb25lbnRzL21vbGVjdWxlcy9UYWcvVGFnLnRzeCIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyBJY29uIH0gZnJvbSAnLi4vLi4vYXRvbXMvSWNvbi9JY29uJztcblxuZXhwb3J0IGludGVyZmFjZSBUYWdQcm9wcyB7XG4gIGVuZEljb24/OiBib29sZWFuO1xuICBzdGFydEljb24/OiBib29sZWFuO1xuICBzaG93VGV4dD86IGJvb2xlYW47XG4gIHRleHQ/OiBzdHJpbmc7XG4gIGNvbG9yPzogJ3llbGxvdycgfCAnZ3JheScgfCAnYmx1ZScgfCAnZ3JlZW4nIHwgJ29yYW5nZScgfCAncGluaycgfCAncHVycGxlJztcbiAgc2l6ZT86ICdsJyB8ICdtJyB8ICdzJztcbiAgdHlwZT86ICduZWdhdGl2ZScgfCAncG9zaXRpdmUnO1xuICBjbGFzc05hbWU/OiBzdHJpbmc7XG4gIG9uQ2xpY2s/OiAoKSA9PiB2b2lkO1xufVxuXG5leHBvcnQgY29uc3QgVGFnOiBSZWFjdC5GQzxUYWdQcm9wcz4gPSAoe1xuICBlbmRJY29uID0gdHJ1ZSxcbiAgc3RhcnRJY29uID0gdHJ1ZSxcbiAgc2hvd1RleHQgPSB0cnVlLFxuICB0ZXh0ID0gJ1RhZycsXG4gIGNvbG9yID0gJ2JsdWUnLFxuICBzaXplID0gJ20nLFxuICB0eXBlID0gJ3Bvc2l0aXZlJyxcbiAgY2xhc3NOYW1lID0gJycsXG4gIG9uQ2xpY2ssXG59KSA9PiB7XG4gIGNvbnN0IHNpemVDbGFzc2VzID0ge1xuICAgIHM6ICdweC0yIHB5LTEgdGV4dC14cyBnYXAtMScsXG4gICAgbTogJ3B4LTMgcHktMS41IHRleHQtc20gZ2FwLTInLFxuICAgIGw6ICdweC00IHB5LTIgdGV4dC1iYXNlIGdhcC0yJyxcbiAgfTtcblxuICBjb25zdCBjb2xvckNsYXNzZXMgPSB7XG4gICAgcG9zaXRpdmU6IHtcbiAgICAgIHllbGxvdzogJ2JnLXllbGxvdy0xMDAgdGV4dC15ZWxsb3ctODAwIGJvcmRlci15ZWxsb3ctMjAwJyxcbiAgICAgIGdyYXk6ICdiZy1ncmF5LTEwMCB0ZXh0LWdyYXktODAwIGJvcmRlci1ncmF5LTIwMCcsXG4gICAgICBibHVlOiAnYmctYmx1ZS0xMDAgdGV4dC1ibHVlLTgwMCBib3JkZXItYmx1ZS0yMDAnLFxuICAgICAgZ3JlZW46ICdiZy1ncmVlbi0xMDAgdGV4dC1ncmVlbi04MDAgYm9yZGVyLWdyZWVuLTIwMCcsXG4gICAgICBvcmFuZ2U6ICdiZy1vcmFuZ2UtMTAwIHRleHQtb3JhbmdlLTgwMCBib3JkZXItb3JhbmdlLTIwMCcsXG4gICAgICBwaW5rOiAnYmctcGluay0xMDAgdGV4dC1waW5rLTgwMCBib3JkZXItcGluay0yMDAnLFxuICAgICAgcHVycGxlOiAnYmctcHVycGxlLTEwMCB0ZXh0LXB1cnBsZS04MDAgYm9yZGVyLXB1cnBsZS0yMDAnLFxuICAgIH0sXG4gICAgbmVnYXRpdmU6IHtcbiAgICAgIHllbGxvdzogJ2JnLXllbGxvdy04MDAgdGV4dC15ZWxsb3ctMTAwIGJvcmRlci15ZWxsb3ctNzAwJyxcbiAgICAgIGdyYXk6ICdiZy1ncmF5LTgwMCB0ZXh0LWdyYXktMTAwIGJvcmRlci1ncmF5LTcwMCcsXG4gICAgICBibHVlOiAnYmctYmx1ZS04MDAgdGV4dC1ibHVlLTEwMCBib3JkZXItYmx1ZS03MDAnLFxuICAgICAgZ3JlZW46ICdiZy1ncmVlbi04MDAgdGV4dC1ncmVlbi0xMDAgYm9yZGVyLWdyZWVuLTcwMCcsXG4gICAgICBvcmFuZ2U6ICdiZy1vcmFuZ2UtODAwIHRleHQtb3JhbmdlLTEwMCBib3JkZXItb3JhbmdlLTcwMCcsXG4gICAgICBwaW5rOiAnYmctcGluay04MDAgdGV4dC1waW5rLTEwMCBib3JkZXItcGluay03MDAnLFxuICAgICAgcHVycGxlOiAnYmctcHVycGxlLTgwMCB0ZXh0LXB1cnBsZS0xMDAgYm9yZGVyLXB1cnBsZS03MDAnLFxuICAgIH0sXG4gIH07XG5cbiAgY29uc3QgaWNvbkNvbG9yQ2xhc3NlcyA9IHtcbiAgICBwb3NpdGl2ZToge1xuICAgICAgeWVsbG93OiAndGV4dC15ZWxsb3ctODAwJyxcbiAgICAgIGdyYXk6ICd0ZXh0LWdyYXktODAwJyxcbiAgICAgIGJsdWU6ICd0ZXh0LWJsdWUtODAwJyxcbiAgICAgIGdyZWVuOiAndGV4dC1ncmVlbi04MDAnLFxuICAgICAgb3JhbmdlOiAndGV4dC1vcmFuZ2UtODAwJyxcbiAgICAgIHBpbms6ICd0ZXh0LXBpbmstODAwJyxcbiAgICAgIHB1cnBsZTogJ3RleHQtcHVycGxlLTgwMCcsXG4gICAgfSxcbiAgICBuZWdhdGl2ZToge1xuICAgICAgeWVsbG93OiAndGV4dC15ZWxsb3ctMTAwJyxcbiAgICAgIGdyYXk6ICd0ZXh0LWdyYXktMTAwJyxcbiAgICAgIGJsdWU6ICd0ZXh0LWJsdWUtMTAwJyxcbiAgICAgIGdyZWVuOiAndGV4dC1ncmVlbi0xMDAnLFxuICAgICAgb3JhbmdlOiAndGV4dC1vcmFuZ2UtMTAwJyxcbiAgICAgIHBpbms6ICd0ZXh0LXBpbmstMTAwJyxcbiAgICAgIHB1cnBsZTogJ3RleHQtcHVycGxlLTEwMCcsXG4gICAgfSxcbiAgfTtcblxuICBjb25zdCBpY29uU2l6ZSA9IHNpemUgPT09ICdzJyA/ICd4cycgOiBzaXplID09PSAnbScgPyAnc20nIDogJ21kJztcblxuICBjb25zdCBiYXNlQ2xhc3NlcyA9XG4gICAgJ2lubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBib3JkZXIgcm91bmRlZC1mdWxsIGZvbnQtbWVkaXVtJztcbiAgY29uc3QgYXBwbGllZENvbG9yQ2xhc3NlcyA9IGNvbG9yQ2xhc3Nlc1t0eXBlXVtjb2xvcl07XG4gIGNvbnN0IGFwcGxpZWRTaXplQ2xhc3NlcyA9IHNpemVDbGFzc2VzW3NpemVdO1xuICBjb25zdCBpY29uQ29sb3JDbGFzcyA9IGljb25Db2xvckNsYXNzZXNbdHlwZV1bY29sb3JdO1xuXG4gIHJldHVybiAoXG4gICAgPGRpdlxuICAgICAgY2xhc3NOYW1lPXtgJHtiYXNlQ2xhc3Nlc30gJHthcHBsaWVkQ29sb3JDbGFzc2VzfSAke2FwcGxpZWRTaXplQ2xhc3Nlc30gJHtjbGFzc05hbWV9YH1cbiAgICAgIG9uQ2xpY2s9e29uQ2xpY2t9XG4gICAgICByb2xlPXtvbkNsaWNrID8gJ2J1dHRvbicgOiB1bmRlZmluZWR9XG4gICAgICB0YWJJbmRleD17b25DbGljayA/IDAgOiB1bmRlZmluZWR9XG4gICAgPlxuICAgICAge3N0YXJ0SWNvbiAmJiAoXG4gICAgICAgIDxJY29uIG5hbWU9XCJhcnJvdy1sZWZ0XCIgc2l6ZT17aWNvblNpemV9IGNsYXNzTmFtZT17aWNvbkNvbG9yQ2xhc3N9IC8+XG4gICAgICApfVxuXG4gICAgICB7c2hvd1RleHQgJiYgPHNwYW4+e3RleHR9PC9zcGFuPn1cblxuICAgICAge2VuZEljb24gJiYgPEljb24gbmFtZT1cInhcIiBzaXplPXtpY29uU2l6ZX0gY2xhc3NOYW1lPXtpY29uQ29sb3JDbGFzc30gLz59XG4gICAgPC9kaXY+XG4gICk7XG59O1xuIl19