import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/atoms/Icon/Icon.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.cache/sb-vite/deps/react_jsx-dev-runtime.js?v=77221ebe"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$();
import __vite__cjsImport1_react from "/node_modules/.cache/sb-vite/deps/react.js?v=77221ebe"; const React = __vite__cjsImport1_react.__esModule ? __vite__cjsImport1_react.default : __vite__cjsImport1_react; const useReducer = __vite__cjsImport1_react["useReducer"]; const useCallback = __vite__cjsImport1_react["useCallback"];
const icons = {
  leaf: /* @__PURE__ */ jsxDEV(
    "svg",
    {
      xmlns: "http://www.w3.org/2000/svg",
      width: "24",
      height: "24",
      viewBox: "0 0 24 24",
      fill: "none",
      stroke: "currentColor",
      strokeWidth: "2",
      strokeLinecap: "round",
      strokeLinejoin: "round",
      children: [
        /* @__PURE__ */ jsxDEV("path", { d: "M11 20A7 7 0 0 1 9.8 6.1C15.5 5 17 4.48 19 2c1 2 2 4.18 2 8 0 5.5-4.78 10-10 10Z" }, void 0, false, {
          fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/atoms/Icon/Icon.tsx",
          lineNumber: 17,
          columnNumber: 7
        }, this),
        /* @__PURE__ */ jsxDEV("path", { d: "M2 21c0-3 1.85-5.36 5.08-6C9.5 14.52 12 13 13 12" }, void 0, false, {
          fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/atoms/Icon/Icon.tsx",
          lineNumber: 18,
          columnNumber: 7
        }, this)
      ]
    },
    void 0,
    true,
    {
      fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/atoms/Icon/Icon.tsx",
      lineNumber: 6,
      columnNumber: 3
    },
    this
  ),
  accessibility: /* @__PURE__ */ jsxDEV(
    "svg",
    {
      xmlns: "http://www.w3.org/2000/svg",
      width: "24",
      height: "24",
      viewBox: "0 0 24 24",
      fill: "none",
      stroke: "currentColor",
      strokeWidth: "2",
      strokeLinecap: "round",
      strokeLinejoin: "round",
      children: [
        /* @__PURE__ */ jsxDEV("circle", { cx: "16", cy: "4", r: "1" }, void 0, false, {
          fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/atoms/Icon/Icon.tsx",
          lineNumber: 33,
          columnNumber: 7
        }, this),
        /* @__PURE__ */ jsxDEV("path", { d: "m18 19 1-7-6 1" }, void 0, false, {
          fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/atoms/Icon/Icon.tsx",
          lineNumber: 34,
          columnNumber: 7
        }, this),
        /* @__PURE__ */ jsxDEV("path", { d: "m5 8 3-3 5.5 3-2.36 3.5" }, void 0, false, {
          fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/atoms/Icon/Icon.tsx",
          lineNumber: 35,
          columnNumber: 7
        }, this),
        /* @__PURE__ */ jsxDEV("path", { d: "M4.24 14.5a5 5 0 0 0 6.88 6" }, void 0, false, {
          fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/atoms/Icon/Icon.tsx",
          lineNumber: 36,
          columnNumber: 7
        }, this),
        /* @__PURE__ */ jsxDEV("path", { d: "M13.76 17.5a5 5 0 0 0-6.88-6" }, void 0, false, {
          fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/atoms/Icon/Icon.tsx",
          lineNumber: 37,
          columnNumber: 7
        }, this)
      ]
    },
    void 0,
    true,
    {
      fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/atoms/Icon/Icon.tsx",
      lineNumber: 22,
      columnNumber: 3
    },
    this
  ),
  x: /* @__PURE__ */ jsxDEV(
    "svg",
    {
      xmlns: "http://www.w3.org/2000/svg",
      width: "24",
      height: "24",
      viewBox: "0 0 24 24",
      fill: "none",
      stroke: "currentColor",
      strokeWidth: "2",
      strokeLinecap: "round",
      strokeLinejoin: "round",
      children: [
        /* @__PURE__ */ jsxDEV("path", { d: "M18 6 6 18" }, void 0, false, {
          fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/atoms/Icon/Icon.tsx",
          lineNumber: 52,
          columnNumber: 7
        }, this),
        /* @__PURE__ */ jsxDEV("path", { d: "m6 6 12 12" }, void 0, false, {
          fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/atoms/Icon/Icon.tsx",
          lineNumber: 53,
          columnNumber: 7
        }, this)
      ]
    },
    void 0,
    true,
    {
      fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/atoms/Icon/Icon.tsx",
      lineNumber: 41,
      columnNumber: 3
    },
    this
  ),
  handshake: /* @__PURE__ */ jsxDEV(
    "svg",
    {
      xmlns: "http://www.w3.org/2000/svg",
      width: "24",
      height: "24",
      viewBox: "0 0 24 24",
      fill: "none",
      stroke: "currentColor",
      strokeWidth: "2",
      strokeLinecap: "round",
      strokeLinejoin: "round",
      children: [
        /* @__PURE__ */ jsxDEV("path", { d: "m11 17 2 2a1 1 0 1 0 3-3" }, void 0, false, {
          fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/atoms/Icon/Icon.tsx",
          lineNumber: 68,
          columnNumber: 7
        }, this),
        /* @__PURE__ */ jsxDEV("path", { d: "m14 14 2.5 2.5a1 1 0 1 0 3-3l-3.88-3.88a3 3 0 0 0-4.24 0l-.88.88a1 1 0 1 1-3-3l2.81-2.81a5.79 5.79 0 0 1 7.06-.87l.47.28a2 2 0 0 0 1.42.25L21 4" }, void 0, false, {
          fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/atoms/Icon/Icon.tsx",
          lineNumber: 69,
          columnNumber: 7
        }, this),
        /* @__PURE__ */ jsxDEV("path", { d: "m21 3 1 11h-2" }, void 0, false, {
          fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/atoms/Icon/Icon.tsx",
          lineNumber: 70,
          columnNumber: 7
        }, this),
        /* @__PURE__ */ jsxDEV("path", { d: "M3 3 2 14l6.5 6.5a1 1 0 1 0 3-3" }, void 0, false, {
          fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/atoms/Icon/Icon.tsx",
          lineNumber: 71,
          columnNumber: 7
        }, this),
        /* @__PURE__ */ jsxDEV("path", { d: "M3 4h8" }, void 0, false, {
          fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/atoms/Icon/Icon.tsx",
          lineNumber: 72,
          columnNumber: 7
        }, this)
      ]
    },
    void 0,
    true,
    {
      fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/atoms/Icon/Icon.tsx",
      lineNumber: 57,
      columnNumber: 3
    },
    this
  ),
  "arrow-left": /* @__PURE__ */ jsxDEV(
    "svg",
    {
      xmlns: "http://www.w3.org/2000/svg",
      width: "24",
      height: "24",
      viewBox: "0 0 24 24",
      fill: "none",
      stroke: "currentColor",
      strokeWidth: "2",
      strokeLinecap: "round",
      strokeLinejoin: "round",
      children: [
        /* @__PURE__ */ jsxDEV("path", { d: "m12 19-7-7 7-7" }, void 0, false, {
          fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/atoms/Icon/Icon.tsx",
          lineNumber: 87,
          columnNumber: 7
        }, this),
        /* @__PURE__ */ jsxDEV("path", { d: "M19 12H5" }, void 0, false, {
          fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/atoms/Icon/Icon.tsx",
          lineNumber: 88,
          columnNumber: 7
        }, this)
      ]
    },
    void 0,
    true,
    {
      fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/atoms/Icon/Icon.tsx",
      lineNumber: 76,
      columnNumber: 3
    },
    this
  )
};
function iconStateReducer(state, action) {
  if (state.colorVariant === "primary" && state.state === "hover") {
    switch (action) {
      case "mouse_leave":
        return { colorVariant: "primary", state: "default" };
      case "focus":
        return { ...state, state: "focus" };
      case "blur":
        return { ...state, state: "default" };
    }
  }
  if (state.colorVariant === "secondary" && state.state === "hover") {
    switch (action) {
      case "mouse_leave":
        return { colorVariant: "secondary", state: "default" };
      case "focus":
        return { ...state, state: "focus" };
      case "blur":
        return { ...state, state: "default" };
    }
  }
  if (state.colorVariant === "tertiary" && state.state === "hover") {
    switch (action) {
      case "mouse_leave":
        return { colorVariant: "tertiary", state: "default" };
      case "focus":
        return { ...state, state: "focus" };
      case "blur":
        return { ...state, state: "default" };
    }
  }
  switch (action) {
    case "mouse_enter":
      return { ...state, state: "hover" };
    case "mouse_leave":
      return { ...state, state: "default" };
    case "focus":
      return { ...state, state: "focus" };
    case "blur":
      return { ...state, state: "default" };
    case "disable":
      return { ...state, state: "disabled" };
    case "enable":
      return { ...state, state: "default" };
    default:
      return state;
  }
}
export const Icon = ({
  name,
  size = "md",
  color = "foreground",
  colorVariant = "primary",
  state: controlledState,
  interactive = false,
  disabled = false,
  className = "",
  onStateChange,
  onMouseEnter,
  onMouseLeave,
  onFocus,
  onBlur,
  ...props
}) => {
  _s();
  const [internalState, dispatch] = useReducer(iconStateReducer, {
    colorVariant,
    state: disabled ? "disabled" : controlledState || "default"
  });
  const currentState = controlledState || internalState.state;
  const sizeClasses = {
    xs: "w-3 h-3",
    sm: "w-4 h-4",
    md: "w-6 h-6",
    lg: "w-8 h-8",
    xl: "w-10 h-10"
  };
  const colorClasses = {
    primary: "text-primary",
    secondary: "text-secondary",
    muted: "text-muted-foreground",
    destructive: "text-destructive",
    foreground: "text-foreground"
  };
  const getInteractiveColor = () => {
    if (!interactive)
      return colorClasses[color];
    const variant = internalState.colorVariant;
    const state = currentState;
    if (variant === "primary") {
      switch (state) {
        case "hover":
        case "focus":
          return "text-primary-600 transition-colors duration-200";
        case "disabled":
          return "text-gray-400";
        default:
          return "text-primary transition-colors duration-200";
      }
    }
    if (variant === "secondary") {
      switch (state) {
        case "hover":
        case "focus":
          return "text-white transition-colors duration-200";
        case "disabled":
          return "text-gray-400";
        default:
          return "text-white transition-colors duration-200";
      }
    }
    if (variant === "tertiary") {
      switch (state) {
        case "hover":
        case "focus":
          return "text-gray-700 transition-colors duration-200";
        case "disabled":
          return "text-gray-400";
        default:
          return "text-gray-600 transition-colors duration-200";
      }
    }
    return colorClasses[color];
  };
  const handleMouseEnter = useCallback(
    (event) => {
      if (interactive && !disabled) {
        dispatch("mouse_enter");
        onStateChange?.("hover");
      }
      onMouseEnter?.(event);
    },
    [interactive, disabled, onStateChange, onMouseEnter]
  );
  const handleMouseLeave = useCallback(
    (event) => {
      if (interactive && !disabled) {
        dispatch("mouse_leave");
        onStateChange?.("default");
      }
      onMouseLeave?.(event);
    },
    [interactive, disabled, onStateChange, onMouseLeave]
  );
  const handleFocus = useCallback(
    (event) => {
      if (interactive && !disabled) {
        dispatch("focus");
        onStateChange?.("focus");
      }
      onFocus?.(event);
    },
    [interactive, disabled, onStateChange, onFocus]
  );
  const handleBlur = useCallback(
    (event) => {
      if (interactive && !disabled) {
        dispatch("blur");
        onStateChange?.("default");
      }
      onBlur?.(event);
    },
    [interactive, disabled, onStateChange, onBlur]
  );
  const iconElement = icons[name];
  if (!iconElement) {
    console.warn(`Icon "${name}" not found`);
    return null;
  }
  const appliedColor = getInteractiveColor();
  const stateClasses = interactive ? `cursor-pointer ${disabled ? "cursor-not-allowed opacity-50" : ""}` : "";
  const focusClasses = interactive && !disabled ? "focus:outline-none focus:ring-2 focus:ring-primary focus:ring-offset-1 rounded" : "";
  const iconWithClasses = React.cloneElement(iconElement, {
    className: `${sizeClasses[size]} ${appliedColor}`
  });
  if (interactive) {
    const {
      // SVG attributes that should not be passed to span
      // fill,
      // stroke,
      // strokeWidth,
      // strokeLinecap,
      // strokeLinejoin,
      // strokeDasharray,
      // strokeDashoffset,
      // pathLength,
      // clipPath,
      // mask,
      // filter,
      // opacity,
      // transform,
      // style,
      // // Event handlers that should not be passed to span
      // onCopy,
      // onCut,
      // onPaste,
      // onCompositionEnd,
      // onCompositionStart,
      // onCompositionUpdate,
      // onSelect,
      // onBeforeInput,
      // onInput,
      ...spanProps
    } = props;
    return /* @__PURE__ */ jsxDEV(
      "span",
      {
        className: `inline-block ${stateClasses} ${focusClasses} ${className}`,
        onMouseEnter: handleMouseEnter,
        onMouseLeave: handleMouseLeave,
        onFocus: handleFocus,
        onBlur: handleBlur,
        tabIndex: disabled ? void 0 : 0,
        role: "button",
        "aria-disabled": disabled,
        ...spanProps,
        children: iconWithClasses
      },
      void 0,
      false,
      {
        fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/atoms/Icon/Icon.tsx",
        lineNumber: 352,
        columnNumber: 7
      },
      this
    );
  }
  return React.cloneElement(iconElement, {
    className: `${sizeClasses[size]} ${appliedColor} ${className}`,
    ...props
  });
};
_s(Icon, "C6J5v6HJVtZmQV0oCq7+v7enxcQ=");
_c = Icon;
var _c;
$RefreshReg$(_c, "Icon");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/atoms/Icon/Icon.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/atoms/Icon/Icon.tsx", currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/atoms/Icon/Icon.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBZ0JNOztBQWhCTixPQUFPQSxTQUFTQyxZQUFZQyxtQkFBbUI7QUFHL0MsTUFBTUMsUUFBUTtBQUFBLEVBQ1pDLE1BQ0U7QUFBQSxJQUFDO0FBQUE7QUFBQSxNQUNDLE9BQU07QUFBQSxNQUNOLE9BQU07QUFBQSxNQUNOLFFBQU87QUFBQSxNQUNQLFNBQVE7QUFBQSxNQUNSLE1BQUs7QUFBQSxNQUNMLFFBQU87QUFBQSxNQUNQLGFBQVk7QUFBQSxNQUNaLGVBQWM7QUFBQSxNQUNkLGdCQUFlO0FBQUEsTUFFZjtBQUFBLCtCQUFDLFVBQUssR0FBRSxzRkFBUjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTBGO0FBQUEsUUFDMUYsdUJBQUMsVUFBSyxHQUFFLHNEQUFSO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBMEQ7QUFBQTtBQUFBO0FBQUEsSUFaNUQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBYUE7QUFBQSxFQUVGQyxlQUNFO0FBQUEsSUFBQztBQUFBO0FBQUEsTUFDQyxPQUFNO0FBQUEsTUFDTixPQUFNO0FBQUEsTUFDTixRQUFPO0FBQUEsTUFDUCxTQUFRO0FBQUEsTUFDUixNQUFLO0FBQUEsTUFDTCxRQUFPO0FBQUEsTUFDUCxhQUFZO0FBQUEsTUFDWixlQUFjO0FBQUEsTUFDZCxnQkFBZTtBQUFBLE1BRWY7QUFBQSwrQkFBQyxZQUFPLElBQUcsTUFBSyxJQUFHLEtBQUksR0FBRSxPQUF6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTRCO0FBQUEsUUFDNUIsdUJBQUMsVUFBSyxHQUFFLG9CQUFSO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBd0I7QUFBQSxRQUN4Qix1QkFBQyxVQUFLLEdBQUUsNkJBQVI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFpQztBQUFBLFFBQ2pDLHVCQUFDLFVBQUssR0FBRSxpQ0FBUjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXFDO0FBQUEsUUFDckMsdUJBQUMsVUFBSyxHQUFFLGtDQUFSO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBc0M7QUFBQTtBQUFBO0FBQUEsSUFmeEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBZ0JBO0FBQUEsRUFFRkMsR0FDRTtBQUFBLElBQUM7QUFBQTtBQUFBLE1BQ0MsT0FBTTtBQUFBLE1BQ04sT0FBTTtBQUFBLE1BQ04sUUFBTztBQUFBLE1BQ1AsU0FBUTtBQUFBLE1BQ1IsTUFBSztBQUFBLE1BQ0wsUUFBTztBQUFBLE1BQ1AsYUFBWTtBQUFBLE1BQ1osZUFBYztBQUFBLE1BQ2QsZ0JBQWU7QUFBQSxNQUVmO0FBQUEsK0JBQUMsVUFBSyxHQUFFLGdCQUFSO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBb0I7QUFBQSxRQUNwQix1QkFBQyxVQUFLLEdBQUUsZ0JBQVI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFvQjtBQUFBO0FBQUE7QUFBQSxJQVp0QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFhQTtBQUFBLEVBRUZDLFdBQ0U7QUFBQSxJQUFDO0FBQUE7QUFBQSxNQUNDLE9BQU07QUFBQSxNQUNOLE9BQU07QUFBQSxNQUNOLFFBQU87QUFBQSxNQUNQLFNBQVE7QUFBQSxNQUNSLE1BQUs7QUFBQSxNQUNMLFFBQU87QUFBQSxNQUNQLGFBQVk7QUFBQSxNQUNaLGVBQWM7QUFBQSxNQUNkLGdCQUFlO0FBQUEsTUFFZjtBQUFBLCtCQUFDLFVBQUssR0FBRSw4QkFBUjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWtDO0FBQUEsUUFDbEMsdUJBQUMsVUFBSyxHQUFFLHFKQUFSO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBeUo7QUFBQSxRQUN6Six1QkFBQyxVQUFLLEdBQUUsbUJBQVI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF1QjtBQUFBLFFBQ3ZCLHVCQUFDLFVBQUssR0FBRSxxQ0FBUjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXlDO0FBQUEsUUFDekMsdUJBQUMsVUFBSyxHQUFFLFlBQVI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFnQjtBQUFBO0FBQUE7QUFBQSxJQWZsQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFnQkE7QUFBQSxFQUVGLGNBQ0U7QUFBQSxJQUFDO0FBQUE7QUFBQSxNQUNDLE9BQU07QUFBQSxNQUNOLE9BQU07QUFBQSxNQUNOLFFBQU87QUFBQSxNQUNQLFNBQVE7QUFBQSxNQUNSLE1BQUs7QUFBQSxNQUNMLFFBQU87QUFBQSxNQUNQLGFBQVk7QUFBQSxNQUNaLGVBQWM7QUFBQSxNQUNkLGdCQUFlO0FBQUEsTUFFZjtBQUFBLCtCQUFDLFVBQUssR0FBRSxvQkFBUjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXdCO0FBQUEsUUFDeEIsdUJBQUMsVUFBSyxHQUFFLGNBQVI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFrQjtBQUFBO0FBQUE7QUFBQSxJQVpwQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFhQTtBQUVKO0FBeUJBLFNBQVNDLGlCQUNQQyxPQUNBQyxRQUNpQjtBQUNqQixNQUFJRCxNQUFNRSxpQkFBaUIsYUFBYUYsTUFBTUEsVUFBVSxTQUFTO0FBQy9ELFlBQVFDLFFBQU07QUFBQSxNQUNaLEtBQUs7QUFDSCxlQUFPLEVBQUVDLGNBQWMsV0FBV0YsT0FBTyxVQUFVO0FBQUEsTUFDckQsS0FBSztBQUNILGVBQU8sRUFBRSxHQUFHQSxPQUFPQSxPQUFPLFFBQVE7QUFBQSxNQUNwQyxLQUFLO0FBQ0gsZUFBTyxFQUFFLEdBQUdBLE9BQU9BLE9BQU8sVUFBVTtBQUFBLElBQ3hDO0FBQUEsRUFDRjtBQUVBLE1BQUlBLE1BQU1FLGlCQUFpQixlQUFlRixNQUFNQSxVQUFVLFNBQVM7QUFDakUsWUFBUUMsUUFBTTtBQUFBLE1BQ1osS0FBSztBQUNILGVBQU8sRUFBRUMsY0FBYyxhQUFhRixPQUFPLFVBQVU7QUFBQSxNQUN2RCxLQUFLO0FBQ0gsZUFBTyxFQUFFLEdBQUdBLE9BQU9BLE9BQU8sUUFBUTtBQUFBLE1BQ3BDLEtBQUs7QUFDSCxlQUFPLEVBQUUsR0FBR0EsT0FBT0EsT0FBTyxVQUFVO0FBQUEsSUFDeEM7QUFBQSxFQUNGO0FBRUEsTUFBSUEsTUFBTUUsaUJBQWlCLGNBQWNGLE1BQU1BLFVBQVUsU0FBUztBQUNoRSxZQUFRQyxRQUFNO0FBQUEsTUFDWixLQUFLO0FBQ0gsZUFBTyxFQUFFQyxjQUFjLFlBQVlGLE9BQU8sVUFBVTtBQUFBLE1BQ3RELEtBQUs7QUFDSCxlQUFPLEVBQUUsR0FBR0EsT0FBT0EsT0FBTyxRQUFRO0FBQUEsTUFDcEMsS0FBSztBQUNILGVBQU8sRUFBRSxHQUFHQSxPQUFPQSxPQUFPLFVBQVU7QUFBQSxJQUN4QztBQUFBLEVBQ0Y7QUFFQSxVQUFRQyxRQUFNO0FBQUEsSUFDWixLQUFLO0FBQ0gsYUFBTyxFQUFFLEdBQUdELE9BQU9BLE9BQU8sUUFBUTtBQUFBLElBQ3BDLEtBQUs7QUFDSCxhQUFPLEVBQUUsR0FBR0EsT0FBT0EsT0FBTyxVQUFVO0FBQUEsSUFDdEMsS0FBSztBQUNILGFBQU8sRUFBRSxHQUFHQSxPQUFPQSxPQUFPLFFBQVE7QUFBQSxJQUNwQyxLQUFLO0FBQ0gsYUFBTyxFQUFFLEdBQUdBLE9BQU9BLE9BQU8sVUFBVTtBQUFBLElBQ3RDLEtBQUs7QUFDSCxhQUFPLEVBQUUsR0FBR0EsT0FBT0EsT0FBTyxXQUFXO0FBQUEsSUFDdkMsS0FBSztBQUNILGFBQU8sRUFBRSxHQUFHQSxPQUFPQSxPQUFPLFVBQVU7QUFBQSxJQUN0QztBQUNFLGFBQU9BO0FBQUFBLEVBQ1g7QUFDRjtBQUVPLGFBQU1HLE9BQTRCQSxDQUFDO0FBQUEsRUFDeENDO0FBQUFBLEVBQ0FDLE9BQU87QUFBQSxFQUNQQyxRQUFRO0FBQUEsRUFDUkosZUFBZTtBQUFBLEVBQ2ZGLE9BQU9PO0FBQUFBLEVBQ1BDLGNBQWM7QUFBQSxFQUNkQyxXQUFXO0FBQUEsRUFDWEMsWUFBWTtBQUFBLEVBQ1pDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0EsR0FBR0M7QUFDTCxNQUFNO0FBQUFDLEtBQUE7QUFDSixRQUFNLENBQUNDLGVBQWVDLFFBQVEsSUFBSTNCLFdBQVdPLGtCQUFrQjtBQUFBLElBQzdERztBQUFBQSxJQUNBRixPQUFPUyxXQUFXLGFBQWFGLG1CQUFtQjtBQUFBLEVBQ3BELENBQUM7QUFFRCxRQUFNYSxlQUFlYixtQkFBbUJXLGNBQWNsQjtBQUV0RCxRQUFNcUIsY0FBYztBQUFBLElBQ2xCQyxJQUFJO0FBQUEsSUFDSkMsSUFBSTtBQUFBLElBQ0pDLElBQUk7QUFBQSxJQUNKQyxJQUFJO0FBQUEsSUFDSkMsSUFBSTtBQUFBLEVBQ047QUFHQSxRQUFNQyxlQUFlO0FBQUEsSUFDbkJDLFNBQVM7QUFBQSxJQUNUQyxXQUFXO0FBQUEsSUFDWEMsT0FBTztBQUFBLElBQ1BDLGFBQWE7QUFBQSxJQUNiQyxZQUFZO0FBQUEsRUFDZDtBQUdBLFFBQU1DLHNCQUFzQkEsTUFBTTtBQUNoQyxRQUFJLENBQUN6QjtBQUFhLGFBQU9tQixhQUFhckIsS0FBSztBQUUzQyxVQUFNNEIsVUFBVWhCLGNBQWNoQjtBQUM5QixVQUFNRixRQUFRb0I7QUFFZCxRQUFJYyxZQUFZLFdBQVc7QUFDekIsY0FBUWxDLE9BQUs7QUFBQSxRQUNYLEtBQUs7QUFBQSxRQUNMLEtBQUs7QUFDSCxpQkFBTztBQUFBLFFBQ1QsS0FBSztBQUNILGlCQUFPO0FBQUEsUUFDVDtBQUNFLGlCQUFPO0FBQUEsTUFDWDtBQUFBLElBQ0Y7QUFFQSxRQUFJa0MsWUFBWSxhQUFhO0FBQzNCLGNBQVFsQyxPQUFLO0FBQUEsUUFDWCxLQUFLO0FBQUEsUUFDTCxLQUFLO0FBQ0gsaUJBQU87QUFBQSxRQUNULEtBQUs7QUFDSCxpQkFBTztBQUFBLFFBQ1Q7QUFDRSxpQkFBTztBQUFBLE1BQ1g7QUFBQSxJQUNGO0FBRUEsUUFBSWtDLFlBQVksWUFBWTtBQUMxQixjQUFRbEMsT0FBSztBQUFBLFFBQ1gsS0FBSztBQUFBLFFBQ0wsS0FBSztBQUNILGlCQUFPO0FBQUEsUUFDVCxLQUFLO0FBQ0gsaUJBQU87QUFBQSxRQUNUO0FBQ0UsaUJBQU87QUFBQSxNQUNYO0FBQUEsSUFDRjtBQUVBLFdBQU8yQixhQUFhckIsS0FBSztBQUFBLEVBQzNCO0FBRUEsUUFBTTZCLG1CQUFtQjFDO0FBQUFBLElBQ3ZCLENBQUMyQyxVQUEwRDtBQUN6RCxVQUFJNUIsZUFBZSxDQUFDQyxVQUFVO0FBQzVCVSxpQkFBUyxhQUFhO0FBQ3RCUix3QkFBZ0IsT0FBTztBQUFBLE1BQ3pCO0FBQ0FDLHFCQUFld0IsS0FBcUM7QUFBQSxJQUN0RDtBQUFBLElBQ0EsQ0FBQzVCLGFBQWFDLFVBQVVFLGVBQWVDLFlBQVk7QUFBQSxFQUNyRDtBQUVBLFFBQU15QixtQkFBbUI1QztBQUFBQSxJQUN2QixDQUFDMkMsVUFBMEQ7QUFDekQsVUFBSTVCLGVBQWUsQ0FBQ0MsVUFBVTtBQUM1QlUsaUJBQVMsYUFBYTtBQUN0QlIsd0JBQWdCLFNBQVM7QUFBQSxNQUMzQjtBQUNBRSxxQkFBZXVCLEtBQXFDO0FBQUEsSUFDdEQ7QUFBQSxJQUNBLENBQUM1QixhQUFhQyxVQUFVRSxlQUFlRSxZQUFZO0FBQUEsRUFDckQ7QUFFQSxRQUFNeUIsY0FBYzdDO0FBQUFBLElBQ2xCLENBQUMyQyxVQUEwRDtBQUN6RCxVQUFJNUIsZUFBZSxDQUFDQyxVQUFVO0FBQzVCVSxpQkFBUyxPQUFPO0FBQ2hCUix3QkFBZ0IsT0FBTztBQUFBLE1BQ3pCO0FBQ0FHLGdCQUFVc0IsS0FBcUM7QUFBQSxJQUNqRDtBQUFBLElBQ0EsQ0FBQzVCLGFBQWFDLFVBQVVFLGVBQWVHLE9BQU87QUFBQSxFQUNoRDtBQUVBLFFBQU15QixhQUFhOUM7QUFBQUEsSUFDakIsQ0FBQzJDLFVBQTBEO0FBQ3pELFVBQUk1QixlQUFlLENBQUNDLFVBQVU7QUFDNUJVLGlCQUFTLE1BQU07QUFDZlIsd0JBQWdCLFNBQVM7QUFBQSxNQUMzQjtBQUNBSSxlQUFTcUIsS0FBcUM7QUFBQSxJQUNoRDtBQUFBLElBQ0EsQ0FBQzVCLGFBQWFDLFVBQVVFLGVBQWVJLE1BQU07QUFBQSxFQUMvQztBQUVBLFFBQU15QixjQUFjOUMsTUFBTVUsSUFBSTtBQUM5QixNQUFJLENBQUNvQyxhQUFhO0FBQ2hCQyxZQUFRQyxLQUFLLFNBQVN0QyxpQkFBaUI7QUFDdkMsV0FBTztBQUFBLEVBQ1Q7QUFFQSxRQUFNdUMsZUFBZVYsb0JBQW9CO0FBQ3pDLFFBQU1XLGVBQWVwQyxjQUNqQixrQkFBa0JDLFdBQVcsa0NBQWtDLE9BQy9EO0FBQ0osUUFBTW9DLGVBQ0pyQyxlQUFlLENBQUNDLFdBQ1osbUZBQ0E7QUFFTixRQUFNcUMsa0JBQWtCdkQsTUFBTXdELGFBQWFQLGFBQWE7QUFBQSxJQUN0RDlCLFdBQVcsR0FBR1csWUFBWWhCLElBQUksS0FBS3NDO0FBQUFBLEVBQ3JDLENBQUM7QUFFRCxNQUFJbkMsYUFBYTtBQUVmLFVBQU07QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BMEJKLEdBQUd3QztBQUFBQSxJQUNMLElBQUloQztBQUVKLFdBQ0U7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLFdBQVcsZ0JBQWdCNEIsZ0JBQWdCQyxnQkFBZ0JuQztBQUFBQSxRQUMzRCxjQUFjeUI7QUFBQUEsUUFDZCxjQUFjRTtBQUFBQSxRQUNkLFNBQVNDO0FBQUFBLFFBQ1QsUUFBUUM7QUFBQUEsUUFDUixVQUFVOUIsV0FBV3dDLFNBQVk7QUFBQSxRQUNqQyxNQUFLO0FBQUEsUUFDTCxpQkFBZXhDO0FBQUFBLFFBQ2YsR0FBS3VDO0FBQUFBLFFBRUpGO0FBQUFBO0FBQUFBLE1BWEg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBWUE7QUFBQSxFQUVKO0FBRUEsU0FBT3ZELE1BQU13RCxhQUFhUCxhQUFhO0FBQUEsSUFDckM5QixXQUFXLEdBQUdXLFlBQVloQixJQUFJLEtBQUtzQyxnQkFBZ0JqQztBQUFBQSxJQUNuRCxHQUFHTTtBQUFBQSxFQUNMLENBQUM7QUFDSDtBQUFFQyxHQXpNV2QsTUFBeUI7QUFBQStDLEtBQXpCL0M7QUFBeUIsSUFBQStDO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJSZWFjdCIsInVzZVJlZHVjZXIiLCJ1c2VDYWxsYmFjayIsImljb25zIiwibGVhZiIsImFjY2Vzc2liaWxpdHkiLCJ4IiwiaGFuZHNoYWtlIiwiaWNvblN0YXRlUmVkdWNlciIsInN0YXRlIiwiYWN0aW9uIiwiY29sb3JWYXJpYW50IiwiSWNvbiIsIm5hbWUiLCJzaXplIiwiY29sb3IiLCJjb250cm9sbGVkU3RhdGUiLCJpbnRlcmFjdGl2ZSIsImRpc2FibGVkIiwiY2xhc3NOYW1lIiwib25TdGF0ZUNoYW5nZSIsIm9uTW91c2VFbnRlciIsIm9uTW91c2VMZWF2ZSIsIm9uRm9jdXMiLCJvbkJsdXIiLCJwcm9wcyIsIl9zIiwiaW50ZXJuYWxTdGF0ZSIsImRpc3BhdGNoIiwiY3VycmVudFN0YXRlIiwic2l6ZUNsYXNzZXMiLCJ4cyIsInNtIiwibWQiLCJsZyIsInhsIiwiY29sb3JDbGFzc2VzIiwicHJpbWFyeSIsInNlY29uZGFyeSIsIm11dGVkIiwiZGVzdHJ1Y3RpdmUiLCJmb3JlZ3JvdW5kIiwiZ2V0SW50ZXJhY3RpdmVDb2xvciIsInZhcmlhbnQiLCJoYW5kbGVNb3VzZUVudGVyIiwiZXZlbnQiLCJoYW5kbGVNb3VzZUxlYXZlIiwiaGFuZGxlRm9jdXMiLCJoYW5kbGVCbHVyIiwiaWNvbkVsZW1lbnQiLCJjb25zb2xlIiwid2FybiIsImFwcGxpZWRDb2xvciIsInN0YXRlQ2xhc3NlcyIsImZvY3VzQ2xhc3NlcyIsImljb25XaXRoQ2xhc3NlcyIsImNsb25lRWxlbWVudCIsInNwYW5Qcm9wcyIsInVuZGVmaW5lZCIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiSWNvbi50c3giXSwiZmlsZSI6Ii9ob21lL3N1bmRlL3Byb2plY3RzL0xpZHIvZnJvbnRlbmQtdXNlLWNhc2UtZGVzaWduLXN5c3RlbS9zcmMvY29tcG9uZW50cy9hdG9tcy9JY29uL0ljb24udHN4Iiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0LCB7IHVzZVJlZHVjZXIsIHVzZUNhbGxiYWNrIH0gZnJvbSAncmVhY3QnO1xuXG4vLyBJY29uIGRlZmluaXRpb25zXG5jb25zdCBpY29ucyA9IHtcbiAgbGVhZjogKFxuICAgIDxzdmdcbiAgICAgIHhtbG5zPVwiaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmdcIlxuICAgICAgd2lkdGg9XCIyNFwiXG4gICAgICBoZWlnaHQ9XCIyNFwiXG4gICAgICB2aWV3Qm94PVwiMCAwIDI0IDI0XCJcbiAgICAgIGZpbGw9XCJub25lXCJcbiAgICAgIHN0cm9rZT1cImN1cnJlbnRDb2xvclwiXG4gICAgICBzdHJva2VXaWR0aD1cIjJcIlxuICAgICAgc3Ryb2tlTGluZWNhcD1cInJvdW5kXCJcbiAgICAgIHN0cm9rZUxpbmVqb2luPVwicm91bmRcIlxuICAgID5cbiAgICAgIDxwYXRoIGQ9XCJNMTEgMjBBNyA3IDAgMCAxIDkuOCA2LjFDMTUuNSA1IDE3IDQuNDggMTkgMmMxIDIgMiA0LjE4IDIgOCAwIDUuNS00Ljc4IDEwLTEwIDEwWlwiIC8+XG4gICAgICA8cGF0aCBkPVwiTTIgMjFjMC0zIDEuODUtNS4zNiA1LjA4LTZDOS41IDE0LjUyIDEyIDEzIDEzIDEyXCIgLz5cbiAgICA8L3N2Zz5cbiAgKSxcbiAgYWNjZXNzaWJpbGl0eTogKFxuICAgIDxzdmdcbiAgICAgIHhtbG5zPVwiaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmdcIlxuICAgICAgd2lkdGg9XCIyNFwiXG4gICAgICBoZWlnaHQ9XCIyNFwiXG4gICAgICB2aWV3Qm94PVwiMCAwIDI0IDI0XCJcbiAgICAgIGZpbGw9XCJub25lXCJcbiAgICAgIHN0cm9rZT1cImN1cnJlbnRDb2xvclwiXG4gICAgICBzdHJva2VXaWR0aD1cIjJcIlxuICAgICAgc3Ryb2tlTGluZWNhcD1cInJvdW5kXCJcbiAgICAgIHN0cm9rZUxpbmVqb2luPVwicm91bmRcIlxuICAgID5cbiAgICAgIDxjaXJjbGUgY3g9XCIxNlwiIGN5PVwiNFwiIHI9XCIxXCIgLz5cbiAgICAgIDxwYXRoIGQ9XCJtMTggMTkgMS03LTYgMVwiIC8+XG4gICAgICA8cGF0aCBkPVwibTUgOCAzLTMgNS41IDMtMi4zNiAzLjVcIiAvPlxuICAgICAgPHBhdGggZD1cIk00LjI0IDE0LjVhNSA1IDAgMCAwIDYuODggNlwiIC8+XG4gICAgICA8cGF0aCBkPVwiTTEzLjc2IDE3LjVhNSA1IDAgMCAwLTYuODgtNlwiIC8+XG4gICAgPC9zdmc+XG4gICksXG4gIHg6IChcbiAgICA8c3ZnXG4gICAgICB4bWxucz1cImh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnXCJcbiAgICAgIHdpZHRoPVwiMjRcIlxuICAgICAgaGVpZ2h0PVwiMjRcIlxuICAgICAgdmlld0JveD1cIjAgMCAyNCAyNFwiXG4gICAgICBmaWxsPVwibm9uZVwiXG4gICAgICBzdHJva2U9XCJjdXJyZW50Q29sb3JcIlxuICAgICAgc3Ryb2tlV2lkdGg9XCIyXCJcbiAgICAgIHN0cm9rZUxpbmVjYXA9XCJyb3VuZFwiXG4gICAgICBzdHJva2VMaW5lam9pbj1cInJvdW5kXCJcbiAgICA+XG4gICAgICA8cGF0aCBkPVwiTTE4IDYgNiAxOFwiIC8+XG4gICAgICA8cGF0aCBkPVwibTYgNiAxMiAxMlwiIC8+XG4gICAgPC9zdmc+XG4gICksXG4gIGhhbmRzaGFrZTogKFxuICAgIDxzdmdcbiAgICAgIHhtbG5zPVwiaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmdcIlxuICAgICAgd2lkdGg9XCIyNFwiXG4gICAgICBoZWlnaHQ9XCIyNFwiXG4gICAgICB2aWV3Qm94PVwiMCAwIDI0IDI0XCJcbiAgICAgIGZpbGw9XCJub25lXCJcbiAgICAgIHN0cm9rZT1cImN1cnJlbnRDb2xvclwiXG4gICAgICBzdHJva2VXaWR0aD1cIjJcIlxuICAgICAgc3Ryb2tlTGluZWNhcD1cInJvdW5kXCJcbiAgICAgIHN0cm9rZUxpbmVqb2luPVwicm91bmRcIlxuICAgID5cbiAgICAgIDxwYXRoIGQ9XCJtMTEgMTcgMiAyYTEgMSAwIDEgMCAzLTNcIiAvPlxuICAgICAgPHBhdGggZD1cIm0xNCAxNCAyLjUgMi41YTEgMSAwIDEgMCAzLTNsLTMuODgtMy44OGEzIDMgMCAwIDAtNC4yNCAwbC0uODguODhhMSAxIDAgMSAxLTMtM2wyLjgxLTIuODFhNS43OSA1Ljc5IDAgMCAxIDcuMDYtLjg3bC40Ny4yOGEyIDIgMCAwIDAgMS40Mi4yNUwyMSA0XCIgLz5cbiAgICAgIDxwYXRoIGQ9XCJtMjEgMyAxIDExaC0yXCIgLz5cbiAgICAgIDxwYXRoIGQ9XCJNMyAzIDIgMTRsNi41IDYuNWExIDEgMCAxIDAgMy0zXCIgLz5cbiAgICAgIDxwYXRoIGQ9XCJNMyA0aDhcIiAvPlxuICAgIDwvc3ZnPlxuICApLFxuICAnYXJyb3ctbGVmdCc6IChcbiAgICA8c3ZnXG4gICAgICB4bWxucz1cImh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnXCJcbiAgICAgIHdpZHRoPVwiMjRcIlxuICAgICAgaGVpZ2h0PVwiMjRcIlxuICAgICAgdmlld0JveD1cIjAgMCAyNCAyNFwiXG4gICAgICBmaWxsPVwibm9uZVwiXG4gICAgICBzdHJva2U9XCJjdXJyZW50Q29sb3JcIlxuICAgICAgc3Ryb2tlV2lkdGg9XCIyXCJcbiAgICAgIHN0cm9rZUxpbmVjYXA9XCJyb3VuZFwiXG4gICAgICBzdHJva2VMaW5lam9pbj1cInJvdW5kXCJcbiAgICA+XG4gICAgICA8cGF0aCBkPVwibTEyIDE5LTctNyA3LTdcIiAvPlxuICAgICAgPHBhdGggZD1cIk0xOSAxMkg1XCIgLz5cbiAgICA8L3N2Zz5cbiAgKSxcbn0gYXMgY29uc3Q7XG5cbmV4cG9ydCB0eXBlIEljb25OYW1lID0ga2V5b2YgdHlwZW9mIGljb25zO1xuZXhwb3J0IHR5cGUgSWNvblN0YXRlID0gJ2RlZmF1bHQnIHwgJ2hvdmVyJyB8ICdmb2N1cycgfCAnZGlzYWJsZWQnO1xuZXhwb3J0IHR5cGUgSWNvbkNvbG9yVmFyaWFudCA9ICdwcmltYXJ5JyB8ICdzZWNvbmRhcnknIHwgJ3RlcnRpYXJ5JztcblxuaW50ZXJmYWNlIEljb25TdGF0ZUNvbmZpZyB7XG4gIHN0YXRlOiBJY29uU3RhdGU7XG4gIGNvbG9yVmFyaWFudDogSWNvbkNvbG9yVmFyaWFudDtcbn1cblxuZXhwb3J0IGludGVyZmFjZSBJY29uUHJvcHNcbiAgZXh0ZW5kcyBPbWl0PFJlYWN0LlNWR0F0dHJpYnV0ZXM8U1ZHRWxlbWVudD4sICdjb2xvcic+IHtcbiAgbmFtZTogSWNvbk5hbWU7XG4gIHNpemU/OiAneHMnIHwgJ3NtJyB8ICdtZCcgfCAnbGcnIHwgJ3hsJztcbiAgY29sb3I/OiAncHJpbWFyeScgfCAnc2Vjb25kYXJ5JyB8ICdtdXRlZCcgfCAnZGVzdHJ1Y3RpdmUnIHwgJ2ZvcmVncm91bmQnO1xuICBjb2xvclZhcmlhbnQ/OiBJY29uQ29sb3JWYXJpYW50O1xuICBzdGF0ZT86IEljb25TdGF0ZTtcbiAgaW50ZXJhY3RpdmU/OiBib29sZWFuO1xuICBkaXNhYmxlZD86IGJvb2xlYW47XG4gIGNsYXNzTmFtZT86IHN0cmluZztcbiAgb25TdGF0ZUNoYW5nZT86IChzdGF0ZTogSWNvblN0YXRlKSA9PiB2b2lkO1xufVxuXG4vLyBTdGF0ZSByZWR1Y2VyIGZvciBpbnRlcmFjdGl2ZSBpY29uc1xuZnVuY3Rpb24gaWNvblN0YXRlUmVkdWNlcihcbiAgc3RhdGU6IEljb25TdGF0ZUNvbmZpZyxcbiAgYWN0aW9uOiBzdHJpbmdcbik6IEljb25TdGF0ZUNvbmZpZyB7XG4gIGlmIChzdGF0ZS5jb2xvclZhcmlhbnQgPT09ICdwcmltYXJ5JyAmJiBzdGF0ZS5zdGF0ZSA9PT0gJ2hvdmVyJykge1xuICAgIHN3aXRjaCAoYWN0aW9uKSB7XG4gICAgICBjYXNlICdtb3VzZV9sZWF2ZSc6XG4gICAgICAgIHJldHVybiB7IGNvbG9yVmFyaWFudDogJ3ByaW1hcnknLCBzdGF0ZTogJ2RlZmF1bHQnIH07XG4gICAgICBjYXNlICdmb2N1cyc6XG4gICAgICAgIHJldHVybiB7IC4uLnN0YXRlLCBzdGF0ZTogJ2ZvY3VzJyB9O1xuICAgICAgY2FzZSAnYmx1cic6XG4gICAgICAgIHJldHVybiB7IC4uLnN0YXRlLCBzdGF0ZTogJ2RlZmF1bHQnIH07XG4gICAgfVxuICB9XG5cbiAgaWYgKHN0YXRlLmNvbG9yVmFyaWFudCA9PT0gJ3NlY29uZGFyeScgJiYgc3RhdGUuc3RhdGUgPT09ICdob3ZlcicpIHtcbiAgICBzd2l0Y2ggKGFjdGlvbikge1xuICAgICAgY2FzZSAnbW91c2VfbGVhdmUnOlxuICAgICAgICByZXR1cm4geyBjb2xvclZhcmlhbnQ6ICdzZWNvbmRhcnknLCBzdGF0ZTogJ2RlZmF1bHQnIH07XG4gICAgICBjYXNlICdmb2N1cyc6XG4gICAgICAgIHJldHVybiB7IC4uLnN0YXRlLCBzdGF0ZTogJ2ZvY3VzJyB9O1xuICAgICAgY2FzZSAnYmx1cic6XG4gICAgICAgIHJldHVybiB7IC4uLnN0YXRlLCBzdGF0ZTogJ2RlZmF1bHQnIH07XG4gICAgfVxuICB9XG5cbiAgaWYgKHN0YXRlLmNvbG9yVmFyaWFudCA9PT0gJ3RlcnRpYXJ5JyAmJiBzdGF0ZS5zdGF0ZSA9PT0gJ2hvdmVyJykge1xuICAgIHN3aXRjaCAoYWN0aW9uKSB7XG4gICAgICBjYXNlICdtb3VzZV9sZWF2ZSc6XG4gICAgICAgIHJldHVybiB7IGNvbG9yVmFyaWFudDogJ3RlcnRpYXJ5Jywgc3RhdGU6ICdkZWZhdWx0JyB9O1xuICAgICAgY2FzZSAnZm9jdXMnOlxuICAgICAgICByZXR1cm4geyAuLi5zdGF0ZSwgc3RhdGU6ICdmb2N1cycgfTtcbiAgICAgIGNhc2UgJ2JsdXInOlxuICAgICAgICByZXR1cm4geyAuLi5zdGF0ZSwgc3RhdGU6ICdkZWZhdWx0JyB9O1xuICAgIH1cbiAgfVxuXG4gIHN3aXRjaCAoYWN0aW9uKSB7XG4gICAgY2FzZSAnbW91c2VfZW50ZXInOlxuICAgICAgcmV0dXJuIHsgLi4uc3RhdGUsIHN0YXRlOiAnaG92ZXInIH07XG4gICAgY2FzZSAnbW91c2VfbGVhdmUnOlxuICAgICAgcmV0dXJuIHsgLi4uc3RhdGUsIHN0YXRlOiAnZGVmYXVsdCcgfTtcbiAgICBjYXNlICdmb2N1cyc6XG4gICAgICByZXR1cm4geyAuLi5zdGF0ZSwgc3RhdGU6ICdmb2N1cycgfTtcbiAgICBjYXNlICdibHVyJzpcbiAgICAgIHJldHVybiB7IC4uLnN0YXRlLCBzdGF0ZTogJ2RlZmF1bHQnIH07XG4gICAgY2FzZSAnZGlzYWJsZSc6XG4gICAgICByZXR1cm4geyAuLi5zdGF0ZSwgc3RhdGU6ICdkaXNhYmxlZCcgfTtcbiAgICBjYXNlICdlbmFibGUnOlxuICAgICAgcmV0dXJuIHsgLi4uc3RhdGUsIHN0YXRlOiAnZGVmYXVsdCcgfTtcbiAgICBkZWZhdWx0OlxuICAgICAgcmV0dXJuIHN0YXRlO1xuICB9XG59XG5cbmV4cG9ydCBjb25zdCBJY29uOiBSZWFjdC5GQzxJY29uUHJvcHM+ID0gKHtcbiAgbmFtZSxcbiAgc2l6ZSA9ICdtZCcsXG4gIGNvbG9yID0gJ2ZvcmVncm91bmQnLFxuICBjb2xvclZhcmlhbnQgPSAncHJpbWFyeScsXG4gIHN0YXRlOiBjb250cm9sbGVkU3RhdGUsXG4gIGludGVyYWN0aXZlID0gZmFsc2UsXG4gIGRpc2FibGVkID0gZmFsc2UsXG4gIGNsYXNzTmFtZSA9ICcnLFxuICBvblN0YXRlQ2hhbmdlLFxuICBvbk1vdXNlRW50ZXIsXG4gIG9uTW91c2VMZWF2ZSxcbiAgb25Gb2N1cyxcbiAgb25CbHVyLFxuICAuLi5wcm9wc1xufSkgPT4ge1xuICBjb25zdCBbaW50ZXJuYWxTdGF0ZSwgZGlzcGF0Y2hdID0gdXNlUmVkdWNlcihpY29uU3RhdGVSZWR1Y2VyLCB7XG4gICAgY29sb3JWYXJpYW50LFxuICAgIHN0YXRlOiBkaXNhYmxlZCA/ICdkaXNhYmxlZCcgOiBjb250cm9sbGVkU3RhdGUgfHwgJ2RlZmF1bHQnLFxuICB9KTtcblxuICBjb25zdCBjdXJyZW50U3RhdGUgPSBjb250cm9sbGVkU3RhdGUgfHwgaW50ZXJuYWxTdGF0ZS5zdGF0ZTtcblxuICBjb25zdCBzaXplQ2xhc3NlcyA9IHtcbiAgICB4czogJ3ctMyBoLTMnLFxuICAgIHNtOiAndy00IGgtNCcsXG4gICAgbWQ6ICd3LTYgaC02JyxcbiAgICBsZzogJ3ctOCBoLTgnLFxuICAgIHhsOiAndy0xMCBoLTEwJyxcbiAgfTtcblxuICAvLyBCYWNrd2FyZCBjb21wYXRpYmlsaXR5OiBpZiBjb2xvciBwcm9wIGlzIHVzZWQsIHVzZSBzZW1hbnRpYyBjb2xvcnNcbiAgY29uc3QgY29sb3JDbGFzc2VzID0ge1xuICAgIHByaW1hcnk6ICd0ZXh0LXByaW1hcnknLFxuICAgIHNlY29uZGFyeTogJ3RleHQtc2Vjb25kYXJ5JyxcbiAgICBtdXRlZDogJ3RleHQtbXV0ZWQtZm9yZWdyb3VuZCcsXG4gICAgZGVzdHJ1Y3RpdmU6ICd0ZXh0LWRlc3RydWN0aXZlJyxcbiAgICBmb3JlZ3JvdW5kOiAndGV4dC1mb3JlZ3JvdW5kJyxcbiAgfTtcblxuICAvLyBOZXcgaW50ZXJhY3RpdmUgY29sb3IgdmFyaWFudHMgd2l0aCBzdGF0ZXNcbiAgY29uc3QgZ2V0SW50ZXJhY3RpdmVDb2xvciA9ICgpID0+IHtcbiAgICBpZiAoIWludGVyYWN0aXZlKSByZXR1cm4gY29sb3JDbGFzc2VzW2NvbG9yXTtcblxuICAgIGNvbnN0IHZhcmlhbnQgPSBpbnRlcm5hbFN0YXRlLmNvbG9yVmFyaWFudDtcbiAgICBjb25zdCBzdGF0ZSA9IGN1cnJlbnRTdGF0ZTtcblxuICAgIGlmICh2YXJpYW50ID09PSAncHJpbWFyeScpIHtcbiAgICAgIHN3aXRjaCAoc3RhdGUpIHtcbiAgICAgICAgY2FzZSAnaG92ZXInOlxuICAgICAgICBjYXNlICdmb2N1cyc6XG4gICAgICAgICAgcmV0dXJuICd0ZXh0LXByaW1hcnktNjAwIHRyYW5zaXRpb24tY29sb3JzIGR1cmF0aW9uLTIwMCc7XG4gICAgICAgIGNhc2UgJ2Rpc2FibGVkJzpcbiAgICAgICAgICByZXR1cm4gJ3RleHQtZ3JheS00MDAnO1xuICAgICAgICBkZWZhdWx0OlxuICAgICAgICAgIHJldHVybiAndGV4dC1wcmltYXJ5IHRyYW5zaXRpb24tY29sb3JzIGR1cmF0aW9uLTIwMCc7XG4gICAgICB9XG4gICAgfVxuXG4gICAgaWYgKHZhcmlhbnQgPT09ICdzZWNvbmRhcnknKSB7XG4gICAgICBzd2l0Y2ggKHN0YXRlKSB7XG4gICAgICAgIGNhc2UgJ2hvdmVyJzpcbiAgICAgICAgY2FzZSAnZm9jdXMnOlxuICAgICAgICAgIHJldHVybiAndGV4dC13aGl0ZSB0cmFuc2l0aW9uLWNvbG9ycyBkdXJhdGlvbi0yMDAnO1xuICAgICAgICBjYXNlICdkaXNhYmxlZCc6XG4gICAgICAgICAgcmV0dXJuICd0ZXh0LWdyYXktNDAwJztcbiAgICAgICAgZGVmYXVsdDpcbiAgICAgICAgICByZXR1cm4gJ3RleHQtd2hpdGUgdHJhbnNpdGlvbi1jb2xvcnMgZHVyYXRpb24tMjAwJztcbiAgICAgIH1cbiAgICB9XG5cbiAgICBpZiAodmFyaWFudCA9PT0gJ3RlcnRpYXJ5Jykge1xuICAgICAgc3dpdGNoIChzdGF0ZSkge1xuICAgICAgICBjYXNlICdob3Zlcic6XG4gICAgICAgIGNhc2UgJ2ZvY3VzJzpcbiAgICAgICAgICByZXR1cm4gJ3RleHQtZ3JheS03MDAgdHJhbnNpdGlvbi1jb2xvcnMgZHVyYXRpb24tMjAwJztcbiAgICAgICAgY2FzZSAnZGlzYWJsZWQnOlxuICAgICAgICAgIHJldHVybiAndGV4dC1ncmF5LTQwMCc7XG4gICAgICAgIGRlZmF1bHQ6XG4gICAgICAgICAgcmV0dXJuICd0ZXh0LWdyYXktNjAwIHRyYW5zaXRpb24tY29sb3JzIGR1cmF0aW9uLTIwMCc7XG4gICAgICB9XG4gICAgfVxuXG4gICAgcmV0dXJuIGNvbG9yQ2xhc3Nlc1tjb2xvcl07XG4gIH07XG5cbiAgY29uc3QgaGFuZGxlTW91c2VFbnRlciA9IHVzZUNhbGxiYWNrKFxuICAgIChldmVudDogUmVhY3QuTW91c2VFdmVudDxIVE1MU3BhbkVsZW1lbnQgfCBTVkdFbGVtZW50PikgPT4ge1xuICAgICAgaWYgKGludGVyYWN0aXZlICYmICFkaXNhYmxlZCkge1xuICAgICAgICBkaXNwYXRjaCgnbW91c2VfZW50ZXInKTtcbiAgICAgICAgb25TdGF0ZUNoYW5nZT8uKCdob3ZlcicpO1xuICAgICAgfVxuICAgICAgb25Nb3VzZUVudGVyPy4oZXZlbnQgYXMgUmVhY3QuTW91c2VFdmVudDxTVkdFbGVtZW50Pik7XG4gICAgfSxcbiAgICBbaW50ZXJhY3RpdmUsIGRpc2FibGVkLCBvblN0YXRlQ2hhbmdlLCBvbk1vdXNlRW50ZXJdXG4gICk7XG5cbiAgY29uc3QgaGFuZGxlTW91c2VMZWF2ZSA9IHVzZUNhbGxiYWNrKFxuICAgIChldmVudDogUmVhY3QuTW91c2VFdmVudDxIVE1MU3BhbkVsZW1lbnQgfCBTVkdFbGVtZW50PikgPT4ge1xuICAgICAgaWYgKGludGVyYWN0aXZlICYmICFkaXNhYmxlZCkge1xuICAgICAgICBkaXNwYXRjaCgnbW91c2VfbGVhdmUnKTtcbiAgICAgICAgb25TdGF0ZUNoYW5nZT8uKCdkZWZhdWx0Jyk7XG4gICAgICB9XG4gICAgICBvbk1vdXNlTGVhdmU/LihldmVudCBhcyBSZWFjdC5Nb3VzZUV2ZW50PFNWR0VsZW1lbnQ+KTtcbiAgICB9LFxuICAgIFtpbnRlcmFjdGl2ZSwgZGlzYWJsZWQsIG9uU3RhdGVDaGFuZ2UsIG9uTW91c2VMZWF2ZV1cbiAgKTtcblxuICBjb25zdCBoYW5kbGVGb2N1cyA9IHVzZUNhbGxiYWNrKFxuICAgIChldmVudDogUmVhY3QuRm9jdXNFdmVudDxIVE1MU3BhbkVsZW1lbnQgfCBTVkdFbGVtZW50PikgPT4ge1xuICAgICAgaWYgKGludGVyYWN0aXZlICYmICFkaXNhYmxlZCkge1xuICAgICAgICBkaXNwYXRjaCgnZm9jdXMnKTtcbiAgICAgICAgb25TdGF0ZUNoYW5nZT8uKCdmb2N1cycpO1xuICAgICAgfVxuICAgICAgb25Gb2N1cz8uKGV2ZW50IGFzIFJlYWN0LkZvY3VzRXZlbnQ8U1ZHRWxlbWVudD4pO1xuICAgIH0sXG4gICAgW2ludGVyYWN0aXZlLCBkaXNhYmxlZCwgb25TdGF0ZUNoYW5nZSwgb25Gb2N1c11cbiAgKTtcblxuICBjb25zdCBoYW5kbGVCbHVyID0gdXNlQ2FsbGJhY2soXG4gICAgKGV2ZW50OiBSZWFjdC5Gb2N1c0V2ZW50PEhUTUxTcGFuRWxlbWVudCB8IFNWR0VsZW1lbnQ+KSA9PiB7XG4gICAgICBpZiAoaW50ZXJhY3RpdmUgJiYgIWRpc2FibGVkKSB7XG4gICAgICAgIGRpc3BhdGNoKCdibHVyJyk7XG4gICAgICAgIG9uU3RhdGVDaGFuZ2U/LignZGVmYXVsdCcpO1xuICAgICAgfVxuICAgICAgb25CbHVyPy4oZXZlbnQgYXMgUmVhY3QuRm9jdXNFdmVudDxTVkdFbGVtZW50Pik7XG4gICAgfSxcbiAgICBbaW50ZXJhY3RpdmUsIGRpc2FibGVkLCBvblN0YXRlQ2hhbmdlLCBvbkJsdXJdXG4gICk7XG5cbiAgY29uc3QgaWNvbkVsZW1lbnQgPSBpY29uc1tuYW1lXTtcbiAgaWYgKCFpY29uRWxlbWVudCkge1xuICAgIGNvbnNvbGUud2FybihgSWNvbiBcIiR7bmFtZX1cIiBub3QgZm91bmRgKTtcbiAgICByZXR1cm4gbnVsbDtcbiAgfVxuXG4gIGNvbnN0IGFwcGxpZWRDb2xvciA9IGdldEludGVyYWN0aXZlQ29sb3IoKTtcbiAgY29uc3Qgc3RhdGVDbGFzc2VzID0gaW50ZXJhY3RpdmVcbiAgICA/IGBjdXJzb3ItcG9pbnRlciAke2Rpc2FibGVkID8gJ2N1cnNvci1ub3QtYWxsb3dlZCBvcGFjaXR5LTUwJyA6ICcnfWBcbiAgICA6ICcnO1xuICBjb25zdCBmb2N1c0NsYXNzZXMgPVxuICAgIGludGVyYWN0aXZlICYmICFkaXNhYmxlZFxuICAgICAgPyAnZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLXByaW1hcnkgZm9jdXM6cmluZy1vZmZzZXQtMSByb3VuZGVkJ1xuICAgICAgOiAnJztcblxuICBjb25zdCBpY29uV2l0aENsYXNzZXMgPSBSZWFjdC5jbG9uZUVsZW1lbnQoaWNvbkVsZW1lbnQsIHtcbiAgICBjbGFzc05hbWU6IGAke3NpemVDbGFzc2VzW3NpemVdfSAke2FwcGxpZWRDb2xvcn1gLFxuICB9KTtcblxuICBpZiAoaW50ZXJhY3RpdmUpIHtcbiAgICAvLyBGaWx0ZXIgb3V0IFNWRy1zcGVjaWZpYyBwcm9wcyBmb3Igc3BhbiB3cmFwcGVyXG4gICAgY29uc3Qge1xuICAgICAgLy8gU1ZHIGF0dHJpYnV0ZXMgdGhhdCBzaG91bGQgbm90IGJlIHBhc3NlZCB0byBzcGFuXG4gICAgICAvLyBmaWxsLFxuICAgICAgLy8gc3Ryb2tlLFxuICAgICAgLy8gc3Ryb2tlV2lkdGgsXG4gICAgICAvLyBzdHJva2VMaW5lY2FwLFxuICAgICAgLy8gc3Ryb2tlTGluZWpvaW4sXG4gICAgICAvLyBzdHJva2VEYXNoYXJyYXksXG4gICAgICAvLyBzdHJva2VEYXNob2Zmc2V0LFxuICAgICAgLy8gcGF0aExlbmd0aCxcbiAgICAgIC8vIGNsaXBQYXRoLFxuICAgICAgLy8gbWFzayxcbiAgICAgIC8vIGZpbHRlcixcbiAgICAgIC8vIG9wYWNpdHksXG4gICAgICAvLyB0cmFuc2Zvcm0sXG4gICAgICAvLyBzdHlsZSxcbiAgICAgIC8vIC8vIEV2ZW50IGhhbmRsZXJzIHRoYXQgc2hvdWxkIG5vdCBiZSBwYXNzZWQgdG8gc3BhblxuICAgICAgLy8gb25Db3B5LFxuICAgICAgLy8gb25DdXQsXG4gICAgICAvLyBvblBhc3RlLFxuICAgICAgLy8gb25Db21wb3NpdGlvbkVuZCxcbiAgICAgIC8vIG9uQ29tcG9zaXRpb25TdGFydCxcbiAgICAgIC8vIG9uQ29tcG9zaXRpb25VcGRhdGUsXG4gICAgICAvLyBvblNlbGVjdCxcbiAgICAgIC8vIG9uQmVmb3JlSW5wdXQsXG4gICAgICAvLyBvbklucHV0LFxuICAgICAgLi4uc3BhblByb3BzXG4gICAgfSA9IHByb3BzO1xuXG4gICAgcmV0dXJuIChcbiAgICAgIDxzcGFuXG4gICAgICAgIGNsYXNzTmFtZT17YGlubGluZS1ibG9jayAke3N0YXRlQ2xhc3Nlc30gJHtmb2N1c0NsYXNzZXN9ICR7Y2xhc3NOYW1lfWB9XG4gICAgICAgIG9uTW91c2VFbnRlcj17aGFuZGxlTW91c2VFbnRlcn1cbiAgICAgICAgb25Nb3VzZUxlYXZlPXtoYW5kbGVNb3VzZUxlYXZlfVxuICAgICAgICBvbkZvY3VzPXtoYW5kbGVGb2N1c31cbiAgICAgICAgb25CbHVyPXtoYW5kbGVCbHVyfVxuICAgICAgICB0YWJJbmRleD17ZGlzYWJsZWQgPyB1bmRlZmluZWQgOiAwfVxuICAgICAgICByb2xlPVwiYnV0dG9uXCJcbiAgICAgICAgYXJpYS1kaXNhYmxlZD17ZGlzYWJsZWR9XG4gICAgICAgIHsuLi4oc3BhblByb3BzIGFzIFJlYWN0LkhUTUxBdHRyaWJ1dGVzPEhUTUxTcGFuRWxlbWVudD4pfVxuICAgICAgPlxuICAgICAgICB7aWNvbldpdGhDbGFzc2VzfVxuICAgICAgPC9zcGFuPlxuICAgICk7XG4gIH1cblxuICByZXR1cm4gUmVhY3QuY2xvbmVFbGVtZW50KGljb25FbGVtZW50LCB7XG4gICAgY2xhc3NOYW1lOiBgJHtzaXplQ2xhc3Nlc1tzaXplXX0gJHthcHBsaWVkQ29sb3J9ICR7Y2xhc3NOYW1lfWAsXG4gICAgLi4ucHJvcHMsXG4gIH0pO1xufTtcbiJdfQ==