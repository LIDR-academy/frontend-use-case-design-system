import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/atoms/Input/Input.stories.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.cache/sb-vite/deps/react_jsx-dev-runtime.js?v=77221ebe"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$();
import __vite__cjsImport1_react from "/node_modules/.cache/sb-vite/deps/react.js?v=77221ebe"; const useState = __vite__cjsImport1_react["useState"];
import { userEvent, within, expect } from "/node_modules/.cache/sb-vite/deps/@storybook_test.js?v=77221ebe";
import { Input } from "/src/components/atoms/Input/Input.tsx";
const meta = {
  title: "Atoms/Input",
  component: Input,
  parameters: {
    layout: "centered",
    docs: {
      description: {
        component: "Campo de entrada de texto con diferentes variantes y estados."
      }
    },
    a11y: {
      config: {
        rules: [{
          id: "label",
          enabled: true
        }, {
          id: "autocomplete-valid",
          enabled: true
        }]
      }
    }
  },
  argTypes: {
    variant: {
      control: {
        type: "select"
      },
      options: ["outlined", "filled", "standard"],
      description: "Estilo visual del input"
    },
    type: {
      control: {
        type: "select"
      },
      options: ["text", "email", "password", "number", "tel", "url"],
      description: "Tipo de input HTML"
    },
    disabled: {
      control: {
        type: "boolean"
      },
      description: "Si el input está deshabilitado"
    },
    required: {
      control: {
        type: "boolean"
      },
      description: "Si el campo es obligatorio"
    },
    fullWidth: {
      control: {
        type: "boolean"
      },
      description: "Si ocupa todo el ancho disponible"
    },
    label: {
      control: "text",
      description: "Etiqueta del campo"
    },
    placeholder: {
      control: "text",
      description: "Texto placeholder"
    },
    error: {
      control: "text",
      description: "Mensaje de error"
    },
    helperText: {
      control: "text",
      description: "Texto de ayuda"
    }
  },
  tags: ["autodocs"]
};
export default meta;
export const Outlined = {
  args: {
    label: "Email",
    placeholder: "Enter your email",
    type: "email",
    variant: "outlined"
  },
  parameters: {
    docs: {
      description: {
        story: "Input con borde - variante más común"
      }
    }
  }
};
export const Filled = {
  args: {
    label: "Password",
    placeholder: "Enter your password",
    type: "password",
    variant: "filled"
  },
  parameters: {
    docs: {
      description: {
        story: "Input con fondo relleno"
      }
    }
  }
};
export const Standard = {
  args: {
    label: "Name",
    placeholder: "Enter your name",
    variant: "standard"
  },
  parameters: {
    docs: {
      description: {
        story: "Input estilo material design con línea inferior"
      }
    }
  }
};
export const WithError = {
  args: {
    label: "Email",
    placeholder: "Enter your email",
    type: "email",
    error: "Please enter a valid email address",
    variant: "outlined"
  },
  parameters: {
    docs: {
      description: {
        story: "Input mostrando estado de error"
      }
    }
  }
};
export const WithHelperText = {
  args: {
    label: "Password",
    placeholder: "Enter your password",
    type: "password",
    helperText: "Password must be at least 8 characters",
    variant: "outlined"
  },
  parameters: {
    docs: {
      description: {
        story: "Input con texto de ayuda"
      }
    }
  }
};
export const Disabled = {
  args: {
    label: "Disabled Field",
    placeholder: "This field is disabled",
    disabled: true,
    variant: "outlined"
  },
  parameters: {
    docs: {
      description: {
        story: "Input deshabilitado"
      }
    }
  }
};
export const Required = {
  args: {
    label: "Required Field",
    placeholder: "This field is required",
    required: true,
    variant: "outlined"
  },
  parameters: {
    docs: {
      description: {
        story: "Input obligatorio con indicador visual"
      }
    }
  }
};
export const WithStartIcon = {
  args: {
    label: "Search",
    placeholder: "Search...",
    startIcon: /* @__PURE__ */jsxDEV("svg", {
      className: "w-5 h-5",
      fill: "none",
      stroke: "currentColor",
      viewBox: "0 0 24 24",
      children: /* @__PURE__ */jsxDEV("path", {
        strokeLinecap: "round",
        strokeLinejoin: "round",
        strokeWidth: 2,
        d: "M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"
      }, void 0, false, {
        fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/atoms/Input/Input.stories.tsx",
        lineNumber: 205,
        columnNumber: 9
      }, this)
    }, void 0, false, {
      fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/atoms/Input/Input.stories.tsx",
      lineNumber: 199,
      columnNumber: 5
    }, this),
    variant: "outlined"
  },
  parameters: {
    docs: {
      description: {
        story: "Input con icono al inicio"
      }
    }
  }
};
export const WithEndIcon = {
  args: {
    label: "Password",
    placeholder: "Enter password",
    type: "password",
    endIcon: /* @__PURE__ */jsxDEV("svg", {
      className: "w-5 h-5",
      fill: "none",
      stroke: "currentColor",
      viewBox: "0 0 24 24",
      children: [/* @__PURE__ */jsxDEV("path", {
        strokeLinecap: "round",
        strokeLinejoin: "round",
        strokeWidth: 2,
        d: "M15 12a3 3 0 11-6 0 3 3 0 016 0z"
      }, void 0, false, {
        fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/atoms/Input/Input.stories.tsx",
        lineNumber: 236,
        columnNumber: 9
      }, this), /* @__PURE__ */jsxDEV("path", {
        strokeLinecap: "round",
        strokeLinejoin: "round",
        strokeWidth: 2,
        d: "M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"
      }, void 0, false, {
        fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/atoms/Input/Input.stories.tsx",
        lineNumber: 242,
        columnNumber: 9
      }, this)]
    }, void 0, true, {
      fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/atoms/Input/Input.stories.tsx",
      lineNumber: 230,
      columnNumber: 5
    }, this),
    variant: "outlined"
  },
  parameters: {
    docs: {
      description: {
        story: "Input con icono al final"
      }
    }
  }
};
export const FullWidth = {
  args: {
    label: "Full Width Input",
    placeholder: "This input takes full width",
    fullWidth: true,
    variant: "outlined"
  },
  parameters: {
    layout: "padded",
    docs: {
      description: {
        story: "Input que ocupa todo el ancho disponible"
      }
    }
  }
};
export const TypeInteraction = {
  args: {
    label: "Name",
    placeholder: "Enter your name",
    variant: "outlined"
  },
  play: async ({
    canvasElement
  }) => {
    const canvas = within(canvasElement);
    const input = canvas.getByLabelText("Name");
    await expect(input).toBeInTheDocument();
    await userEvent.type(input, "John Doe");
    await expect(input).toHaveValue("John Doe");
  },
  parameters: {
    docs: {
      description: {
        story: "Demostración de interaction testing - escribir en el input"
      }
    }
  }
};
const ControlledInputExample = () => {
  _s();
  const [value, setValue] = useState("");
  const [error, setError] = useState("");
  const handleChange = e => {
    const newValue = e.target.value;
    setValue(newValue);
    if (newValue.length < 3) {
      setError("Mínimo 3 caracteres");
    } else {
      setError("");
    }
  };
  return /* @__PURE__ */jsxDEV("div", {
    className: "w-80",
    children: [/* @__PURE__ */jsxDEV(Input, {
      label: "Controlled Input",
      placeholder: "Type something...",
      value,
      onChange: handleChange,
      error,
      variant: "outlined"
    }, void 0, false, {
      fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/atoms/Input/Input.stories.tsx",
      lineNumber: 327,
      columnNumber: 7
    }, this), /* @__PURE__ */jsxDEV("p", {
      className: "mt-2 text-sm text-text-secondary",
      children: ["Characters: ", value.length]
    }, void 0, true, {
      fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/atoms/Input/Input.stories.tsx",
      lineNumber: 335,
      columnNumber: 7
    }, this)]
  }, void 0, true, {
    fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/atoms/Input/Input.stories.tsx",
    lineNumber: 326,
    columnNumber: 5
  }, this);
};
_s(ControlledInputExample, "qxZdhtr9g92c3GV8J/N8QXf7hhg=");
_c = ControlledInputExample;
export const Controlled = {
  render: () => /* @__PURE__ */jsxDEV(ControlledInputExample, {}, void 0, false, {
    fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/atoms/Input/Input.stories.tsx",
    lineNumber: 343,
    columnNumber: 17
  }, this),
  parameters: {
    docs: {
      description: {
        story: "Ejemplo de input controlado con validación en tiempo real"
      }
    }
  }
};
var _c;
$RefreshReg$(_c, "ControlledInputExample");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong.");
  }
  RefreshRuntime.__hmr_import(import.meta.url).then(currentExports => {
    RefreshRuntime.registerExportsForReactRefresh("/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/atoms/Input/Input.stories.tsx", currentExports);
    import.meta.hot.accept(nextExports => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/atoms/Input/Input.stories.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/atoms/Input/Input.stories.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}
Outlined.parameters = {
  ...Outlined.parameters,
  docs: {
    ...Outlined.parameters?.docs,
    source: {
      originalSource: "{\n  args: {\n    label: 'Email',\n    placeholder: 'Enter your email',\n    type: 'email',\n    variant: 'outlined'\n  },\n  parameters: {\n    docs: {\n      description: {\n        story: 'Input con borde - variante m\xE1s com\xFAn'\n      }\n    }\n  }\n}",
      ...Outlined.parameters?.docs?.source
    }
  }
};
Filled.parameters = {
  ...Filled.parameters,
  docs: {
    ...Filled.parameters?.docs,
    source: {
      originalSource: "{\n  args: {\n    label: 'Password',\n    placeholder: 'Enter your password',\n    type: 'password',\n    variant: 'filled'\n  },\n  parameters: {\n    docs: {\n      description: {\n        story: 'Input con fondo relleno'\n      }\n    }\n  }\n}",
      ...Filled.parameters?.docs?.source
    }
  }
};
Standard.parameters = {
  ...Standard.parameters,
  docs: {
    ...Standard.parameters?.docs,
    source: {
      originalSource: "{\n  args: {\n    label: 'Name',\n    placeholder: 'Enter your name',\n    variant: 'standard'\n  },\n  parameters: {\n    docs: {\n      description: {\n        story: 'Input estilo material design con l\xEDnea inferior'\n      }\n    }\n  }\n}",
      ...Standard.parameters?.docs?.source
    }
  }
};
WithError.parameters = {
  ...WithError.parameters,
  docs: {
    ...WithError.parameters?.docs,
    source: {
      originalSource: "{\n  args: {\n    label: 'Email',\n    placeholder: 'Enter your email',\n    type: 'email',\n    error: 'Please enter a valid email address',\n    variant: 'outlined'\n  },\n  parameters: {\n    docs: {\n      description: {\n        story: 'Input mostrando estado de error'\n      }\n    }\n  }\n}",
      ...WithError.parameters?.docs?.source
    }
  }
};
WithHelperText.parameters = {
  ...WithHelperText.parameters,
  docs: {
    ...WithHelperText.parameters?.docs,
    source: {
      originalSource: "{\n  args: {\n    label: 'Password',\n    placeholder: 'Enter your password',\n    type: 'password',\n    helperText: 'Password must be at least 8 characters',\n    variant: 'outlined'\n  },\n  parameters: {\n    docs: {\n      description: {\n        story: 'Input con texto de ayuda'\n      }\n    }\n  }\n}",
      ...WithHelperText.parameters?.docs?.source
    }
  }
};
Disabled.parameters = {
  ...Disabled.parameters,
  docs: {
    ...Disabled.parameters?.docs,
    source: {
      originalSource: "{\n  args: {\n    label: 'Disabled Field',\n    placeholder: 'This field is disabled',\n    disabled: true,\n    variant: 'outlined'\n  },\n  parameters: {\n    docs: {\n      description: {\n        story: 'Input deshabilitado'\n      }\n    }\n  }\n}",
      ...Disabled.parameters?.docs?.source
    }
  }
};
Required.parameters = {
  ...Required.parameters,
  docs: {
    ...Required.parameters?.docs,
    source: {
      originalSource: "{\n  args: {\n    label: 'Required Field',\n    placeholder: 'This field is required',\n    required: true,\n    variant: 'outlined'\n  },\n  parameters: {\n    docs: {\n      description: {\n        story: 'Input obligatorio con indicador visual'\n      }\n    }\n  }\n}",
      ...Required.parameters?.docs?.source
    }
  }
};
WithStartIcon.parameters = {
  ...WithStartIcon.parameters,
  docs: {
    ...WithStartIcon.parameters?.docs,
    source: {
      originalSource: "{\n  args: {\n    label: 'Search',\n    placeholder: 'Search...',\n    startIcon: <svg className=\"w-5 h-5\" fill=\"none\" stroke=\"currentColor\" viewBox=\"0 0 24 24\">\n        <path strokeLinecap=\"round\" strokeLinejoin=\"round\" strokeWidth={2} d=\"M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z\" />\n      </svg>,\n    variant: 'outlined'\n  },\n  parameters: {\n    docs: {\n      description: {\n        story: 'Input con icono al inicio'\n      }\n    }\n  }\n}",
      ...WithStartIcon.parameters?.docs?.source
    }
  }
};
WithEndIcon.parameters = {
  ...WithEndIcon.parameters,
  docs: {
    ...WithEndIcon.parameters?.docs,
    source: {
      originalSource: "{\n  args: {\n    label: 'Password',\n    placeholder: 'Enter password',\n    type: 'password',\n    endIcon: <svg className=\"w-5 h-5\" fill=\"none\" stroke=\"currentColor\" viewBox=\"0 0 24 24\">\n        <path strokeLinecap=\"round\" strokeLinejoin=\"round\" strokeWidth={2} d=\"M15 12a3 3 0 11-6 0 3 3 0 016 0z\" />\n        <path strokeLinecap=\"round\" strokeLinejoin=\"round\" strokeWidth={2} d=\"M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z\" />\n      </svg>,\n    variant: 'outlined'\n  },\n  parameters: {\n    docs: {\n      description: {\n        story: 'Input con icono al final'\n      }\n    }\n  }\n}",
      ...WithEndIcon.parameters?.docs?.source
    }
  }
};
FullWidth.parameters = {
  ...FullWidth.parameters,
  docs: {
    ...FullWidth.parameters?.docs,
    source: {
      originalSource: "{\n  args: {\n    label: 'Full Width Input',\n    placeholder: 'This input takes full width',\n    fullWidth: true,\n    variant: 'outlined'\n  },\n  parameters: {\n    layout: 'padded',\n    docs: {\n      description: {\n        story: 'Input que ocupa todo el ancho disponible'\n      }\n    }\n  }\n}",
      ...FullWidth.parameters?.docs?.source
    }
  }
};
TypeInteraction.parameters = {
  ...TypeInteraction.parameters,
  docs: {
    ...TypeInteraction.parameters?.docs,
    source: {
      originalSource: "{\n  args: {\n    label: 'Name',\n    placeholder: 'Enter your name',\n    variant: 'outlined'\n  },\n  play: async ({\n    canvasElement\n  }) => {\n    const canvas = within(canvasElement);\n    const input = canvas.getByLabelText('Name');\n\n    // Verificar que el input est\xE1 visible\n    await expect(input).toBeInTheDocument();\n\n    // Simular escritura\n    await userEvent.type(input, 'John Doe');\n\n    // Verificar que el valor se actualiz\xF3\n    await expect(input).toHaveValue('John Doe');\n  },\n  parameters: {\n    docs: {\n      description: {\n        story: 'Demostraci\xF3n de interaction testing - escribir en el input'\n      }\n    }\n  }\n}",
      ...TypeInteraction.parameters?.docs?.source
    }
  }
};
Controlled.parameters = {
  ...Controlled.parameters,
  docs: {
    ...Controlled.parameters?.docs,
    source: {
      originalSource: "{\n  render: () => <ControlledInputExample />,\n  parameters: {\n    docs: {\n      description: {\n        story: 'Ejemplo de input controlado con validaci\xF3n en tiempo real'\n      }\n    }\n  }\n}",
      ...Controlled.parameters?.docs?.source
    }
  }
};;export const __namedExportsOrder = ["Outlined","Filled","Standard","WithError","WithHelperText","Disabled","Required","WithStartIcon","WithEndIcon","FullWidth","TypeInteraction","Controlled"];