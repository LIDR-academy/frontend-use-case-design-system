import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/atoms/Input/Input.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.cache/sb-vite/deps/react_jsx-dev-runtime.js?v=77221ebe"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import __vite__cjsImport1_react from "/node_modules/.cache/sb-vite/deps/react.js?v=77221ebe"; const forwardRef = __vite__cjsImport1_react["forwardRef"];
export const Input = forwardRef(
  _c = ({
    label,
    error,
    helperText,
    startIcon,
    endIcon,
    fullWidth = false,
    variant = "outlined",
    className = "",
    id,
    ...props
  }, ref) => {
    const inputId = id || `input-${Math.random().toString(36).substr(2, 9)}`;
    const baseStyles = "flex items-center gap-2 px-3 py-2 text-base transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-50";
    const variantStyles = {
      outlined: `border border-input bg-background text-foreground placeholder:text-muted-foreground focus-visible:ring-ring rounded-md ${error ? "border-destructive focus-visible:ring-destructive" : ""}`,
      filled: `border-0 bg-muted text-foreground placeholder:text-muted-foreground focus-visible:ring-ring rounded-md ${error ? "bg-destructive/10 focus-visible:ring-destructive" : ""}`,
      standard: `border-0 border-b-2 border-input bg-transparent text-foreground placeholder:text-muted-foreground focus-visible:border-ring focus-visible:ring-0 rounded-none px-0 pb-1 ${error ? "border-destructive focus-visible:border-destructive" : ""}`
    };
    const widthStyles = fullWidth ? "w-full" : "";
    return /* @__PURE__ */ jsxDEV("div", { className: `flex flex-col gap-1 ${widthStyles}`, children: [
      label && /* @__PURE__ */ jsxDEV(
        "label",
        {
          htmlFor: inputId,
          className: "text-sm font-medium text-foreground",
          children: [
            label,
            props.required && /* @__PURE__ */ jsxDEV("span", { className: "text-destructive ml-1", children: "*" }, void 0, false, {
              fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/atoms/Input/Input.tsx",
              lineNumber: 57,
              columnNumber: 32
            }, this)
          ]
        },
        void 0,
        true,
        {
          fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/atoms/Input/Input.tsx",
          lineNumber: 52,
          columnNumber: 7
        },
        this
      ),
      /* @__PURE__ */ jsxDEV("div", { className: "relative", children: [
        startIcon && /* @__PURE__ */ jsxDEV("div", { className: "absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground", children: startIcon }, void 0, false, {
          fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/atoms/Input/Input.tsx",
          lineNumber: 63,
          columnNumber: 9
        }, this),
        /* @__PURE__ */ jsxDEV(
          "input",
          {
            ref,
            id: inputId,
            className: `${baseStyles} ${variantStyles[variant]} ${startIcon ? "pl-10" : ""} ${endIcon ? "pr-10" : ""} ${className}`,
            ...props
          },
          void 0,
          false,
          {
            fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/atoms/Input/Input.tsx",
            lineNumber: 68,
            columnNumber: 11
          },
          this
        ),
        endIcon && /* @__PURE__ */ jsxDEV("div", { className: "absolute right-3 top-1/2 transform -translate-y-1/2 text-muted-foreground", children: endIcon }, void 0, false, {
          fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/atoms/Input/Input.tsx",
          lineNumber: 78,
          columnNumber: 9
        }, this)
      ] }, void 0, true, {
        fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/atoms/Input/Input.tsx",
        lineNumber: 61,
        columnNumber: 9
      }, this),
      (error || helperText) && /* @__PURE__ */ jsxDEV("div", { className: "text-sm", children: [
        error && /* @__PURE__ */ jsxDEV("p", { className: "text-destructive", role: "alert", children: error }, void 0, false, {
          fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/atoms/Input/Input.tsx",
          lineNumber: 87,
          columnNumber: 9
        }, this),
        helperText && !error && /* @__PURE__ */ jsxDEV("p", { className: "text-muted-foreground", children: helperText }, void 0, false, {
          fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/atoms/Input/Input.tsx",
          lineNumber: 92,
          columnNumber: 9
        }, this)
      ] }, void 0, true, {
        fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/atoms/Input/Input.tsx",
        lineNumber: 85,
        columnNumber: 7
      }, this)
    ] }, void 0, true, {
      fileName: "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/atoms/Input/Input.tsx",
      lineNumber: 50,
      columnNumber: 5
    }, this);
  }
);
_c2 = Input;
Input.displayName = "Input";
var _c, _c2;
$RefreshReg$(_c, "Input$forwardRef");
$RefreshReg$(_c2, "Input");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/atoms/Input/Input.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/atoms/Input/Input.tsx", currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "/home/sunde/projects/Lidr/frontend-use-case-design-system/src/components/atoms/Input/Input.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}
try {
    // @ts-ignore
    Input.displayName = "Input";
    // @ts-ignore
    Input.__docgenInfo = { "description": "", "displayName": "Input", "props": { "label": { "defaultValue": null, "description": "", "name": "label", "required": false, "type": { "name": "string" } }, "error": { "defaultValue": null, "description": "", "name": "error", "required": false, "type": { "name": "string" } }, "helperText": { "defaultValue": null, "description": "", "name": "helperText", "required": false, "type": { "name": "string" } }, "startIcon": { "defaultValue": null, "description": "", "name": "startIcon", "required": false, "type": { "name": "React.ReactNode" } }, "endIcon": { "defaultValue": null, "description": "", "name": "endIcon", "required": false, "type": { "name": "React.ReactNode" } }, "fullWidth": { "defaultValue": { value: "false" }, "description": "", "name": "fullWidth", "required": false, "type": { "name": "boolean" } }, "variant": { "defaultValue": { value: "outlined" }, "description": "", "name": "variant", "required": false, "type": { "name": "enum", "value": [{ "value": "\"outlined\"" }, { "value": "\"filled\"" }, { "value": "\"standard\"" }] } } } };
}
catch (__react_docgen_typescript_loader_error) { }
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBd0QrQjtBQXhEL0I7QUFhTztBQUFjQTtBQUVqQjtBQUNFQztBQUNBQztBQUNBQztBQUNBQztBQUNBQztBQUNZO0FBQ0Y7QUFDRTtBQUNaQztBQUNHQztBQUlMO0FBRUE7QUFHQTtBQUFzQjtBQUU0QztBQUdEO0FBR0c7QUFJcEU7QUFFQTtBQUVLTjtBQUNDO0FBQUM7QUFBQTtBQUNVTztBQUNDO0FBRVRQO0FBQUFBO0FBQ2tCO0FBQUE7QUFBQTtBQUFBO0FBQXlDO0FBQUE7QUFBQTtBQUw5RDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBTUE7QUFJQ0c7QUFDQztBQUFBO0FBQUE7QUFBQTtBQUVBO0FBR0Y7QUFBQztBQUFBO0FBQ0M7QUFDSUk7QUFHMEJDO0FBQzFCRjtBQUFBQTtBQU5OO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFNWTtBQUlWO0FBQUE7QUFBQTtBQUFBO0FBRUE7QUFuQko7QUFBQTtBQUFBO0FBQUE7QUFxQkE7QUFJS0w7QUFDQztBQUFBO0FBQUE7QUFBQTtBQUVBO0FBR0E7QUFBQTtBQUFBO0FBQUE7QUFBaUQ7QUFQckQ7QUFBQTtBQUFBO0FBQUE7QUFTQTtBQTVDSjtBQUFBO0FBQUE7QUFBQTtBQThDQTtBQUdOO0FBQUVRO0FBRUZDO0FBQTRCO0FBQUFDO0FBQUFBIiwibmFtZXMiOlsiZm9yd2FyZFJlZiIsImxhYmVsIiwiZXJyb3IiLCJoZWxwZXJUZXh0Iiwic3RhcnRJY29uIiwiZW5kSWNvbiIsImlkIiwicHJvcHMiLCJpbnB1dElkIiwiY2xhc3NOYW1lIiwiX2MyIiwiSW5wdXQiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJJbnB1dC50c3giXSwiZmlsZSI6Ii9ob21lL3N1bmRlL3Byb2plY3RzL0xpZHIvZnJvbnRlbmQtdXNlLWNhc2UtZGVzaWduLXN5c3RlbS9zcmMvY29tcG9uZW50cy9hdG9tcy9JbnB1dC9JbnB1dC50c3giLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QsIHsgZm9yd2FyZFJlZiB9IGZyb20gJ3JlYWN0JztcblxuZXhwb3J0IGludGVyZmFjZSBJbnB1dFByb3BzXG4gIGV4dGVuZHMgUmVhY3QuSW5wdXRIVE1MQXR0cmlidXRlczxIVE1MSW5wdXRFbGVtZW50PiB7XG4gIGxhYmVsPzogc3RyaW5nO1xuICBlcnJvcj86IHN0cmluZztcbiAgaGVscGVyVGV4dD86IHN0cmluZztcbiAgc3RhcnRJY29uPzogUmVhY3QuUmVhY3ROb2RlO1xuICBlbmRJY29uPzogUmVhY3QuUmVhY3ROb2RlO1xuICBmdWxsV2lkdGg/OiBib29sZWFuO1xuICB2YXJpYW50PzogJ291dGxpbmVkJyB8ICdmaWxsZWQnIHwgJ3N0YW5kYXJkJztcbn1cblxuZXhwb3J0IGNvbnN0IElucHV0ID0gZm9yd2FyZFJlZjxIVE1MSW5wdXRFbGVtZW50LCBJbnB1dFByb3BzPihcbiAgKFxuICAgIHtcbiAgICAgIGxhYmVsLFxuICAgICAgZXJyb3IsXG4gICAgICBoZWxwZXJUZXh0LFxuICAgICAgc3RhcnRJY29uLFxuICAgICAgZW5kSWNvbixcbiAgICAgIGZ1bGxXaWR0aCA9IGZhbHNlLFxuICAgICAgdmFyaWFudCA9ICdvdXRsaW5lZCcsXG4gICAgICBjbGFzc05hbWUgPSAnJyxcbiAgICAgIGlkLFxuICAgICAgLi4ucHJvcHNcbiAgICB9LFxuICAgIHJlZlxuICApID0+IHtcbiAgICBjb25zdCBpbnB1dElkID0gaWQgfHwgYGlucHV0LSR7TWF0aC5yYW5kb20oKS50b1N0cmluZygzNikuc3Vic3RyKDIsIDkpfWA7XG5cbiAgICBjb25zdCBiYXNlU3R5bGVzID1cbiAgICAgICdmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBweC0zIHB5LTIgdGV4dC1iYXNlIHRyYW5zaXRpb24tY29sb3JzIGZvY3VzLXZpc2libGU6b3V0bGluZS1ub25lIGZvY3VzLXZpc2libGU6cmluZy0yIGZvY3VzLXZpc2libGU6cmluZy1yaW5nIGRpc2FibGVkOnBvaW50ZXItZXZlbnRzLW5vbmUgZGlzYWJsZWQ6b3BhY2l0eS01MCc7XG5cbiAgICBjb25zdCB2YXJpYW50U3R5bGVzID0ge1xuICAgICAgb3V0bGluZWQ6IGBib3JkZXIgYm9yZGVyLWlucHV0IGJnLWJhY2tncm91bmQgdGV4dC1mb3JlZ3JvdW5kIHBsYWNlaG9sZGVyOnRleHQtbXV0ZWQtZm9yZWdyb3VuZCBmb2N1cy12aXNpYmxlOnJpbmctcmluZyByb3VuZGVkLW1kICR7XG4gICAgICAgIGVycm9yID8gJ2JvcmRlci1kZXN0cnVjdGl2ZSBmb2N1cy12aXNpYmxlOnJpbmctZGVzdHJ1Y3RpdmUnIDogJydcbiAgICAgIH1gLFxuICAgICAgZmlsbGVkOiBgYm9yZGVyLTAgYmctbXV0ZWQgdGV4dC1mb3JlZ3JvdW5kIHBsYWNlaG9sZGVyOnRleHQtbXV0ZWQtZm9yZWdyb3VuZCBmb2N1cy12aXNpYmxlOnJpbmctcmluZyByb3VuZGVkLW1kICR7XG4gICAgICAgIGVycm9yID8gJ2JnLWRlc3RydWN0aXZlLzEwIGZvY3VzLXZpc2libGU6cmluZy1kZXN0cnVjdGl2ZScgOiAnJ1xuICAgICAgfWAsXG4gICAgICBzdGFuZGFyZDogYGJvcmRlci0wIGJvcmRlci1iLTIgYm9yZGVyLWlucHV0IGJnLXRyYW5zcGFyZW50IHRleHQtZm9yZWdyb3VuZCBwbGFjZWhvbGRlcjp0ZXh0LW11dGVkLWZvcmVncm91bmQgZm9jdXMtdmlzaWJsZTpib3JkZXItcmluZyBmb2N1cy12aXNpYmxlOnJpbmctMCByb3VuZGVkLW5vbmUgcHgtMCBwYi0xICR7XG4gICAgICAgIGVycm9yID8gJ2JvcmRlci1kZXN0cnVjdGl2ZSBmb2N1cy12aXNpYmxlOmJvcmRlci1kZXN0cnVjdGl2ZScgOiAnJ1xuICAgICAgfWAsXG4gICAgfTtcblxuICAgIGNvbnN0IHdpZHRoU3R5bGVzID0gZnVsbFdpZHRoID8gJ3ctZnVsbCcgOiAnJztcblxuICAgIHJldHVybiAoXG4gICAgICA8ZGl2IGNsYXNzTmFtZT17YGZsZXggZmxleC1jb2wgZ2FwLTEgJHt3aWR0aFN0eWxlc31gfT5cbiAgICAgICAge2xhYmVsICYmIChcbiAgICAgICAgICA8bGFiZWxcbiAgICAgICAgICAgIGh0bWxGb3I9e2lucHV0SWR9XG4gICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZm9yZWdyb3VuZFwiXG4gICAgICAgICAgPlxuICAgICAgICAgICAge2xhYmVsfVxuICAgICAgICAgICAge3Byb3BzLnJlcXVpcmVkICYmIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtZGVzdHJ1Y3RpdmUgbWwtMVwiPio8L3NwYW4+fVxuICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICl9XG5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZVwiPlxuICAgICAgICAgIHtzdGFydEljb24gJiYgKFxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhYnNvbHV0ZSBsZWZ0LTMgdG9wLTEvMiB0cmFuc2Zvcm0gLXRyYW5zbGF0ZS15LTEvMiB0ZXh0LW11dGVkLWZvcmVncm91bmRcIj5cbiAgICAgICAgICAgICAge3N0YXJ0SWNvbn1cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICl9XG5cbiAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgIHJlZj17cmVmfVxuICAgICAgICAgICAgaWQ9e2lucHV0SWR9XG4gICAgICAgICAgICBjbGFzc05hbWU9e2Ake2Jhc2VTdHlsZXN9ICR7dmFyaWFudFN0eWxlc1t2YXJpYW50XX0gJHtcbiAgICAgICAgICAgICAgc3RhcnRJY29uID8gJ3BsLTEwJyA6ICcnXG4gICAgICAgICAgICB9ICR7ZW5kSWNvbiA/ICdwci0xMCcgOiAnJ30gJHtjbGFzc05hbWV9YH1cbiAgICAgICAgICAgIHsuLi5wcm9wc31cbiAgICAgICAgICAvPlxuXG4gICAgICAgICAge2VuZEljb24gJiYgKFxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhYnNvbHV0ZSByaWdodC0zIHRvcC0xLzIgdHJhbnNmb3JtIC10cmFuc2xhdGUteS0xLzIgdGV4dC1tdXRlZC1mb3JlZ3JvdW5kXCI+XG4gICAgICAgICAgICAgIHtlbmRJY29ufVxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgKX1cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgeyhlcnJvciB8fCBoZWxwZXJUZXh0KSAmJiAoXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXNtXCI+XG4gICAgICAgICAgICB7ZXJyb3IgJiYgKFxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LWRlc3RydWN0aXZlXCIgcm9sZT1cImFsZXJ0XCI+XG4gICAgICAgICAgICAgICAge2Vycm9yfVxuICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICApfVxuICAgICAgICAgICAge2hlbHBlclRleHQgJiYgIWVycm9yICYmIChcbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1tdXRlZC1mb3JlZ3JvdW5kXCI+e2hlbHBlclRleHR9PC9wPlxuICAgICAgICAgICAgKX1cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgKX1cbiAgICAgIDwvZGl2PlxuICAgICk7XG4gIH1cbik7XG5cbklucHV0LmRpc3BsYXlOYW1lID0gJ0lucHV0JztcbiJdfQ==